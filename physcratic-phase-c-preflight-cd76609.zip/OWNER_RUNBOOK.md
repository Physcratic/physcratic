# Phase C read-only Production permission preflight

## Release to verify

| Item | Pinned reference |
| --- | --- |
| Site and Vercel project | `physcratic.com`, `neuterions-projects/financial-dashboard` |
| READY Production deployment | `dpl_2Lm7mcuKVpwA3a7G7xnRSVoGbWMm` |
| Exact main and serving SHA | `cd766099586d3935e9b6e1e427181cc8be5f8f85` |
| GitHub push CI | `44579380708`, all three jobs successful |
| Neon Production | `divine-mode-82940461` / `br-quiet-dawn-b7m2zrt3` / `ep-snowy-heart-b7c1220y` / `neondb` |
| Restricted application role | `physcratic_runtime_app` |
| Approved metadata transport | Existing direct libpq service, PostgreSQL 18.7, TLS `verify-full` |

[Deployment](https://vercel.com/neuterions-projects/financial-dashboard/2Lm7mcuKVpwA3a7G7xnRSVoGbWMm) · [Exact-main CI](https://github.com/Physcratic/physcratic/actions/runs/44579380708) · [Reviewed Phase C checklist](https://github.com/Physcratic/physcratic/blob/cd766099586d3935e9b6e1e427181cc8be5f8f85/docs/engineering/PHASE_C_B1_RELEASE_CHECKLIST.md)

Verified during preparation: the actual alias and current main match the table.
The saved `DATABASE_URL` is sensitive and Production-only. Its recorded metadata
update predates the accepted November 19 restricted LOGIN receipt. The saved
temporary attestation variable is absent. No saved encrypted values were read.
The prior receipt covers the sampled pool on `cd1e2c7`. Effective binding and
flags on this deployment, live ledger, and privileges are owner checks.

## 1. Confirm control-plane evidence privately

1. In Vercel, start from the actual `physcratic.com` alias and confirm the READY
   Production deployment and full Git SHA above. Check the project setting's
   scope and update history and the owner-held release binding reference.
   Confirm continuity to the previously accepted restricted pooled Production
   binding and that the temporary attestation variable remains absent. Retain
   only IDs, scopes, dates and pass/fail evidence. Leave URL values sealed.
2. Confirm effective Production `COMMUNITY_PROBLEM_STATS_ENABLED=true`. Confirm
   each gate below is OFF on the serving deployment. Use the owner-held release
   evidence. Saved scopes and source defaults alone are incomplete.

   ```text
   COMMUNITY_PROFILES_ENABLED
   COMMUNITY_PROFILE_MEDIA_ENABLED
   COMMUNITY_AUTHORSHIP_ENABLED
   COMMUNITY_ACHIEVEMENTS_ENABLED
   COMMUNITY_MEDALS_ENABLED
   COMMUNITY_MEDAL_SHOWCASE_ENABLED
   COMMUNITY_COMMENTS_ENABLED
   COMMUNITY_MODERATION_ENABLED
   COMMUNITY_MODERATION_UI_ENABLED
   COMMUNITY_STAFF_ENABLED
   COMMUNITY_ACTIONS_ENABLED
   COMMUNITY_VERIFICATION_UI_ENABLED
   PRACTICE_CHECKS_ENABLED
   ACCOUNT_DELETION_ENABLED
   AUTHORED_PUBLIC_SOLUTIONS_ENABLED
   ```
3. Check the direct endpoint above against the Neon Production branch in the
   console. Confirm the approved operator LOGIN, credential-free connection
   inputs, trusted CA, and existing libpq service can authenticate using
   `psql -w`. Use the owner-approved service as configured. A transaction
   pooler is unsuitable for spanning the audits' transactions with one
   `batch-a` setting. Confirm the independently usable rollback deployment
   and binding reference. Coordinate a window without competing DDL or grants.
4. Stop if deployment, source, role, TLS, branch, flags or binding continuity
   are unknown or differ. Reconfirm the alias immediately before the SQL step.
   This preflight uses the accepted historical sample alongside current
   control-plane evidence. The metadata session itself verifies the operator
   identity separately from the deployed application's LOGIN.

[Project environment settings](https://vercel.com/neuterions-projects/financial-dashboard/settings/environment-variables) · [Accepted historical sample](https://github.com/Physcratic/physcratic/blob/cd766099586d3935e9b6e1e427181cc8be5f8f85/docs/engineering/RUNTIME_LOGIN_ATTESTATION.md)

## 2. Review the local commands in Windows PowerShell 5.1

Use a private, transcript-free terminal with Git and psql 16+ on PATH. Save
`Invoke-PhaseCReadOnly.ps1` and `phase-c-readonly.sql` together in a local folder
outside the repo. Retain the original LF bytes of the SQL file. From that folder,
prepare a fresh local checkout. Choose an unused local directory.

```powershell
$Repo = 'C:\src\physcratic-phase-c-cd76609'
$Release = 'cd766099586d3935e9b6e1e427181cc8be5f8f85'
git -c core.autocrlf=false clone --no-checkout https://github.com/Physcratic/physcratic.git $Repo
if ($LASTEXITCODE -ne 0) { throw 'Clone failed' }
git -C $Repo -c core.autocrlf=false checkout --detach $Release
if ($LASTEXITCODE -ne 0) { throw 'Checkout failed' }
.\Invoke-PhaseCReadOnly.ps1 -Repository $Repo
```

The default command checks current main, the clean pinned checkout, exact CI,
both manifest digests and every listed entry, reviewed artifact hashes, and the
driver hash. It opens no database connection. On a mismatch, stop and obtain a
reviewed pin or a clean LF checkout. Preserve manifest bytes.

| Manifest | SHA-256 | Entries |
| --- | --- | --- |
| `scripts/activation/PACKAGE_SHA256SUMS` | `fa6fb4ebce76b3ca674640fa61b807f1ba1e1b7ea4a1d9d4d6e8a6bbcf48de6b` | 23 |
| `scripts/runtime-role/PACKAGE_SHA256SUMS` | `1eb029de161d636903173c15a9337beefef954ebd46102505abcac9433b9e088` | 12 |

Only after owner authorization of this read-only session and confirming section
1, run the explicit live mode. Both inputs below are nonsecret labels.

```powershell
$Service = Read-Host 'Existing approved direct libpq service name'
$Operator = Read-Host 'Approved metadata operator LOGIN role name'
.\Invoke-PhaseCReadOnly.ps1 -Repository $Repo -RunOwnerPreflight -ServiceName $Service -OperatorRole $Operator
```

The script repeats source and integrity checks, then asks for the exact confirmed
deployment ID. Review the displayed prompt before entering it. One psql
connection uses `-X -w`, explicit TLS `verify-full`, a read-only transaction
default, bounded statement and lock timeouts, and `ON_ERROR_STOP`. It checks the
database, operator `current_user` and `session_user`, PostgreSQL version and
server TLS. The approved direct service retains its private auth and CA settings.
Keep credentials out of command arguments. If existing authentication or CA
verification fails, stop and resolve through the owner without changing access.

The driver uses the same backend through both reviewed SQL files and sets
`physcratic.audit_contract='batch-a'` for this session. Each file opens its own
read-only transaction. The wrapper requires psql exit zero, the three successful
SQL guard rows, and the final completion marker in order. The driver also reads the ledger, checks the validated
0021 constraint shape, and measures table-level and column-level ACLs. The
report shows selected catalog metadata and findings. Raw psql output, passwords,
tokens, migration operator details, RLS expressions and arbitrary routine
configuration values are withheld. The only configuration change is the
temporary audit selector in that psql session.

## 3. Read the verdict and smallest delta

- **Ledger:** require verified `0001`–`0018` against the canonical manifest and
  their originally accepted source provenance. Also require exactly one
  verified `0021_arena_favourite_key_pattern` at source
  `5e929d7ff8c4cc93b0755fcf3c968396caed54b8`, UP SHA-256
  `fdb797a3dcc604055f6a89bd9f27b252a6ef38a1a2887c5f044717d184cb3bc3`, and the
  validated reviewed CHECK. Expect 19 rows and absence of `0020`. Treat
  `0019` or other unreviewed entries as evidence to reconcile. The 18-row
  comment within the older audit predates 0021. The SELECT is unchanged.
- **Batch A:** require zero final verifier rows, all 11 favourites checks,
  no invalid constraints or indexes or disabled triggers, and the exact
  authored UPDATE allowlist `published_revision_id,state,updated_at`. Require
  effective UPDATE on `id` and table-wide UPDATE both false. Compare owners,
  runtime attributes and memberships, PUBLIC and default ACLs, RLS and routine
  path evidence to the accepted contract. Keep existing compatible
  CONNECT/TEMP and the canonical PUBLIC exact-row guard EXECUTE. Review any
  withheld or unfamiliar metadata through the approved private evidence.
- **PASS:** the automated baseline is clean, all six profile rights are absent, and the owner verifies original
  ledger provenance and each catalog inventory. No Phase C correction is
  needed. The smallest reviewed B1 delta is table-level SELECT, INSERT and UPDATE on each of
  `community_profile` and `community_profile_write_limit`. Schema USAGE
  already exists. This is a finding for separate approval.
- **FAIL:** any confirmed ledger, ownership, ACL, constraint or permission drift.
  A profile right already present is outside the current `batch-a` contract.
  With all six already present there is no missing profile right. With a mixed
  or column-only result, use the six-row report to identify the individual gaps
  after independent reconciliation. Do not replay a broad grant or the old
  revoke. If `UPDATE(id)` reappears, determine whether the path is direct,
  table-wide, PUBLIC or inherited before proposing any correction.
- **UNKNOWN:** missing control-plane, TLS, identity, provenance or inventory
  evidence, a nonzero psql exit, timeout, or unreadable report. Stop without
  drawing a permission conclusion. A zero psql exit alone does not convert
  returned findings into a pass.

The preflight reads catalog metadata only. It performs no live HTTP test, grant,
revoke, migration, publication, deployment or flag action. The latest collection
change can omit images when restriction metadata is unreadable. That behavior is
outside the B1 delta and supplies no authority to expand the current audit
contract.

## Review revision

This release-specific package keeps the prior package intact. The PowerShell
driver pins current main, the live deployment and CI. It requires positive
identity, contract and final session guard output. The profile check now blocks
final PASS before the owner review if any of the six rights are already present.
The driver SQL and approved repository SQL retain their original bytes.

## Local verification

- PowerShell parser and fixture tests passed on PowerShell 7.6. Native Windows
  PowerShell 5.1 execution was unavailable. The commands use 5.1 syntax and
  cmdlets.
- The integrity-only entry point passed with an offline Git mirror and CI
  metadata fixture. Wrong source, dirty checkout, CI failure and changed
  driver bytes stopped. The original package remains byte-identical.
- Extracted code sections passed four input rejection cases and 18 report
  cases. These included a nonzero native exit with a completion marker,
  missing or false guard proof, malformed completion, profile and authored
  privilege drift, ledger drift, verifier findings, manual rejection and
  output masking. Every negative report terminated without final PASS.
- PostgreSQL 18 parsing confirmed read-only SQL and the approved session
  settings in the driver and both included audits. An isolated PG18.7
  native psql test returned exit 3 on a server SQL error and never reached
  the completion marker. A local libpq test verified the read-only startup
  default and that the explicit empty hostaddr clears an inherited address.

The owner-only switch was never invoked. The current deployment, exact CI,
role continuity evidence, effective flags and approved service must still
match before the owner connects. After the catalog and provenance review,
accept only the final line
`PASS. Current batch-a contract. No ACL correction needed.`
with zero verifier findings and all six profile rights absent. A terminating
error or missing final PASS ends the preflight.
