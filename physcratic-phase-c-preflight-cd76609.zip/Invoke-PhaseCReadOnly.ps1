#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Repository,
    [switch]$RunOwnerPreflight,
    [string]$ServiceName,
    [string]$OperatorRole
)

$ErrorActionPreference = 'Stop'
$Release = 'cd766099586d3935e9b6e1e427181cc8be5f8f85'
$Deployment = 'dpl_2Lm7mcuKVpwA3a7G7xnRSVoGbWMm'
$CIRun = '44579380708'
$RuntimeRole = 'physcratic_runtime_app'
$Endpoint = 'ep-snowy-heart-b7c1220y.c-13.us-east-1.aws.neon.tech'
$Driver = Join-Path $PSScriptRoot 'phase-c-readonly.sql'
$Migration21 = '0021_arena_favourite_key_pattern'
$Migration21Hash = 'fdb797a3dcc604055f6a89bd9f27b252a6ef38a1a2887c5f044717d184cb3bc3'
$Migration21Source = '5e929d7ff8c4cc93b0755fcf3c968396caed54b8'
$LedgerManifest = 'scripts/production-upgrade/migrations.json'

function Assert-Sha256([string]$Path, [string]$Expected) {
    if ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Expected) {
        throw "FAIL. SHA-256 mismatch for $Path"
    }
}

function Test-Manifest([string]$Path, [string]$Hash, [int]$Entries) {
    Assert-Sha256 $Path $Hash
    $lines = @(Get-Content -LiteralPath $Path)
    if ($lines.Count -ne $Entries) { throw 'FAIL. Manifest entry count changed.' }
    foreach ($line in $lines) {
        if ($line -cnotmatch '^([a-f0-9]{64})  ([A-Za-z0-9_./-]+)$') { throw 'FAIL. Unexpected manifest syntax.' }
        $digest = $Matches[1]
        $file = $Matches[2]
        Assert-Sha256 $file $digest
    }
    Write-Host "PASS. $Path ($Entries entries)."
}

function Find-Line([string[]]$Lines, [string]$Marker) {
    $positions = @(for ($i = 0; $i -lt $Lines.Count; $i++) {
        if ($Lines[$i] -ceq $Marker) { $i }
    })
    if ($positions.Count -ne 1) { throw 'UNKNOWN. Expected audit boundary missing or duplicated.' }
    return $positions[0]
}

function Between([string[]]$Lines, [string]$Start, [string]$End) {
    $first = Find-Line $Lines $Start
    $last = Find-Line $Lines $End
    if ($last -le $first) { throw 'UNKNOWN. Audit boundaries out of order.' }
    if ($last -gt ($first + 1)) { $Lines[($first+1)..($last-1)] }
}

function Convert-AuditCsv([string[]]$Lines) {
    if ($Lines.Count -lt 1) { throw 'UNKNOWN. Empty audit section.' }
    try {
        ConvertFrom-Csv -InputObject ($Lines -join "`n") -ErrorAction Stop -WarningAction Stop
    } catch {
        throw 'UNKNOWN. Could not parse the catalog report.'
    }
}

# This returns only a fixed search_path string of ordinary identifiers, never
# arbitrary routine settings. The owner still reviews order and trusted schemas.
function Safe-SearchPath([string]$Config) {
    if ($Config -ceq 'UNKNOWN' -or $Config -ceq '' -or $Config -ceq '{}') { return '(unset)' }
    if ($Config -cmatch '^\{"?search_path=([A-Za-z_][A-Za-z0-9_]*(?:, ?[A-Za-z_][A-Za-z0-9_]*)*)"?\}$') {
        return $Matches[1]
    }
    return '(other settings withheld; review required)'
}

Push-Location -LiteralPath $Repository
try {
    $git = @(Get-Command git -CommandType Application -ErrorAction Stop)[0].Source
    & $git fetch origin main *> $null
    if ($LASTEXITCODE -ne 0) { throw 'UNKNOWN. Could not refresh origin/main.' }
    foreach ($ref in @('HEAD','origin/main','FETCH_HEAD')) {
        $actual = & $git rev-parse --verify $ref 2>$null
        if ($LASTEXITCODE -ne 0 -or $actual -cne $Release) { throw 'STOP. Source advanced or the checkout is not the pinned release.' }
    }
    $dirty = @(& $git status --porcelain --untracked-files=normal 2>$null)
    if ($LASTEXITCODE -ne 0 -or $dirty.Count -ne 0) { throw 'STOP. Use a clean LF checkout of the pinned release.' }
    try {
        $run = Invoke-RestMethod -UseBasicParsing -Uri "https://api.github.com/repos/Physcratic/physcratic/actions/runs/$CIRun"
        $jobs = Invoke-RestMethod -UseBasicParsing -Uri "https://api.github.com/repos/Physcratic/physcratic/actions/runs/$CIRun/jobs?per_page=20"
    } catch { throw 'UNKNOWN. Could not verify CI through GitHub.' }
    if ($run.head_sha -cne $Release -or $run.head_branch -cne 'main' -or $run.event -cne 'push' -or
        $run.name -cne 'CI' -or $run.status -cne 'completed' -or $run.conclusion -cne 'success' -or
        @($jobs.jobs).Count -ne 3 -or @($jobs.jobs | Where-Object { $_.head_sha -cne $Release -or $_.conclusion -cne 'success' }).Count -ne 0) {
        throw 'STOP. Exact-main CI is not verified successful.'
    }
    Write-Host "PASS. Exact main and CI $CIRun."
    Test-Manifest 'scripts/activation/PACKAGE_SHA256SUMS' 'fa6fb4ebce76b3ca674640fa61b807f1ba1e1b7ea4a1d9d4d6e8a6bbcf48de6b' 23
    Test-Manifest 'scripts/runtime-role/PACKAGE_SHA256SUMS' '1eb029de161d636903173c15a9337beefef954ebd46102505abcac9433b9e088' 12
    Assert-Sha256 'scripts/activation/revoke-authored-problem-id.review.sql' 'dcec5ac29b8a363fc2fd42742ffb7fce89e0a45522e4ffb25a505b5cfc7e28d2'
    Assert-Sha256 'scripts/activation/profiles-grants.review.sql' 'ec8b59b652501014ec3f390b8fab7865ab51ecfa17581b68ff5b96c14215a1bd'
    Assert-Sha256 $LedgerManifest 'f8c75f4c83797153230d2577e8ab24e0848bb8492321aa1edd2e6ec663b30493'
    Assert-Sha256 'migrations/0021_arena_favourite_key_pattern.up.sql' $Migration21Hash
    Assert-Sha256 $Driver 'be4712f5621dcc66b4cfe45620ea2eb05ff72735a707c99c2ca0a7fce98c1a0a'
    Write-Host 'PASS. Approved SQL artifacts and read-only driver hashes.'
    if (-not $RunOwnerPreflight) { return }

    if ($ServiceName -cnotmatch '^[A-Za-z0-9_.-]{1,80}$' -or
        $OperatorRole -cnotmatch '^[A-Za-z_][A-Za-z0-9_]{0,62}$' -or
        $OperatorRole -ceq $RuntimeRole) {
        throw 'STOP. Supply the approved direct libpq service name and metadata operator role.'
    }
    Write-Host 'Complete the private Vercel, Neon, binding, flags, and recovery checks in the runbook.'
    $decision = Read-Host 'After separate owner approval of this read-only session, enter the verified serving deployment ID'
    if ($decision -cne $Deployment) { throw 'UNKNOWN. Owner control-plane confirmation is missing or different.' }

    $psql = @(Get-Command psql -CommandType Application -ErrorAction Stop)[0].Source
    $conn = "service=$ServiceName host=$Endpoint hostaddr='' port=5432 dbname=neondb user=$OperatorRole sslmode=verify-full gssencmode=disable connect_timeout=5 options='-c default_transaction_read_only=on -c statement_timeout=10000 -c lock_timeout=1000 -c search_path=pg_catalog,public'"
    # No password is passed. Keep raw catalogs and diagnostics off the console.
    try {
        $raw = @(& $psql -X -w -q --csv -P footer=off -P null=UNKNOWN -v ON_ERROR_STOP=1 -v "operator_role=$OperatorRole" -v "runtime_role=$RuntimeRole" -d $conn -f $Driver 2>$null)
        $psqlExit = $LASTEXITCODE
    } catch {
        throw 'UNKNOWN. psql failed. Stop and review privately.'
    }
    if ($psqlExit -ne 0) {
        throw 'UNKNOWN. psql returned a nonzero exit code. Stop and review privately.'
    }
    $identity = @(Between (@('PHASE_C_START') + $raw) 'PHASE_C_START' 'PHASE_C_LEDGER')
    $contract = @(Between $raw 'PHASE_C_PROFILES_END' 'PHASE_C_ACTIVATION')
    $final = @(Between $raw 'PHASE_C_VERIFIER_END' 'PHASE_C_COMPLETE')
    $completion = Find-Line $raw 'PHASE_C_COMPLETE'
    if ($identity.Count -ne 2 -or $identity[0] -cne 'identity_guard' -or $identity[1] -cne '1' -or
        $contract.Count -ne 2 -or $contract[0] -cne 'contract_guard' -or $contract[1] -cne '1' -or
        $final.Count -ne 2 -or $final[0] -cne 'final_session_guard' -or $final[1] -cne '1' -or
        $completion -ne ($raw.Count - 1)) {
        throw 'UNKNOWN. Expected identity, contract, final session, or completion proof failed.'
    }
    Write-Host 'PASS. Approved metadata LOGIN, direct verify-full TLS, PostgreSQL 18.7, read-only default and same-session batch-a.'
    $ledger = @(Convert-AuditCsv @(Between $raw 'PHASE_C_LEDGER' 'PHASE_C_CONSTRAINT'))
    $constraint = @(Convert-AuditCsv @(Between $raw 'PHASE_C_CONSTRAINT' 'PHASE_C_AUTHORED'))
    $authored = @(Convert-AuditCsv @(Between $raw 'PHASE_C_AUTHORED' 'PHASE_C_PROFILES'))
    $profiles = @(Convert-AuditCsv @(Between $raw 'PHASE_C_PROFILES' 'PHASE_C_PROFILES_END'))
    $activation = @(Between $raw 'PHASE_C_ACTIVATION' 'PHASE_C_VERIFIER')
    $verifier = @(Between $raw 'PHASE_C_VERIFIER' 'PHASE_C_VERIFIER_END')

    $expected = @((Get-Content -LiteralPath $LedgerManifest -Raw | ConvertFrom-Json))
    $expected += [pscustomobject]@{ id = $Migration21; sha256 = $Migration21Hash }
    $ledgerOK = $ledger.Count -eq $expected.Count
    foreach ($entry in $expected) {
        $matchesId = @($ledger | Where-Object { $_.id -ceq $entry.id })
        if ($matchesId.Count -ne 1 -or $matchesId[0].sha256 -cne $entry.sha256 -or
            $matchesId[0].result -cne 'verified' -or $matchesId[0].source_commit -cnotmatch '^[a-f0-9]{40}$') {
            $ledgerOK = $false
        }
    }
    $row21 = @($ledger | Where-Object { $_.id -ceq $Migration21 })
    $ledgerOK = $ledgerOK -and $row21.Count -eq 1 -and $row21[0].source_commit -ceq $Migration21Source
    $constraintOK = $constraint.Count -eq 1 -and $constraint[0].validated -ceq 't' -and $constraint[0].matches -ceq 't'
    Write-Host "Ledger IDs, hashes, verified results and 0021 source match: $ledgerOK"
    Write-Host "0021 enforced CHECK definition and validation match: $constraintOK"
    # Strict format check above keeps unexpected ledger text out of output.
    if ($ledgerOK) { $ledger | Select-Object id,source_commit | Format-Table -AutoSize }

    $authoredOK = $authored.Count -eq 1 -and $authored[0].table_update -ceq 'f' -and
        $authored[0].id_update -ceq 'f' -and $authored[0].row_lock_available -ceq 't' -and
        $authored[0].update_columns -ceq 'published_revision_id,state,updated_at'
    Write-Host "Authored UPDATE allowlist and app row-lock rights match: $authoredOK"
    if ($authored.Count -eq 1) {
        $authored | Select-Object table_update,id_update,row_lock_available | Format-Table -AutoSize
    }

    if ($profiles.Count -ne 6) { throw 'UNKNOWN. Six profile rights were not reported.' }
    $profileOK = $true
    foreach ($relation in @('community_profile','community_profile_write_limit')) {
        foreach ($privilege in @('SELECT','INSERT','UPDATE')) {
            $rows = @($profiles | Where-Object { $_.relation -ceq $relation -and $_.privilege -ceq $privilege })
            if ($rows.Count -ne 1 -or $rows[0].object_present -cne 't' -or
                $rows[0].table_allowed -cnotmatch '^[tf]$' -or $rows[0].any_column_allowed -cnotmatch '^[tf]$') {
                $profileOK = $false
            }
        }
    }
    $profilesAbsent = $false
    if ($profileOK) {
        $profiles | Format-Table -AutoSize
        $whollyAbsent = @($profiles | Where-Object { $_.table_allowed -ceq 'f' -and $_.any_column_allowed -ceq 'f' })
        $partial = @($profiles | Where-Object { $_.table_allowed -ceq 'f' -and $_.any_column_allowed -ceq 't' })
        Write-Host "Profile rights wholly absent: $($whollyAbsent.Count). Column-only cases requiring review: $($partial.Count)."
        $profilesAbsent = $whollyAbsent.Count -eq 6
    }

    $privHeader = 'feature,relation_name,privilege,object_present,allowed,privilege_state'
    $favTable = @($privHeader) + @(Between $activation $privHeader 'verified_user_id_read,verified_user_status_read,authored_row_lock_permission')
    $fav = @(Convert-AuditCsv $favTable | Where-Object { $_.feature -ceq 'favourites' })
    $favouritesOK = $fav.Count -eq 11 -and @($fav | Where-Object { $_.object_present -cne 't' -or $_.allowed -cne 't' }).Count -eq 0
    $integrityFindings = @()
    $integrityFindings += @(Between $activation 'relation,conname' 'index_name,indisvalid,indisready')
    $integrityFindings += @(Between $activation 'index_name,indisvalid,indisready' 'relation,tgname,tgenabled')
    $integrityFindings += @(Between $activation 'relation,tgname,tgenabled' 'rolname,rolsuper,rolcreaterole,rolcreatedb,rolbypassrls,schema_usage,schema_create')
    $findingHeader = 'kind,object,detail'
    $findingStart = Find-Line $verifier $findingHeader
    $findings = @(Convert-AuditCsv $verifier[$findingStart..($verifier.Count-1)])

    # Show only nonsecret ACL/ownership metadata. RLS expressions, arbitrary
    # routine settings, migration operators, and raw output stay off the console.
    $rel = 'nspname,relname,relkind,owner,relacl,relrowsecurity,relforcerowsecurity'
    $pol = 'relation,polname,polcmd,polroles,using_expression,check_expression'
    $acl = 'defaclrole,defaclnamespace,defaclobjtype,defaclacl'
    $db = 'datname,datdba,datacl'
    $schema = 'nspname,nspowner,nspacl'
    $fun = 'routine,owner,prosecdef,proconfig,proacl,executable'
    foreach ($section in @(
        @{ Start = 'member_of'; End = $rel },
        @{ Start = $rel; End = $pol },
        @{ Start = $acl; End = $db },
        @{ Start = $db; End = $schema },
        @{ Start = $schema; End = $fun }
    )) {
        Convert-AuditCsv (@($section.Start) + @(Between $verifier $section.Start $section.End)) | Format-Table -AutoSize -Wrap
    }
    Convert-AuditCsv (@($pol) + @(Between $verifier $pol $acl)) |
        Select-Object relation,polname,polcmd,polroles | Format-Table -AutoSize -Wrap
    $publicRoutine = 'routine,owner,security_definer,proconfig,proacl,runtime_execute,public_execute'
    $activationDefault = 'creator,schema,defaclobjtype,defaclacl'
    Convert-AuditCsv (@($publicRoutine) + @(Between $activation $publicRoutine $activationDefault)) |
        Select-Object routine,owner,security_definer,runtime_execute,public_execute |
        Format-Table -AutoSize -Wrap
    Convert-AuditCsv (@($fun) + @(Between $verifier $fun $findingHeader)) |
        Select-Object routine,owner,prosecdef,proacl,executable,@{Name='search_path';Expression={ Safe-SearchPath $_.proconfig }} |
        Format-Table -AutoSize -Wrap

    Write-Host "Favourites checks pass: $favouritesOK"
    Write-Host "Invalid constraints, invalid indexes, or disabled triggers: $($integrityFindings.Count)"
    Write-Host "Final batch-a verifier findings: $($findings.Count)"
    if ($findings.Count -gt 0) { $findings | Select-Object kind,object,detail | Format-Table -AutoSize -Wrap }

    $baselineOK = $ledgerOK -and $constraintOK -and $authoredOK -and $profilesAbsent -and $favouritesOK -and
        $integrityFindings.Count -eq 0 -and $findings.Count -eq 0
    if (-not $baselineOK) {
        throw 'FAIL. Baseline, ledger, or privilege drift. Stop for owner reconciliation.'
    }
    $ownerReview = Read-Host 'After comparing historical ledger provenance and the ownership, PUBLIC, default ACL, RLS and routine inventories, enter PASS, FAIL, or UNKNOWN'
    if ($ownerReview -ceq 'FAIL') { throw 'FAIL. Manual provenance or catalog review found drift.' }
    if ($ownerReview -cne 'PASS') { throw 'UNKNOWN. Manual provenance or catalog review incomplete.' }
    Write-Host 'PASS. Current batch-a contract. No ACL correction needed.'
    Write-Host 'B1 delta for separate review only. Six missing table rights: SELECT, INSERT, UPDATE on each profile table. Existing public schema USAGE is covered by batch-a.'
} finally {
    $raw = $null
    Pop-Location
}
