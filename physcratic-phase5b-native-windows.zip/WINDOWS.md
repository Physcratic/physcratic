# Phase 5B native Windows fixture

26 November 2026, Singapore. This packet uses the existing Windows PostgreSQL 18.7 server binaries to start a separate loopback cluster. It uses Git, Node 22 and pnpm 10. It has no Docker requirement. Use a normal PowerShell window and a folder under your Windows profile.

## 1. Extract and prepare a clean checkout

Save the ZIP to Downloads. Extract into a new directory. Use an existing clean checkout of the reviewed commit if available. Otherwise use the clone below. Keep both .env files and cloud credentials out of the checkout.

~~~powershell
$Kit = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Kit'
$Zip = Join-Path $env:USERPROFILE 'Downloads\physcratic-phase5b-native-windows.zip'
Expand-Archive -LiteralPath $Zip -DestinationPath $Kit

$Repo = Join-Path $env:USERPROFILE 'physcratic-phase5b'
if (-not (Test-Path -LiteralPath $Repo)) {
    git clone --no-checkout https://github.com/Physcratic/physcratic.git $Repo
    if ($LASTEXITCODE -ne 0) { throw 'Clone failed' }
    git -C $Repo checkout --detach 02f09e0ce449c96d4da0d9dc36b27c3455db7766
    if ($LASTEXITCODE -ne 0) { throw 'Reviewed checkout not available' }
}
git -C $Repo rev-parse HEAD
git -C $Repo status --porcelain
pnpm --dir $Repo install --frozen-lockfile
if ($LASTEXITCODE -ne 0) { throw 'Dependency install failed' }
~~~

Expect the exact SHA above or the already reviewed local restore branch at d0293333a56ce126982de5ac220a6730a6a64e69, and no status lines. If an existing checkout differs, choose a fresh folder instead of replacing it. If your Windows download flags prevent running the script, verify the downloaded file by its SHA-256 and unblock just that reviewed file with Unblock-File. Keep the system execution policy as it is.

## 2. Initialize and seed

~~~powershell
$Cluster = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB'
$Runner = Join-Path $Kit 'Invoke-Phase5bNative.ps1'
& $Runner -Action Prepare -Repo $Repo -ClusterRoot $Cluster -Port 55439 -AppPort 3317
~~~

Expected final lines:

~~~text
Fixture=ready (A, B, two synthetic admins, one database-only held object)
DedicatedLogins=verified (runtime, eraser, operator)
Migration0025=absent
Database=127.0.0.1:55439/physcratic_authoring_test
~~~

The wrapper requires a new data directory and free ports. It runs initdb with SCRAM and a fresh random local cluster password. It runs pg_ctl with that exact data directory and postgres options -h 127.0.0.1 -p 55439. The fixture helper independently checks the server address, port, version, LOGIN and data directory before writing. If the port is occupied, select another unused port in 49152–65535, leaving the original service alone. If setup fails after creating the directory, preserve its postgres.log, stop the named fixture if it started, and use a fresh directory for any retry. Keep fixture-state.json private.

The script uses the repository's pre-authoring fixture shape and applies the needed migrations through 0026 with 0025 skipped. It creates a non-login owner and three SCRAM LOGINs, phase5b_runtime, phase5b_eraser and phase5b_operator, then verifies their distinct execution and protected-table privileges. The two app service pools use the dedicated LOGINs. Use a second fresh cluster root and the -IncludeCompletions switch on Prepare only if you later want the separate combined fixture. In that fixture, A and B start with one mark and limiter row each. There is no migration ledger or grant operation on the existing service.

## 3. Start the loopback app

~~~powershell
& $Runner -Action StartApp -ClusterRoot $Cluster
~~~

Keep that window open. Expect App=http://localhost:3317/sign-in followed by Next.js Ready. Open that exact URL. The launcher sets an explicit local environment, uses the three localhost database URLs and keeps email in memory. It loads no Production .env file, cloud credentials or provider binding.

| Synthetic login | Password |
| --- | --- |
| phase5b-a@example.invalid | Phase5B-local-a-only! |
| phase5b-b@example.invalid | Phase5B-local-b-only! |
| phase5b-admin1@example.invalid | Phase5B-local-admin1-only! |
| phase5b-admin2@example.invalid | Phase5B-local-admin2-only! |

Sign in as A and confirm Settings shows Delete account. Stop at that screen for this step. The two synthetic admin users are fixture identities. Real backup and reviewer assignments are still pending. The held path is a database-only fixture and provides no provider-cleanup evidence.

## 4. Stop only the disposable processes

Press Ctrl+C in the app window. Then run this with the cluster path from step 2:

~~~powershell
& $Runner -Action Stop -ClusterRoot $Cluster
~~~

Expect server stopped. The script leaves the fixture files for review and leaves the existing Windows PostgreSQL service alone.

## Verification

The PowerShell runner and Node helper were exercised on Linux with native PostgreSQL 18.7. The tests initialized fresh clusters with and without 0025, verified the three distinct LOGINs, and used the real loopback app to sign in, erase A with one held job still pending, confirm cleanup skipped the held job, and verify B could still sign in. Native Windows execution remains to be confirmed. No provider or Tally calls were used.
