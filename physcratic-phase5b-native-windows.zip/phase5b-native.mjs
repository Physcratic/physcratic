import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { readFile, readdir, realpath } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';

const [action, statePath] = process.argv.slice(2);
const { repo, data, port, appPort, secrets, withCompletions } = JSON.parse(await readFile(statePath, 'utf8'));
const database = 'physcratic_authoring_test';
const host = '127.0.0.1';
const admin = 'phase5b_cluster_admin';
const roles = { runtime: 'phase5b_runtime', eraser: 'phase5b_eraser', operator: 'phase5b_operator' };
const requireFromRepo = createRequire(join(repo, 'package.json'));
const { Client } = requireFromRepo('pg');
const connection = (role, password, db = database) => new Client({
  host, port, database: db, user: role, password, ssl: false, connectionTimeoutMillis: 4000,
  statement_timeout: 30_000,
});
const read = file => readFile(join(repo, file), 'utf8');
const quote = value => "'" + value.replaceAll("'", "''") + "'";

assert.ok(Number.isInteger(port) && port >= 49152 && port <= 65535 && port !== appPort);
assert.ok(Number.isInteger(appPort) && appPort >= 1024 && appPort <= 65535);
assert.ok(Object.values(secrets).every(secret => /^[0-9a-f]{64}$/.test(secret)));

async function identify(client, db, login, checkDirectory = false) {
  const { rows: [identity] } = await client.query(
    "SELECT current_database() AS db, session_user AS login, current_user AS effective, host(inet_server_addr()) AS host, inet_server_port() AS port, current_setting('server_version_num') AS version",
  );
  assert.deepEqual(identity, { db, login, effective: login, host, port, version: '180007' });
  if (checkDirectory) {
    const { rows: [setting] } = await client.query('SHOW data_directory');
    assert.equal(await realpath(setting.data_directory), await realpath(data));
  }
}

async function use(client, handler) {
  await client.connect();
  try { return await handler(client); } finally { await client.end(); }
}

async function verifyRoles() {
  const names = [
    'account_deletion_charge(text,text,boolean)',
    'account_deletion_receipt(text)',
    'account_deletion_open_request(text,text,text,text)',
    'account_deletion_execute(text,text,text,text)',
    'account_deletion_evidence_control(text,text,text,text,jsonb)',
    'account_deletion_cleanup(text,text,text,text,jsonb)',
    'account_deletion_upload_finished(text,text,text)',
  ];
  const expectations = { runtime: [7], eraser: [1, 2, 3, 4], operator: [1, 5, 6] };
  for (const [key, role] of Object.entries(roles)) {
    await use(connection(role, secrets[key]), async client => {
      await identify(client, database, role);
      const { rows: [rights] } = await client.query(
        "SELECT ARRAY(SELECT n::int FROM unnest($1::text[]) WITH ORDINALITY AS t(sig,n) WHERE has_function_privilege('public.' || sig, 'EXECUTE') ORDER BY n) AS allowed, has_table_privilege('public.account_deletion_outbox','SELECT,INSERT,UPDATE,DELETE') AS outbox, has_schema_privilege('public','CREATE') AS ddl",
        [names],
      );
      assert.deepEqual(rights, { allowed: expectations[key], outbox: false, ddl: false });
    });
  }
}

async function prepare() {
  await use(connection(admin, secrets.admin, 'postgres'), async client => {
    await identify(client, 'postgres', admin, true);
    const { rowCount } = await client.query('SELECT 1 FROM pg_database WHERE datname=$1', [database]);
    assert.equal(rowCount, 0, 'Fixture database already exists');
    await client.query('CREATE ROLE phase5b_owner NOLOGIN');
    await client.query('CREATE DATABASE physcratic_authoring_test OWNER phase5b_owner');
    await client.query('REVOKE CONNECT, TEMP ON DATABASE physcratic_authoring_test FROM PUBLIC');
  });

  await use(connection(admin, secrets.admin), async client => {
    await identify(client, database, admin, true);
    const { fixtureDDL } = await import(pathToFileURL(join(repo, 'scripts/authoring-release-production/package/test-fixture.mjs')));
    const { hashPassword } = await import(pathToFileURL(requireFromRepo.resolve('better-auth/crypto')));
    await client.query('SET ROLE phase5b_owner; SET search_path=public,pg_catalog; REVOKE CREATE ON SCHEMA public FROM PUBLIC');
    await client.query(fixtureDDL().join(';\n') + ';');
    await client.query(await read('migrations/20261031_auth_rate_limit.sql'));
    const files = (await readdir(join(repo, 'migrations'))).filter(file => /^00[012]\d_.+\.up\.sql$/.test(file)).sort();
    const selected = files.filter(file => withCompletions || !file.startsWith('0025_'));
    assert.deepEqual(selected.map(file => Number(file.slice(0, 4))),
      Array.from({ length: 26 }, (_, i) => i + 1).filter(i => withCompletions || i !== 25));
    for (const file of selected) {
      const sql = await read('migrations/' + file);
      await client.query(/^BEGIN;/m.test(sql) ? sql : 'BEGIN;\n' + sql + '\nCOMMIT;');
    }

    await client.query("INSERT INTO account_deletion_policy VALUES(true,true,'Synthetic erasure','Synthetic policy','Synthetic owner','Synthetic access','Synthetic review','Synthetic disposal',interval '1 day',interval '2 days',interval '1 day',interval '1 day','WINDOWS-TEST-ONLY',clock_timestamp())");
    for (const label of ['a', 'b', 'admin1', 'admin2']) {
      const id = 'synthetic-phase5b-' + label;
      await client.query('INSERT INTO "user"(id,name,email,"emailVerified","termsAcceptedVersion","termsAcceptedAt") VALUES($1,$2,$3,true,$4,now())',
        [id, 'Synthetic ' + label, 'phase5b-' + label + '@example.invalid', '2026-10-30-draft-1']);
      await client.query('INSERT INTO account(id,"accountId","providerId","userId",password) VALUES($1,$2,\'credential\',$2,$3)',
        ['credential-' + id, id, await hashPassword('Phase5B-local-' + label + '-only!')]);
      if (label.startsWith('admin')) {
        await client.query("INSERT INTO community_staff(user_id,role,reason) VALUES($1,'admin','Synthetic operator fixture')", [id]);
      }
    }
    // DB-only held path. There is no provider object or cloud credential in this fixture.
    await client.query("INSERT INTO solution_evidence(id,\"userId\",pathname,filename,\"mediaType\",bytes,sha256) VALUES(gen_random_uuid(),'synthetic-phase5b-a','solution-evidence/synthetic-phase5b/held-demo.png','held-demo.png','image/png',1,repeat('a',64))");
    if (withCompletions) {
      await client.query("INSERT INTO personal_problem_completion(user_id,problem_key) VALUES('synthetic-phase5b-a','arena:arena-mind-the-gap'),('synthetic-phase5b-b','arena:arena-mind-the-gap')");
      await client.query("INSERT INTO personal_completion_write_limit(user_id,window_start,requests) VALUES('synthetic-phase5b-a',now(),1),('synthetic-phase5b-b',now(),1)");
    }

    await client.query('RESET ROLE');
    const runtimeFile = await read('scripts/runtime-role/provision.review.sql');
    await client.query(runtimeFile.replaceAll(':"runtime_role"', roles.runtime)
      .replaceAll(':\'runtime_role\'', quote(roles.runtime))
      .replaceAll(':"database_name"', database)
      .replaceAll(':\'database_name\'', quote(database)));
    for (const key of ['eraser', 'operator']) {
      await client.query('CREATE ROLE ' + roles[key] + ' LOGIN NOINHERIT');
    }
    for (const [key, name] of Object.entries(roles)) {
      await client.query('ALTER ROLE ' + name + ' PASSWORD ' + quote(secrets[key]));
    }

    await client.query([
      'GRANT CONNECT ON DATABASE physcratic_authoring_test TO phase5b_eraser, phase5b_operator',
      'GRANT USAGE ON SCHEMA public TO phase5b_eraser, phase5b_operator',
      'GRANT EXECUTE ON FUNCTION public.account_deletion_charge(text,text,boolean) TO phase5b_eraser, phase5b_operator',
      'GRANT EXECUTE ON FUNCTION public.account_deletion_receipt(text), public.account_deletion_open_request(text,text,text,text),public.account_deletion_execute(text,text,text,text) TO phase5b_eraser',
      'GRANT EXECUTE ON FUNCTION public.account_deletion_evidence_control(text,text,text,text,jsonb),public.account_deletion_cleanup(text,text,text,text,jsonb) TO phase5b_operator',
      'GRANT EXECUTE ON FUNCTION public.account_deletion_upload_finished(text,text,text) TO phase5b_runtime',
    ].join(';\n'));
    if (withCompletions) {
      const grants = await read('scripts/personal-completions/runtime-grants.review.sql');
      await client.query(grants.replaceAll(':"runtime_role"', roles.runtime));
    }
  });

  await verifyRoles();
  console.log('Fixture=ready (A, B, two synthetic admins, one database-only held object)');
  console.log('DedicatedLogins=verified (runtime, eraser, operator)');
  console.log('Migration0025=' + (withCompletions ? 'included in this fixture only' : 'absent'));
}

async function startApp() {
  await use(connection(admin, secrets.admin), client => identify(client, database, admin, true));
  await verifyRoles();
  const inherited = /^(path|systemroot|windir|comspec|pathext|temp|tmp|userprofile|appdata|localappdata|programfiles(?:\(x86\))?|programdata|home)$/i;
  const env = Object.fromEntries(Object.entries(process.env).filter(([name]) => inherited.test(name)));
  const dsn = key => 'postgresql://' + roles[key] + ':' + secrets[key] + '@' + host + ':' + port + '/' + database;
  Object.assign(env, {
    DATABASE_URL: dsn('runtime'),
    ACCOUNT_DELETION_DATABASE_URL: dsn('eraser'),
    ACCOUNT_DELETION_OPERATOR_DATABASE_URL: dsn('operator'),
    ACCOUNT_DELETION_ENABLED: 'true',
    PERSONAL_COMPLETIONS_ENABLED: withCompletions ? 'true' : 'false',
    BETTER_AUTH_SECRET: secrets.auth,
    BETTER_AUTH_URL: 'http://localhost:' + appPort,
    AUTH_EMAIL_TRANSPORT: 'memory',
    VERCEL_BLOB_RETRIES: '0',
    NEXT_TELEMETRY_DISABLED: '1',
  });

  console.log('App=http://localhost:' + appPort + '/sign-in');
  const child = spawn(process.execPath, [join(repo, 'node_modules/next/dist/bin/next'), 'dev',
    '--hostname', host, '--port', String(appPort)], { cwd: repo, env, stdio: 'inherit' });
  await new Promise((resolve, reject) => {
    child.once('error', reject);
    child.once('exit', (code, signal) => code === 0 || signal === 'SIGINT' ? resolve() : reject(new Error('Local app exited')));
  });
}

if (action === 'prepare') await prepare();
else if (action === 'start') await startApp();
else throw new Error('Unknown local action');
