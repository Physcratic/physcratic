[CmdletBinding()]
param(
    [Parameter(Mandatory)] [ValidateSet('Prepare','StartApp','Stop')] [string] $Action,
    [Parameter(Mandatory)] [string] $ClusterRoot,
    [string] $Repo,
    [ValidateRange(49152,65535)] [int] $Port = 55439,
    [ValidateRange(1024,65535)] [int] $AppPort = 3317,
    [switch] $IncludeCompletions
)

$ErrorActionPreference = 'Stop'
$ClusterRoot = [IO.Path]::GetFullPath($ClusterRoot)
$DataDir = Join-Path $ClusterRoot 'data'
$StatePath = Join-Path $ClusterRoot 'fixture-state.json'
$Helper = Join-Path $PSScriptRoot 'phase5b-native.mjs'
$Node = (Get-Command node -CommandType Application | Select-Object -First 1).Source
$PgCtl = (Get-Command pg_ctl -CommandType Application | Select-Object -First 1).Source
$Utf8 = [Text.UTF8Encoding]::new($false)

function Assert-FreePort([int] $Number) {
    $Listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Number)
    try {
        $Listener.ExclusiveAddressUse = $true
        $Listener.Start()
    } catch {
        throw "Loopback port $Number is in use. Choose a different port."
    } finally {
        $Listener.Stop()
    }
}

function Assert-Candidate([string] $Path) {
    $Head = git -C $Path rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $Head -cnotin @(
        '02f09e0ce449c96d4da0d9dc36b27c3455db7766',
        'd0293333a56ce126982de5ac220a6730a6a64e69'
    )) { throw 'Use the reviewed Phase 5B checkout' }
    $Changes = git -C $Path status --porcelain
    if ($LASTEXITCODE -ne 0 -or $Changes) { throw 'Use a clean separate checkout' }
    $DotEnv = Get-ChildItem -LiteralPath $Path -Force -File |
        Where-Object { $_.Name -match '^\.env(?:$|\.)' -and $_.Name -ne '.env.example' }
    if ($DotEnv) { throw 'Use a separate checkout without .env files' }
    if (-not (Test-Path -LiteralPath (Join-Path $Path 'node_modules/next/dist/bin/next') -PathType Leaf)) {
        throw 'Run pnpm install --frozen-lockfile in the clean fixture checkout first'
    }
}

function New-LocalSecret {
    $Bytes = New-Object byte[] 32
    $Rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    try { $Rng.GetBytes($Bytes) } finally { $Rng.Dispose() }
    [BitConverter]::ToString($Bytes).Replace('-','').ToLowerInvariant()
}

function Invoke-Helper([string] $Phase) {
    & $Node $Helper $Phase $StatePath
    if ($LASTEXITCODE -ne 0) { throw "Local $Phase stopped. Cluster files are in $ClusterRoot" }
}

if ($Action -eq 'Prepare') {
    if (-not $Repo) { throw 'Specify -Repo for Prepare' }
    $Repo = (Resolve-Path -LiteralPath $Repo).Path
    if (Test-Path -LiteralPath $ClusterRoot) { throw 'Choose a new local cluster directory' }
    if ($Port -eq $AppPort) { throw 'Use different database and app ports' }
    if (-not (Test-Path -LiteralPath (Split-Path -Parent $ClusterRoot) -PathType Container)) {
        throw 'Choose a folder whose parent already exists'
    }
    Assert-Candidate $Repo
    Assert-FreePort $Port
    Assert-FreePort $AppPort

    $Initdb = (Get-Command initdb -CommandType Application | Select-Object -First 1).Source
    foreach ($Bin in @($Initdb,$PgCtl)) {
        $Version = & $Bin --version
        if ($LASTEXITCODE -ne 0 -or $Version -notmatch '\(PostgreSQL\) 18\.7(?:\s|$)') {
            throw 'Use the PostgreSQL 18.7 binaries'
        }
    }
    $null = New-Item -Path $ClusterRoot -ItemType Directory
    $State = [ordered]@{
        repo = $Repo
        data = $DataDir
        port = $Port
        appPort = $AppPort
        withCompletions = $IncludeCompletions.IsPresent
        secrets = [ordered]@{
            admin = New-LocalSecret
            runtime = New-LocalSecret
            eraser = New-LocalSecret
            operator = New-LocalSecret
            auth = New-LocalSecret
        }
    }
    [IO.File]::WriteAllText($StatePath, ($State | ConvertTo-Json -Depth 4), $Utf8)
    $PasswordFile = Join-Path $ClusterRoot 'initdb-password.tmp'
    try {
        [IO.File]::WriteAllText($PasswordFile, ($State.secrets.admin + [Environment]::NewLine), $Utf8)
        $InitArgs = @('-D',$DataDir,'-U','phase5b_cluster_admin','--auth=scram-sha-256',
            '--encoding=UTF8','--locale=C','--pwfile',$PasswordFile,'--no-instructions')
        & $Initdb @InitArgs
        if ($LASTEXITCODE -ne 0) { throw 'initdb failed' }
    } finally {
        if (Test-Path -LiteralPath $PasswordFile) { Remove-Item -LiteralPath $PasswordFile }
    }
    & $PgCtl start -D $DataDir -l (Join-Path $ClusterRoot 'postgres.log') -o "-h 127.0.0.1 -p $Port" -w -t 25
    if ($LASTEXITCODE -ne 0) { throw 'Local pg_ctl start failed. Check the fixture postgres.log' }
    Invoke-Helper 'prepare'
    "Database=127.0.0.1:$Port/physcratic_authoring_test"
    "ClusterRoot=$ClusterRoot"
    return
}

$State = Get-Content -Raw -LiteralPath $StatePath -Encoding UTF8 | ConvertFrom-Json
if ([IO.Path]::GetFullPath($State.data) -cne $DataDir) { throw 'Cluster identity file does not match -ClusterRoot' }
if ($Action -eq 'Stop') {
    # pg_ctl targets only the new fixture's datadir. No service operations.
    & $PgCtl stop -D $DataDir -m fast -w -t 25
    if ($LASTEXITCODE -ne 0) { throw 'Local pg_ctl stop did not succeed' }
    return
}
Assert-Candidate $State.repo
Assert-FreePort $State.appPort
Invoke-Helper 'start'
