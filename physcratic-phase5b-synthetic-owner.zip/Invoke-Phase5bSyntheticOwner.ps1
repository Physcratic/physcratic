[CmdletBinding()]
param(
    [Parameter(Mandatory)][ValidateSet('AuthorizeAndRun','Retry')][string]$Action,
    [Parameter(Mandatory)][string]$ClusterRoot,
    [Parameter(Mandatory)][string]$RecoveryKit,
    [string]$EvidenceCollector,
    [string]$AuthorizationSha256
)
$ErrorActionPreference = 'Stop'
$Fresh = (Resolve-Path -LiteralPath $ClusterRoot).Path
$RecoveryKit = (Resolve-Path -LiteralPath $RecoveryKit).Path
$Engine = Join-Path $PSScriptRoot 'reconcile-owner-synthetic.mjs'
$RecordPath = Join-Path $Fresh 'phase5b-synthetic-owner-authorization.json'
$Node = (Get-Command node -CommandType Application | Select-Object -First 1).Source
$DumpHash = 'b9a83f12a27b575c436409af0ee59e5814e55f140151a491a01423f19bfc8ff7'
$ManifestHash = '5ddbc37dd7b90c45542cfd67d87a93f7169ed68718bb7832039b2b412fd3aac6'
$ProposalHash = '3a21fc235e59d637591b8b041de74df32b4f505571afd017bad036b95d040549'
$Receipt = 'c304c5b4-0041-4ae0-8cdc-6dd85c6dc03d'
$Oid = '18420'
$Commit = '02f09e0ce449c96d4da0d9dc36b27c3455db7766'
$Phrase = 'AUTHORIZE SYNTHETIC REPLAY ' + $Oid

function Get-Sha([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}
function Assert-Sha([string]$Path,[string]$Expected) {
    if ((Get-Sha $Path) -cne $Expected) { throw ('Checksum mismatch: ' + (Split-Path -Leaf $Path)) }
}

Assert-Sha $Engine 'c2253337cc337a16aef04721f67abdedb52d99bc95af644575090494e739ad6b'
Assert-Sha (Join-Path $RecoveryKit 'reconcile-native.sql') '80e9216ab6e64fe6bf1e4c683c0fe77f660d109b9dbe75fa973ea0169a87706a'
if ($Action -eq 'AuthorizeAndRun') {
    if (Test-Path -LiteralPath $RecordPath) { throw 'Authorization already exists. Preserve it and use Retry with the original digest if appropriate.' }
    if (-not $EvidenceCollector) { throw 'Supply the reviewed evidence collector from the independent approval kit.' }
    Assert-Sha $EvidenceCollector 'bfbc5394e2f5a22edf436059b497d6564cc9ca4089044b30f2982870a98419de'
    Assert-Sha (Join-Path $RecoveryKit 'Phase5b-Recovery.ps1') 'febee41b7a1ebae6c208d72422f7f7b7a32acb3c5bac2fc942ca6481cbd93e39'
    Assert-Sha (Join-Path $RecoveryKit 'recovery.mjs') 'ebf17681812d7d3aac731fa00985cfa8fe0e945f88d8f9104936eaf201181c35'
    $Proposal = Join-Path $Fresh 'phase5b-recovery-approval.json'
    $Manifest = Join-Path $Fresh 'phase5b-before-a.json'
    Assert-Sha $Proposal $ProposalHash
    Assert-Sha $Manifest $ManifestHash
    Assert-Sha (Join-Path $Fresh 'phase5b-before-a.dump') $DumpHash
    $Plan = Get-Content -Raw -Encoding UTF8 -LiteralPath $Proposal | ConvertFrom-Json
    $FreshJson = (& $EvidenceCollector -ClusterRoot $Fresh -Kit $RecoveryKit) -join [Environment]::NewLine
    $Evidence = $FreshJson | ConvertFrom-Json
    if ($Evidence.result -cne 'READY_FOR_INDEPENDENT_REVIEW' -or
        $Evidence.sourceCommit -cne $Commit -or $Evidence.originalReceipt -cne $Receipt -or
        $Evidence.checkpointSha256 -cne $DumpHash -or $Evidence.checkpointManifestSha256 -cne $ManifestHash -or
        $Evidence.proposalSha256 -cne $ProposalHash -or "$($Evidence.target.databaseOid)" -cne $Oid) {
        throw 'Fresh evidence differs from the independently reviewed rehearsal'
    }

    'FreshVerification=PASS'
    'Target=127.0.0.1:55439/physcratic_restore_test OID=' + $Oid
    'Subject=' + $Plan.subjectId
    'CheckpointSha256=' + $DumpHash
    'SourceReceipt=' + $Receipt
    'HeldPath=' + $Plan.cleanup[0].pathname
    'PublicationApprovals=0'
    $Owner = (Read-Host 'Enter your name as the authorizing owner').Trim()
    if (-not $Owner -or $Owner.Length -gt 100) { throw 'Owner name is required' }
    if ((Read-Host "After reviewing those values, type $Phrase") -cne $Phrase) { throw 'Owner authorization was not given' }
    $Now = [DateTime]::UtcNow
    $Sample = ([DateTimeOffset]$Evidence.sampledUtc).UtcDateTime
    if ($Sample -gt $Now -or ($Now - $Sample).TotalMinutes -gt 5) {
        throw 'Fresh verification expired. Run AuthorizeAndRun again.'
    }
    $Record = [ordered]@{
        kind = 'synthetic-local-owner-authorization-v1'
        owner = $Owner
        approvedAt = $Now.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        expiresAt = $Now.AddMinutes(30).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
        decision = $Phrase
        host = '127.0.0.1'
        port = 55439
        sourceCommit = $Commit
        proposalSha256 = $ProposalHash
        checkpointManifestSha256 = $ManifestHash
        dumpSha256 = $DumpHash
        database = $Plan.database
        databaseOid = $Oid
        deletionRecord = $Receipt
        subjectId = $Plan.subjectId
        subjectFingerprint = $Plan.subjectFingerprint
        publications = @()
        cleanup = @($Plan.cleanup)
        evidence = $FreshJson
    }
    $Payload = [Text.UTF8Encoding]::new($false).GetBytes(($Record | ConvertTo-Json -Depth 8))
    $Stream = [IO.File]::Open($RecordPath, [IO.FileMode]::CreateNew)
    try { $Stream.Write($Payload, 0, $Payload.Length) } finally { $Stream.Dispose() }
    $AuthorizationSha256 = Get-Sha $RecordPath
    "AuthorizationSha256=$AuthorizationSha256"
} else {
    if ($AuthorizationSha256 -cnotmatch '^[a-f0-9]{64}$') { throw 'Supply the original authorization digest printed before replay.' }
    Assert-Sha $RecordPath $AuthorizationSha256
}

$First = & $Node $Engine $Fresh $RecoveryKit $AuthorizationSha256
if ($LASTEXITCODE -ne 0 -or $First -cnotin @(
    'RECONCILED: A absent, B unchanged, Held=1, Pending=1',
    'ALREADY_RECONCILED: A absent, B unchanged, Held=1, Pending=1'
)) { throw 'Reconciliation outcome unconfirmed. Keep the fixture and authorization unchanged.' }
$First
$Repeat = & $Node $Engine $Fresh $RecoveryKit $AuthorizationSha256
if ($LASTEXITCODE -ne 0 -or $Repeat -cne 'ALREADY_RECONCILED: A absent, B unchanged, Held=1, Pending=1') {
    throw 'Repeat outcome unconfirmed. Preserve the original authorization and outputs.'
}
$Repeat
