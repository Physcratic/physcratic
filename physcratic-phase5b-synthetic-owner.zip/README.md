# Phase 5B synthetic owner authorization

This add-on is pinned to the existing native Windows rehearsal. Use Windows PowerShell 5.1 with Next.js stopped. Leave the source, restored database, checkpoint and unsigned proposal in place. PostgreSQL must be running on the existing disposable data directory at 127.0.0.1:55439. Reuse the existing rehearsal kit and independent review evidence collector.

| Item | Pinned value |
| --- | --- |
| Recovery database | physcratic_restore_test, OID 18420 |
| Checkpoint SHA-256 | b9a83f12a27b575c436409af0ee59e5814e55f140151a491a01423f19bfc8ff7 |
| Original synthetic receipt | c304c5b4-0041-4ae0-8cdc-6dd85c6dc03d |
| Subject | synthetic-phase5b-a |
| Sole cleanup path | solution-evidence/synthetic-phase5b/held-demo.png, author, remains held |
| Publication approvals | None |

If the existing disposable PostgreSQL process stopped when Next.js stopped, use the existing pg_ctl recovery steps in OWNER-REVIEW.md from the independent review kit. Never initialize, seed, erase on the source or restore again for this step.

## Verify, authorize and run

Verify the add-on ZIP against the SHA-256 given separately. Extract to a fresh local folder. Run from that folder, using the existing cluster, kit and collector paths below. If the collector is elsewhere, substitute the path where you extracted it from the independent approval kit. The launcher verifies the collector, existing recovery files and new runner against exact hashes.

~~~powershell
$ErrorActionPreference = 'Stop'
$Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
$Kit = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Rehearsal-Kit'
$Collector = Join-Path $env:USERPROFILE 'Downloads\Get-Phase5bReviewEvidence.ps1'
& .\Invoke-Phase5bSyntheticOwner.ps1 -Action AuthorizeAndRun -ClusterRoot $Fresh -RecoveryKit $Kit -EvidenceCollector $Collector
~~~

Expect FreshVerification=PASS and the exact target, subject, archive hash, receipt and held path. Compare them with the table. Enter your name and type AUTHORIZE SYNTHETIC REPLAY 18420 only if they match. You have five minutes from the read-only sample to authorize. The launcher saves a separate 30-minute authorization record with the fresh verification and prints AuthorizationSha256 before replay. The original proposal remains unsigned and byte-for-byte intact.

Expected results:

~~~text
RECONCILED: A absent, B unchanged, Held=1, Pending=1
ALREADY_RECONCILED: A absent, B unchanged, Held=1, Pending=1
~~~

Keep the printed digest and both results in the private dossier. The replay uses the original pinned SQL, including its transaction, schema fingerprint, target isolation and idempotency checks. The wrapper rechecks the live source, recovery target and checkpoint. Both executions compare the live recovery state inside the transaction and ensure upload holds and other outbox rows remain unchanged.

If an acknowledgement is lost, keep the original record and retry with the same digest within its approval window. Leave the app stopped.

~~~powershell
$Sha = (Read-Host 'Original AuthorizationSha256 printed before replay').Trim().ToLowerInvariant()
& .\Invoke-Phase5bSyntheticOwner.ps1 -Action Retry -ClusterRoot $Fresh -RecoveryKit $Kit -AuthorizationSha256 $Sha
~~~

The retry may show RECONCILED if the first transaction did not commit. Its second execution must show ALREADY_RECONCILED. If the window expired or any check fails, preserve the files and seek review. Changing authorization bytes changes the replay nonce.

## Qualification boundary

This records owner authorization for one independently reviewed synthetic fixture. It leaves the original independent approval proposal intact. Production or real-data recovery still requires its original independent human approval, custody, operational authorization, reconciliation and reopening controls. The add-on does not authorize Production changes.

## Test evidence

Tested on a separate native PostgreSQL 18.7 cluster with PowerShell 7 on Linux. The exact delivered pins rejected that other cluster. An otherwise identical scratch copy pinned to the test fixture passed fresh verification, replay, repeat and same-digest retry. It refused a declined confirmation, a granted app connection, changed authorization bytes, a substituted OID and expired authorization. Original checkpoint and proposal hashes stayed unchanged. Windows PowerShell 5.1 execution remains to be confirmed.
