import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFile, realpath } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';

const [dir, recoveryKit, expectedAuthorization] = process.argv.slice(2);
assert.equal(process.argv.length, 5);
const pins = {
  checkpointManifest: '5ddbc37dd7b90c45542cfd67d87a93f7169ed68718bb7832039b2b412fd3aac6',
  proposal: '3a21fc235e59d637591b8b041de74df32b4f505571afd017bad036b95d040549',
  dump: 'b9a83f12a27b575c436409af0ee59e5814e55f140151a491a01423f19bfc8ff7',
  sql: '80e9216ab6e64fe6bf1e4c683c0fe77f660d109b9dbe75fa973ea0169a87706a',
  oid: '18420',
  receipt: 'c304c5b4-0041-4ae0-8cdc-6dd85c6dc03d',
  commit: '02f09e0ce449c96d4da0d9dc36b27c3455db7766',
};
const root = await realpath(resolve(dir));
const state = JSON.parse(await readFile(join(root, 'fixture-state.json'), 'utf8'));
const beforeBytes = await readFile(join(root, 'phase5b-before-a.json'));
const before = JSON.parse(beforeBytes);
const sha = value => createHash('sha256').update(value).digest('hex');
const hex = /^[a-f0-9]{64}$/;
assert.equal(state.port, 55439);
assert.equal(await realpath(state.data), await realpath(join(root, 'data')));
assert.match(state.secrets.admin, hex);
assert.match(before.aFingerprint, hex);
assert.match(before.bFingerprint, hex);
assert.equal(sha(beforeBytes), pins.checkpointManifest, 'Checkpoint manifest differs');
assert.equal(before.withCompletions, true);
assert.equal(state.withCompletions, true);
const dump = join(root, 'phase5b-before-a.dump');
assert.equal(before.dumpSha256, pins.dump, 'Checkpoint hash differs');
assert.equal(sha(await readFile(dump)), pins.dump, 'Checkpoint archive differs');
const pinMigrations = {
  '0018_account_deletion.up.sql': '378ff9140a5eab9d62c70505eb764ad1f621ebe26f6d840c62826aee00d61cda',
  '0026_account_deletion_blockers.up.sql': '3b904c1eb01fc75e5446744acc90474cdbe4aba62c6dffc95b9f7c35bfc6c78a',
};
for (const [name, expected] of Object.entries(pinMigrations)) {
  const sql = (await readFile(join(state.repo, 'migrations', name), 'utf8')).replaceAll('\r\n', '\n');
  assert.equal(sha(sql), expected, 'Reviewed migration bytes differ');
}
const requireFromRepo = createRequire(join(state.repo, 'package.json'));
const { Client } = requireFromRepo('pg');
const admin = 'phase5b_cluster_admin';
const source = 'physcratic_authoring_test';
const target = 'physcratic_restore_test';
const actor = 'synthetic-phase5b-a';
const heldPath = 'solution-evidence/synthetic-phase5b/held-demo.png';


async function targetIdentity(client) {
  const { rows: [row] } = await client.query(
    "SELECT oid::text AS id, datdba='phase5b_owner'::regrole AS owned," +
    " (SELECT count(*)::int FROM pg_roles WHERE rolname IN ('phase5b_runtime','phase5b_eraser','phase5b_operator') AND NOT has_database_privilege(oid,current_database(),'CONNECT')) AS denied" +
    " FROM pg_database WHERE datname=current_database()",
  );
  assert.equal(row.owned, true);
  assert.equal(row.denied, 3);
  return row.id;
}

async function use(database, operation) {
  const client = new Client({
    host: '127.0.0.1', port: 55439, database, user: admin, password: state.secrets.admin,
    ssl: false, connectionTimeoutMillis: 5000, statement_timeout: 40000,
  });
  await client.connect();
  try {
    const { rows: [id] } = await client.query(
      "SELECT current_database() AS db, session_user AS login, current_setting('data_directory') AS data," +
      " current_setting('server_version_num') AS version, host(inet_server_addr()) AS bind," +
      " inet_server_port() AS port, current_setting('listen_addresses') AS listen",
    );
    assert.deepEqual([id.db,id.login,id.version,id.bind,id.port,id.listen], [database,admin,'180007','127.0.0.1',55439,'127.0.0.1']);
    assert.equal(await realpath(id.data), await realpath(state.data));
    return await operation(client);
  } finally { await client.end(); }
}

async function check(client, erased) {
  await client.query("SET LOCAL timezone='UTC'");
  const marks = state.withCompletions ?
    "(SELECT coalesce(jsonb_agg(to_jsonb(c) ORDER BY c.problem_key),'[]') FROM public.personal_problem_completion c WHERE c.user_id='synthetic-phase5b-b')" : "'[]'::jsonb";
  const limiter = state.withCompletions ?
    "(SELECT to_jsonb(l) FROM public.personal_completion_write_limit l WHERE l.user_id='synthetic-phase5b-b')" : "'null'::jsonb";
  const { rows: [row] } = await client.query([
    "SELECT (SELECT count(*)::int FROM public.\"user\" WHERE id=$1) AS a,",
    "(SELECT count(*)::int FROM public.account WHERE \"userId\"=$1) AS credential,",
    "(SELECT count(*)::int FROM public.session WHERE \"userId\"=$1) AS sessions,",
    "(SELECT count(*)::int FROM public.solution_evidence WHERE \"userId\"=$1 AND pathname=$2) AS registered,",
    "(SELECT count(*)::int FROM public.account_deletion_pending_upload WHERE provider='author' AND pathname=$2) AS held,",
    "(SELECT coalesce(array_agg(o.state::text ORDER BY o.id),'{}') FROM public.account_deletion_outbox o WHERE provider='author' AND pathname=$2) AS states,",
    "(SELECT encode(sha256(convert_to(jsonb_build_array(id,\"createdAt\")::text,'UTF8')),'hex') FROM public.\"user\" WHERE id=$1) AS a_fingerprint,",
    "encode(sha256(convert_to(jsonb_build_array((SELECT to_jsonb(u) FROM public.\"user\" u WHERE id='synthetic-phase5b-b'),",
    "(SELECT jsonb_agg(jsonb_build_array(id,\"providerId\",\"createdAt\") ORDER BY id) FROM public.account WHERE \"userId\"='synthetic-phase5b-b'),",
    marks + ',' + limiter + ")::text,'UTF8')),'hex') AS b_fingerprint",
  ].join('\n'), [actor, heldPath]);
  assert.deepEqual(row, { a: erased ? 0 : 1, credential: erased ? 0 : 1, sessions: 0,
    registered: erased ? 0 : 1, held: 1, states: erased ? ['pending'] : [],
    a_fingerprint: erased ? null : before.aFingerprint, b_fingerprint: before.bFingerprint });
  if (state.withCompletions) {
    const { rows: [extra] } = await client.query(
      'SELECT (SELECT count(*)::int FROM public.personal_problem_completion WHERE user_id=$1) AS marks,' +
      ' (SELECT count(*)::int FROM public.personal_completion_write_limit WHERE user_id=$1) AS limiter', [actor],
    );
    assert.deepEqual(extra, { marks: erased ? 0 : before.aMarks, limiter: erased ? 0 : before.aLimiter });
  }
}

async function readCheck(db, erased) {
  return use(db, async client => {
    await client.query('BEGIN READ ONLY');
    await check(client, erased);
    const receipt = erased ? (await client.query(
      "SELECT o.deletion_id::text AS id FROM public.account_deletion_outbox o WHERE o.provider='author' AND o.pathname=$1 AND o.state='pending'",
      [heldPath],
    )).rows[0].id : null;
    await client.query('ROLLBACK');
    return receipt;
  });
}

const proposalBytes = await readFile(join(root, 'phase5b-recovery-approval.json'));
assert.equal(sha(proposalBytes), pins.proposal, 'Original proposal differs');
const proposal = JSON.parse(proposalBytes);
assert.deepEqual(proposal, {
  database: target, databaseOid: pins.oid, dumpSha256: pins.dump,
  subjectId: actor, subjectFingerprint: before.aFingerprint, publications: [],
  cleanup: [{ provider: 'author', pathname: heldPath, held: true }],
  approvedAt: null, expiresAt: null, reviewer: null, deletionRecord: pins.receipt,
});

const bytes = await readFile(join(root, 'phase5b-synthetic-owner-authorization.json'));
assert.match(expectedAuthorization, hex);
assert.equal(sha(bytes), expectedAuthorization, 'Owner authorization checksum differs');
const auth = JSON.parse(bytes);
const utc = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/;
for (const value of [auth.approvedAt, auth.expiresAt]) assert.match(value, utc);
const approvedAt = Date.parse(auth.approvedAt);
const expiresAt = Date.parse(auth.expiresAt);
assert.ok(approvedAt <= Date.now() && Date.now() < expiresAt && expiresAt - approvedAt === 1800000,
  'Owner authorization is outside its 30-minute window');
assert.equal(typeof auth.owner, 'string');
assert.ok(auth.owner.trim() && auth.owner.length <= 100);
assert.deepEqual(auth, {
  kind: 'synthetic-local-owner-authorization-v1', owner: auth.owner,
  approvedAt: auth.approvedAt, expiresAt: auth.expiresAt, decision: 'AUTHORIZE SYNTHETIC REPLAY ' + pins.oid,
  host: '127.0.0.1', port: 55439, sourceCommit: pins.commit,
  proposalSha256: pins.proposal, checkpointManifestSha256: pins.checkpointManifest,
  dumpSha256: pins.dump, database: target, databaseOid: pins.oid,
  deletionRecord: pins.receipt, subjectId: actor, subjectFingerprint: before.aFingerprint,
  publications: [], cleanup: proposal.cleanup, evidence: auth.evidence,
});
assert.equal(typeof auth.evidence, 'string');
const evidence = JSON.parse(auth.evidence);
assert.equal(evidence.result, 'READY_FOR_INDEPENDENT_REVIEW');
assert.equal(evidence.sourceCommit, pins.commit);
assert.equal(evidence.checkpointSha256, pins.dump);
assert.equal(evidence.checkpointManifestSha256, pins.checkpointManifest);
assert.equal(evidence.proposalSha256, pins.proposal);
assert.equal(evidence.originalReceipt, pins.receipt);
assert.equal(evidence.sourceCheck, 'A absent, B unchanged, held=1, pending=1');
const sampledAt = Date.parse(evidence.sampledUtc);
assert.ok(sampledAt <= approvedAt && approvedAt - sampledAt <= 300000, 'Fresh evidence was not sampled within five minutes of authorization');
assert.deepEqual(evidence.target, {
  databaseOid: pins.oid, ownerOk: true, appLoginsDenied: 3, otherClients: 0,
  withCompletions: true, aMarks: before.aMarks, aLimiter: before.aLimiter,
  aFingerprint: before.aFingerprint, bFingerprint: before.bFingerprint, aCredentials: 1, aSessions: 0,
  registered: 1, held: 1, outbox: 0,
});

const sql = await readFile(join(recoveryKit, 'reconcile-native.sql'), 'utf8');
assert.equal(sha(sql), pins.sql, 'Reviewed replay SQL differs');
assert.equal(await readCheck(source, true), pins.receipt, 'Original pending source receipt differs');
const [start, replay] = sql.split('-- APPROVAL PARAMETERS --');

// Only the approved outbox row may change. Upload holds must survive intact.
async function cleanupFingerprint(client) {
  const { rows: [{ fingerprint }] } = await client.query([
    "SELECT encode(sha256(convert_to(jsonb_build_array(",
    "(SELECT jsonb_agg(to_jsonb(h) ORDER BY h.provider,h.pathname) FROM public.account_deletion_pending_upload h),",
    "(SELECT jsonb_agg(to_jsonb(o) ORDER BY o.id) FROM public.account_deletion_outbox o",
    " WHERE (o.provider,o.pathname) <> ('author',$1))",
    ")::text,'UTF8')),'hex') AS fingerprint",
  ].join(' '), [heldPath]);
  return fingerprint;
}
const nonce = sha('phase5b-native-owner-synthetic-v1:' + expectedAuthorization);
const scope = { ...proposal, approvedAt: auth.approvedAt, expiresAt: auth.expiresAt };
await use(target, async client => {
  await client.query(start);
  assert.equal(await targetIdentity(client), pins.oid, 'Recovery database OID differs');
  const { rows: [receipt] } = await client.query(
    'SELECT EXISTS (SELECT FROM public.account_deletion_receipt_store WHERE nonce=$1) AS found', [nonce],
  );
  await check(client, receipt.found);
  const unchangedCleanup = await cleanupFingerprint(client);
  await client.query("SELECT set_config('physcratic.restore_approval',$1,true),set_config('physcratic.restore_nonce',$2,true)",
    [Buffer.from(JSON.stringify(scope)).toString('base64'), nonce]);
  await client.query(replay);
  await check(client, true);
  assert.equal(await cleanupFingerprint(client), unchangedCleanup, 'Replay changed cleanup outside the approved scope');
  const wanted = receipt.found ? 'ALREADY_RECONCILED' : 'RECONCILED';
  const { rows: [{ status }] } = await client.query("SELECT current_setting('physcratic.restore_result') AS status");
  assert.equal(status, wanted);
  await client.query('COMMIT');
  console.log(status + ': A absent, B unchanged, Held=1, Pending=1');
});
