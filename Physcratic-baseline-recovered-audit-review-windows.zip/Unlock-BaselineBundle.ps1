# PowerShell 7. Opens the download locally and verifies the review ZIP before extraction.
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Destination,
    [System.Security.SecureString] $UnlockKey
)

$ErrorActionPreference = 'Stop'
if (Test-Path -LiteralPath $Destination) { throw 'Choose a new destination folder so existing files stay intact.' }

$Envelope = [IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'bundle.aes'))
if ($Envelope.Length -le 28) { throw 'The encrypted bundle is incomplete. Download the ZIP again.' }
[byte[]] $Nonce = $Envelope[0..11]
[byte[]] $Tag = $Envelope[12..27]
[byte[]] $Ciphertext = $Envelope[28..($Envelope.Length - 1)]
$Plaintext = [byte[]]::new($Ciphertext.Length)

if ($null -eq $UnlockKey) { $UnlockKey = Read-Host 'Paste the new unlock key from ChatGPT' -AsSecureString }
try {
    $KeyText = [System.Net.NetworkCredential]::new('', $UnlockKey).Password
    $Key = [Convert]::FromBase64String($KeyText.Trim())
}
catch [FormatException] {
    throw 'The unlock key format is invalid. Copy the full new key from ChatGPT.'
}
finally {
    $KeyText = $null
    $UnlockKey.Dispose()
}

try {
    if ($Key.Length -ne 32) { throw 'The key is incomplete. Copy the full new key from ChatGPT.' }
    $Cipher = [System.Security.Cryptography.AesGcm]::new($Key)
    try {
        $Cipher.Decrypt($Nonce, $Ciphertext, $Tag, $Plaintext, $null)
    }
    catch [System.Security.Cryptography.CryptographicException] {
        throw 'The key or download could not be verified. Check the new key and download the ZIP again if needed.'
    }
    finally {
        $Cipher.Dispose()
    }

    $Hasher = [System.Security.Cryptography.SHA256]::Create()
    try {
        $Digest = [BitConverter]::ToString($Hasher.ComputeHash($Plaintext)).Replace('-', '').ToLowerInvariant()
    }
    finally {
        $Hasher.Dispose()
    }
    if ($Digest -cne 'fbd6d1efee52e96d3a348302c6813628bb0cca078c28703aaa8d3fc858d8d3c3') {
        throw 'The inner archive does not match the review package.'
    }

    $Stream = [IO.MemoryStream]::new($Plaintext, $false)
    try {
        $Archive = [IO.Compression.ZipArchive]::new($Stream, [IO.Compression.ZipArchiveMode]::Read, $true)
        try {
            [IO.Compression.ZipFileExtensions]::ExtractToDirectory($Archive, $Destination)
        }
        finally {
            $Archive.Dispose()
        }
    }
    finally {
        $Stream.Dispose()
    }
}
finally {
    [Array]::Clear($Key, 0, $Key.Length)
    [Array]::Clear($Plaintext, 0, $Plaintext.Length)
}
Write-Output "Verified and extracted the review package to $Destination"
