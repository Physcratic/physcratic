-- Owner read-only driver. Run with psql -X, ON_ERROR_STOP and a pinned checkout.
\echo PHASE_C_CLIENT_CONNECTION
\conninfo
\echo PHASE_C_CLIENT_CONNECTION_END

BEGIN READ ONLY;
SET LOCAL statement_timeout = '5s';
SET LOCAL lock_timeout = '1s';
SELECT 1 / CASE WHEN
  current_database() = 'neondb'
  AND current_user::text = :'operator_role'
  AND session_user::text = :'operator_role'
  AND :'operator_role' <> :'runtime_role'
  AND :'runtime_role' = 'physcratic_runtime_app'
  AND current_setting('server_version_num') = '180007'
  AND current_setting('default_transaction_read_only') = 'on'
  AND current_setting('transaction_read_only') = 'on'
  AND EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'runtime_role')
  THEN 1 ELSE 0 END AS identity_guard;
SELECT pg_backend_pid() AS phase_c_backend \gset

\echo PHASE_C_LEDGER
SELECT id, sha256, source_commit, result
FROM public.physcratic_production_migrations ORDER BY id;

\echo PHASE_C_CONSTRAINT
SELECT convalidated AS validated,
  pg_get_expr(conbin, conrelid) = $expected$((problem_key ~ '^authored:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'::text) OR (problem_key ~ '^arena:arena-[a-z0-9]+(-[a-z0-9]+)*$'::text))$expected$ AS matches
FROM pg_constraint
WHERE conrelid = 'public.community_favourite'::regclass
  AND conname = 'community_favourite_key_check' AND contype = 'c';

\echo PHASE_C_AUTHORED
SELECT has_table_privilege(:'runtime_role', 'public.authored_problem', 'UPDATE') AS table_update,
       has_column_privilege(:'runtime_role', 'public.authored_problem', 'id', 'UPDATE') AS id_update,
       has_any_column_privilege(:'runtime_role', 'public.authored_problem', 'UPDATE') AS row_lock_available,
       coalesce(string_agg(a.attname::text, ',' ORDER BY a.attname::text COLLATE "C")
         FILTER (WHERE has_column_privilege(:'runtime_role', a.attrelid, a.attnum, 'UPDATE')), '') AS update_columns
FROM pg_attribute a
WHERE a.attrelid = 'public.authored_problem'::regclass AND a.attnum > 0 AND NOT a.attisdropped;

\echo PHASE_C_PROFILES
WITH objects(relation) AS (VALUES ('community_profile'), ('community_profile_write_limit')),
     privileges(privilege) AS (VALUES ('SELECT'), ('INSERT'), ('UPDATE'))
SELECT o.relation, p.privilege,
       to_regclass('public.' || o.relation) IS NOT NULL AS object_present,
       has_table_privilege(:'runtime_role', to_regclass('public.' || o.relation), p.privilege) AS table_allowed,
       has_any_column_privilege(:'runtime_role', to_regclass('public.' || o.relation), p.privilege) AS any_column_allowed
FROM objects o CROSS JOIN privileges p ORDER BY 1, 2;
\echo PHASE_C_PROFILES_END
COMMIT;

-- Same direct session across the audited scripts' own read-only transactions.
SET physcratic.audit_contract = 'batch-a';
SELECT 1 / CASE WHEN current_setting('physcratic.audit_contract') = 'batch-a'
 AND pg_backend_pid() = :'phase_c_backend'::integer
 AND current_setting('transaction_read_only') = 'on'
 THEN 1 ELSE 0 END AS contract_guard;
\echo PHASE_C_ACTIVATION
\i scripts/activation/runtime-readonly.sql

\echo PHASE_C_VERIFIER
\i scripts/runtime-role/verify.readonly.sql
\echo PHASE_C_VERIFIER_END

SELECT 1 / CASE WHEN current_setting('physcratic.audit_contract') = 'batch-a'
 AND pg_backend_pid() = :'phase_c_backend'::integer
 AND current_setting('transaction_read_only') = 'on'
 THEN 1 ELSE 0 END AS final_session_guard;
\echo PHASE_C_COMPLETE
