# Physcratic Production freeze investigation

27 November 2026 Singapore time. **Capture remains on hold. No replacement receipt was issued.**

## Finding

Vercel's GitHub integration is creating Production builds when commits land on `main`, and the Production aliases move as those builds become READY. The owner agreement did not stop new merges, and it did not drain a build already in progress. Vercel's active behavior contradicts the governing repository document's statement that automatic deployments are disabled. [Repository agent rules](https://github.com/Physcratic/physcratic/blob/423ea37a62af91b9c70a1007e46b69e8def8a90d/AGENTS.md) [Vercel GitHub integration](https://vercel.com/docs/git/vercel-for-github)

| Source on main | GitHub merge | Vercel created | READY and alias assignment | Deployment |
| --- | --- | --- | --- | --- |
| `5c75ecf`, PR #273 | 21:52:29 | 21:52:33 | 21:55:18 | `dpl_A9sGqjmaSQsMwS1oh9izDfGSsv3o` |
| `423ea37`, PR #274 | 22:33:29 | 22:33:33 | 22:35:54 | `dpl_8YLcVFBtygcXDWJx2Ywock6DWDHz` |

All times are on 27 November in Singapore. The exact active alias linked to `dpl_8YLcVFBtygcXDWJx2Ywock6DWDHz` during the investigation. The named `5c75ecf` build was created before the R2 receipt was generated at 21:55:37 and finished around issuance. The exact second the freeze agreement took effect is unavailable here. The later PR #274 was merged and built after that receipt, establishing a new trigger after approval. [PR #273](https://github.com/Physcratic/physcratic/pull/273) [PR #274](https://github.com/Physcratic/physcratic/pull/274) [Current deployment](https://vercel.com/neuterions-projects/financial-dashboard/8YLcVFBtygcXDWJx2Ywock6DWDHz)

## Trigger evidence

- Both deployment objects had source `git`, target `production`, and the exact `Physcratic/physcratic` SHA on `main`. Vercel activity recorded a new Production deployment and a separate four-domain alias assignment immediately when each became READY. The PR #273 build log confirms it cloned `main` at `5c75ecf`. The available activity showed no separate manual deployment, promotion, rollback or alias move that explains these two rollovers. The activity wording attributes deployments and alias assignments to an actor even when the recorded source is Git.
- Both commits have Vercel-generated GitHub statuses linking directly to the matching financial-dashboard deployment. The GitHub default branch is `main`, and Vercel reports the Git-linked project. The repository has no tracked `vercel.json`, `vercel.ts`, or `now.json` at the reviewed head disabling branch-triggered deployments. GitHub's `Deploy watch` workflow polls the Vercel status and manages GitHub issues. Its smoke workflow reacts to Vercel events. Neither initiates deployments, and the checked workflows have no Vercel deploy or promotion invocation. The connector project view does not expose the exact dashboard toggle values. The deployment, activity and GitHub records establish the effective behavior. [Deploy watch](https://github.com/Physcratic/physcratic/blob/423ea37a62af91b9c70a1007e46b69e8def8a90d/.github/workflows/deploy-watch.yml) [Smoke workflow](https://github.com/Physcratic/physcratic/blob/423ea37a62af91b9c70a1007e46b69e8def8a90d/.github/workflows/smoke.yml)
- No Production entries were returned in QUEUED, INITIALIZING or BUILDING state at the later inspection. This is a snapshot. The previous receipt is preserved as evidence, and its deployment-specific guard would stop capture now.
- PR #273 had documentation changes. PR #274 changed tests, CI and documentation. The source comparison found no scoped database contract changes. Vercel still showed the same Production database variable record and update time. The effective binding of the newest deployment requires its own existing evidence before reuse in an approved capture. No database inspection was repeated. [Exact Git comparison](https://github.com/Physcratic/physcratic/compare/27ead7d1e5c1612c461cebce1d4b70cfe7d5c735...423ea37a62af91b9c70a1007e46b69e8def8a90d)

If retaining the current seal design, coordinate the pause with everyone who can merge or push to `main`, account for other Production promotion paths, and confirm the build queue has drained before obtaining approval. A single check of the serving alias leaves a race with an in-flight build. No repository or provider setting change is part of this investigation.
