[CmdletBinding()]
param([Parameter(Mandatory)][string]$EvidenceDir)
$ErrorActionPreference = 'Stop'
$Folder = (Resolve-Path -LiteralPath $EvidenceDir).Path
$Proposal = Join-Path $Folder 'phase5b-recovery-approval.json'
$Before = Join-Path $Folder 'phase5b-before-a.json'
$Review = Join-Path $Folder 'phase5b-review-evidence.json'
$Approved = Join-Path $Folder 'phase5b-recovery-approved.json'
if (Test-Path -LiteralPath $Approved) { throw 'An approved copy already exists. Preserve it.' }

function Get-Sha256([string]$Path) {
    (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

$Plan = Get-Content -Raw -Encoding UTF8 -LiteralPath $Proposal | ConvertFrom-Json
$Snapshot = Get-Content -Raw -Encoding UTF8 -LiteralPath $Before | ConvertFrom-Json
$Evidence = Get-Content -Raw -Encoding UTF8 -LiteralPath $Review | ConvertFrom-Json
$Target = $Evidence.target

if ($Evidence.result -cne 'READY_FOR_INDEPENDENT_REVIEW' -or
    $Evidence.proposalSha256 -cne (Get-Sha256 $Proposal) -or
    $Evidence.checkpointManifestSha256 -cne (Get-Sha256 $Before) -or
    $Plan.dumpSha256 -cnotmatch '^[a-f0-9]{64}$' -or
    $Plan.dumpSha256 -cne $Snapshot.dumpSha256 -or $Plan.dumpSha256 -cne $Evidence.checkpointSha256 -or
    $Plan.database -cne 'physcratic_restore_test' -or
    "$($Plan.databaseOid)" -cnotmatch '^[0-9]+$' -or "$($Plan.databaseOid)" -cne "$($Target.databaseOid)" -or
    $Plan.subjectId -cne 'synthetic-phase5b-a' -or
    $Plan.subjectFingerprint -cne $Snapshot.aFingerprint -or $Target.aFingerprint -cne $Snapshot.aFingerprint -or
    $Target.bFingerprint -cne $Snapshot.bFingerprint -or
    -not $Target.ownerOk -or $Target.appLoginsDenied -ne 3 -or $Target.otherClients -ne 0 -or
    $Target.aCredentials -ne 1 -or $Target.aSessions -ne 0 -or
    $Target.withCompletions -ne $Snapshot.withCompletions -or
    $Target.aMarks -ne $Snapshot.aMarks -or $Target.aLimiter -ne $Snapshot.aLimiter -or
    $Target.registered -ne 1 -or $Target.held -ne 1 -or $Target.outbox -ne 0 -or
    $Evidence.sourceCheck -cne 'A absent, B unchanged, held=1, pending=1' -or
    "$($Plan.deletionRecord)" -cnotmatch '^[0-9a-f-]{36}$' -or
    $Plan.deletionRecord -cne $Evidence.originalReceipt -or
    @($Plan.publications).Count -ne 0 -or @($Plan.cleanup).Count -ne 1 -or
    $Plan.cleanup[0].provider -cne 'author' -or $Plan.cleanup[0].pathname -cne 'solution-evidence/synthetic-phase5b/held-demo.png' -or
    $Plan.cleanup[0].held -ne $true -or $null -ne $Plan.reviewer -or $null -ne $Plan.approvedAt -or $null -ne $Plan.expiresAt) {
    throw 'Evidence mismatch. Do not approve.'
}

$Receipt = (Read-Host 'Enter the source receipt you independently verified').Trim()
if ($Receipt -cne $Plan.deletionRecord) { throw 'Independently verified receipt did not match' }
$Reviewer = (Read-Host 'Independent reviewer name').Trim()
if (-not $Reviewer) { throw 'Reviewer name is required' }
$Decision = (Read-Host 'After reviewing identity, isolation and scope, type APPROVE SYNTHETIC REPLAY').Trim()
if ($Decision -cne 'APPROVE SYNTHETIC REPLAY') { throw 'Approval was not recorded' }

$Now = [DateTime]::UtcNow
$Plan.reviewer = $Reviewer
$Plan.approvedAt = $Now.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
$Plan.expiresAt = $Now.AddHours(2).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
[IO.File]::WriteAllText($Approved, ($Plan | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
"ApprovedSha256=$(Get-Sha256 $Approved)"
"ExpiresAtUtc=$($Plan.expiresAt)"
