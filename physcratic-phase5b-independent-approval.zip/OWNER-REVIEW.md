# Phase 5B independent synthetic recovery review

27 November 2026, Singapore. Owner reports that the native Windows source erased A, B matched, and one held marker and pending job remained. The restored copy contained A again and the three app logins could not connect. Replay approval remains pending. The steps below use Windows PowerShell 5.1 and the existing disposable cluster only.

## 1. Operator collects evidence

Keep the Next.js app stopped and the recovered copy disconnected from every app and worker. Preserve the dump, its manifest and both cluster directories. Run the read-only evidence script from Downloads. These paths assume the same directory names as the Windows rehearsal kit.

~~~powershell
$ErrorActionPreference = 'Stop'
$Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
$Pack = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Rehearsal-Kit'
$Tool = Join-Path $env:USERPROFILE 'Downloads\Get-Phase5bReviewEvidence.ps1'
$Evidence = Join-Path $Fresh 'phase5b-review-evidence.json'
if ((Get-FileHash -LiteralPath $Tool -Algorithm SHA256).Hash -ine
    'bfbc5394e2f5a22edf436059b497d6564cc9ca4089044b30f2982870a98419de') {
    throw 'Evidence script checksum mismatch'
}
if (Test-Path -LiteralPath $Evidence) { throw 'Preserve the earlier report before collecting a fresh one' }
$Report = & $Tool -ClusterRoot $Fresh -Kit $Pack
[IO.File]::WriteAllText($Evidence, ($Report -join [Environment]::NewLine), [Text.UTF8Encoding]::new($false))
$Report
~~~

Expect READY_FOR_INDEPENDENT_REVIEW, an original synthetic receipt and a target matching the proposal OID with appLoginsDenied=3, otherClients=0, aCredentials=1, aSessions=0, registered=1, held=1 and outbox=0. The script verifies the dump bytes against the two recorded digests and checks A and B fingerprints against the checkpoint. In the combined 0025 case the restored A has one mark and one limiter row.

Send the reviewer these three exact files in a private folder:

- phase5b-before-a.json
- phase5b-recovery-approval.json, the generated proposal with its three approval fields blank
- phase5b-review-evidence.json

Also provide the original checkpoint, source erasure and restore command outputs and the ZIP SHA-256, 8697d2da6f6355df0e5e881d603cfe26ccdbcd49477de603e901ee413fb83e11. The reviewer should witness the read-only check on the isolated workstation or use independently preserved command evidence to confirm the original source receipt, exact checkpoint and target identity. Hash agreement across files is a consistency check. The independent reviewer supplies authorization. Keep the dump, fixture-state.json, passwords and session credentials on the fixture machine.

## 2. Reviewer independently decides

The reviewer must be distinct from the operator and authorized to review this synthetic replay. Compare the checkpoint hash and fingerprints, the original receipt, the target database and OID, and the isolation checks. Confirm the source erased only A with one held pending job, the restore reintroduced only the expected state for A, and B's recorded state matches. The proposed replay scope is synthetic-phase5b-a only, no publication approvals, and one held author cleanup obligation. Check that replay will leave the hold intact. If evidence is missing, disagrees or cannot be independently corroborated, keep the target isolated and withhold approval.

If satisfied, the reviewer runs:

~~~powershell
$Tool = Join-Path $env:USERPROFILE 'Downloads\Approve-Phase5bRecovery.ps1'
if ((Get-FileHash -LiteralPath $Tool -Algorithm SHA256).Hash -ine
    'c715cff98b47091afa233a065a6d6194da0aae4f0b425bd8b09f8ffcca8ef203') {
    throw 'Approval script checksum mismatch'
}
$Folder = (Read-Host 'Private folder containing the three evidence files').Trim()
& $Tool -EvidenceDir $Folder
~~~

Enter the receipt independently verified against the source, the actual reviewer name, then APPROVE SYNTHETIC REPLAY only if satisfied. Expect ApprovedSha256 and ExpiresAtUtc. The script writes a separate UTF-8 phase5b-recovery-approved.json, adding only the reviewer name and UTC approval and expiry to the proposal. Its window is two hours. Return the exact file through the private evidence channel and communicate its SHA-256 separately through the established reviewer channel. Keep the review decision with both hashes.

## 3. Operator applies the approved file

The app stays stopped. Run only after the reviewer returns both the file and digest. Keep a separate copy of the original proposal. The runner expects the approved bytes under the original proposal filename.

~~~powershell
$ErrorActionPreference = 'Stop'
$Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
$Pack = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Rehearsal-Kit'
$Approved = (Read-Host 'Full path to the returned approved JSON file').Trim()
$Sha = (Read-Host 'SHA-256 received independently from the reviewer').Trim().ToLowerInvariant()
if ($Sha -cnotmatch '^[a-f0-9]{64}$' -or
    (Get-FileHash -LiteralPath $Approved -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Sha) {
    throw 'The reviewer file does not match the reviewer digest'
}
$Proposal = Join-Path $Fresh 'phase5b-recovery-approval.json'
$Saved = Join-Path $Fresh 'phase5b-recovery-proposal-original.json'
if (Test-Path -LiteralPath $Saved) { throw 'The proposal was already preserved. Review the existing state before proceeding.' }
Copy-Item -LiteralPath $Proposal -Destination $Saved
Copy-Item -LiteralPath $Approved -Destination $Proposal
$Recovery = Join-Path $Pack 'Phase5b-Recovery.ps1'
& $Recovery -Action Reconcile -ClusterRoot $Fresh -ApprovalSha256 $Sha
& $Recovery -Action Reconcile -ClusterRoot $Fresh -ApprovalSha256 $Sha
~~~

Expect RECONCILED and then ALREADY_RECONCILED. Both must report A absent, B unchanged, Held=1, Pending=1. Preserve both results and leave the restored database disconnected from the app. If replay errors or an acknowledgement is lost, keep the same approved bytes for a retry within the approval window so the runner can recognize its receipt. If the approval expires, retain the receipt and return to the reviewer rather than changing the file or blindly retrying under another digest. Do not rerun Restore.

## Windows issue: stopping Next.js can also stop PostgreSQL

**Observed:** On the owner's Windows laptop, stopping the Next.js process has repeatedly left the disposable PostgreSQL cluster stopped. A shared console control event is a plausible cause when pg_ctl launched PostgreSQL from the same console as Next.js. The cause is unconfirmed. Keep PostgreSQL and Next.js in separate PowerShell windows on future runs. Stop the app in its own window and check the database in the other.

With the app stopped, run the following in the separate PowerShell window. It checks the existing fixture data directory and restarts only that cluster if pg_ctl reports it stopped. It preserves its existing data and app-role restrictions. Never rerun initdb, Prepare or Restore to recover from this symptom.

~~~powershell
$ErrorActionPreference = 'Stop'
$Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
$Data = [IO.Path]::GetFullPath((Join-Path $Fresh 'data'))
$State = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $Fresh 'fixture-state.json') | ConvertFrom-Json
if ($State.port -ne 55439 -or [IO.Path]::GetFullPath($State.data) -ne $Data -or
    -not (Test-Path -LiteralPath (Join-Path $Data 'PG_VERSION') -PathType Leaf)) {
    throw 'Disposable cluster identity mismatch'
}
$PgCtl = (Get-Command pg_ctl -CommandType Application | Select-Object -First 1).Source
& $PgCtl status -D $Data
$Status = $LASTEXITCODE
if ($Status -eq 3) {
    & $PgCtl start -D $Data -l (Join-Path $Fresh 'postgres.log') -o '-h 127.0.0.1 -p 55439' -w -t 25
    if ($LASTEXITCODE -ne 0) { throw 'Fixture restart failed. Keep its data and inspect postgres.log privately.' }
} elseif ($Status -ne 0) {
    throw 'Could not confirm fixture status. Leave existing processes alone.'
}
~~~

Expect pg_ctl to report server running or server started. If needed, inspect only the recent fixture log lines for shutdown and recovery timestamps. Keep raw logs private. A port conflict or an unexpected status needs review before retrying. No commands here act on the original Windows PostgreSQL service or Production.

Evidence collection passed against a real synthetic dump and restore on native PostgreSQL 18.7 with PowerShell 7 on Linux, and the three existing files retained the same hashes. Windows PowerShell 5.1 execution of these review helpers remains to be confirmed.
