[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$ClusterRoot,
    [Parameter(Mandatory)][string]$Kit
)
$ErrorActionPreference = 'Stop'
$Fresh = (Resolve-Path -LiteralPath $ClusterRoot).Path
$BeforePath = Join-Path $Fresh 'phase5b-before-a.json'
$Dump = Join-Path $Fresh 'phase5b-before-a.dump'
$Proposal = Join-Path $Fresh 'phase5b-recovery-approval.json'
$Before = Get-Content -Raw -Encoding UTF8 -LiteralPath $BeforePath | ConvertFrom-Json
$State = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $Fresh 'fixture-state.json') | ConvertFrom-Json
$Plan = Get-Content -Raw -Encoding UTF8 -LiteralPath $Proposal | ConvertFrom-Json
$Data = [IO.Path]::GetFullPath((Join-Path $Fresh 'data'))
$DumpHash = (Get-FileHash -LiteralPath $Dump -Algorithm SHA256).Hash.ToLowerInvariant()
if ($State.port -ne 55439 -or [IO.Path]::GetFullPath($State.data) -ne $Data -or
    $State.secrets.admin -cnotmatch '^[a-f0-9]{64}$' -or $DumpHash -cne $Before.dumpSha256 -or
    $DumpHash -cne $Plan.dumpSha256 -or $Plan.database -cne 'physcratic_restore_test' -or
    "$($Plan.databaseOid)" -cnotmatch '^[0-9]+$' -or
    $Plan.subjectId -cne 'synthetic-phase5b-a' -or $Plan.subjectFingerprint -cne $Before.aFingerprint -or
    $Before.aFingerprint -cnotmatch '^[a-f0-9]{64}$' -or $Before.bFingerprint -cnotmatch '^[a-f0-9]{64}$' -or
    $Before.withCompletions -ne $State.withCompletions) {
    throw 'Checkpoint, target or fixture metadata mismatch'
}
if (@($Plan.publications).Count -ne 0 -or @($Plan.cleanup).Count -ne 1 -or
    $Plan.cleanup[0].provider -cne 'author' -or $Plan.cleanup[0].pathname -cne 'solution-evidence/synthetic-phase5b/held-demo.png' -or
    $Plan.cleanup[0].held -ne $true -or $null -ne $Plan.reviewer -or
    $null -ne $Plan.approvedAt -or $null -ne $Plan.expiresAt) {
    throw 'Expected the untouched synthetic approval proposal'
}

$Head = git -C $State.repo rev-parse HEAD
if ($LASTEXITCODE -ne 0 -or $Head -cnotmatch '^[a-f0-9]{40}$') { throw 'Could not identify the fixture source' }

$Archive = (Get-Command pg_restore -CommandType Application | Select-Object -First 1).Source
$Toc = & $Archive -l $Dump
if ($LASTEXITCODE -ne 0 -or -not ($Toc -match 'TABLE DATA public account_deletion_pending_upload') -or
    -not ($Toc -match 'TABLE DATA public solution_evidence')) { throw 'Checkpoint archive verification failed' }
$Original = & (Join-Path $Kit 'Phase5b-Recovery.ps1') -Action CheckErasure -ClusterRoot $Fresh
if ($LASTEXITCODE -ne 0 -or $Original -cnotcontains 'Source=A absent, B unchanged, Held=1, Pending=1' -or
    $Original -cnotcontains ('SourceReceipt=' + $Plan.deletionRecord)) { throw 'Source erasure or receipt mismatch' }

$Psql = (Get-Command psql -CommandType Application | Select-Object -First 1).Source
$Conn = @('-h','127.0.0.1','-p','55439','-U','phase5b_cluster_admin','-d','physcratic_restore_test','-w','-XqAt','-v','ON_ERROR_STOP=1')
$Saved = @(Get-ChildItem Env: | Where-Object { $_.Name -like 'PG*' })
$Overrides = @{
    PGSSLMODE = 'disable'
    PGGSSENCMODE = 'disable'
    PGCONNECT_TIMEOUT = '5'
    PGCLIENTENCODING = 'UTF8'
    PGPASSWORD = $State.secrets.admin
}
try {
    foreach ($Entry in $Saved) { Remove-Item -LiteralPath ('Env:' + $Entry.Name) }
    foreach ($Name in $Overrides.Keys) { Set-Item -LiteralPath ('Env:' + $Name) -Value $Overrides[$Name] }

    $Identity = & $Psql @Conn -c "SELECT current_setting('data_directory') WHERE current_database()='physcratic_restore_test' AND session_user='phase5b_cluster_admin' AND inet_server_addr()='127.0.0.1' AND inet_server_port()=55439 AND current_setting('listen_addresses')='127.0.0.1' AND current_setting('server_version_num')='180007'"
    if ($LASTEXITCODE -ne 0 -or -not $Identity -or [IO.Path]::GetFullPath($Identity) -ne $Data) {
        throw 'Connection does not match the recovered fixture'
    }

    $Answer = @'
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL timezone='UTC';
SET LOCAL statement_timeout='5s';
SELECT (to_regclass('public.personal_problem_completion') IS NOT NULL
    AND to_regclass('public.personal_completion_write_limit') IS NOT NULL) AS has_0025 \gset
\if :has_0025
SELECT coalesce((SELECT jsonb_agg(to_jsonb(c) ORDER BY c.problem_key)::text
  FROM personal_problem_completion c WHERE c.user_id='synthetic-phase5b-b'),'[]') AS b_marks,
  coalesce((SELECT to_jsonb(l)::text FROM personal_completion_write_limit l WHERE l.user_id='synthetic-phase5b-b'),'null') AS b_limit,
  (SELECT count(*) FROM personal_problem_completion WHERE user_id='synthetic-phase5b-a') AS a_marks,
  (SELECT count(*) FROM personal_completion_write_limit WHERE user_id='synthetic-phase5b-a') AS a_limit \gset
\else
\set b_marks '[]'
\set b_limit 'null'
\set a_marks 0
\set a_limit 0
\endif
SELECT jsonb_build_object(
 'databaseOid',(SELECT oid::text FROM pg_database WHERE datname=current_database()),
 'ownerOk',(SELECT datdba='phase5b_owner'::regrole FROM pg_database WHERE datname=current_database()),
 'appLoginsDenied',(SELECT count(*) FROM pg_roles WHERE rolname IN ('phase5b_runtime','phase5b_eraser','phase5b_operator')
   AND NOT has_database_privilege(oid,current_database(),'CONNECT')),
 'otherClients',(SELECT count(*) FROM pg_stat_activity WHERE datname=current_database()
   AND backend_type='client backend' AND pid<>pg_backend_pid()),
 'withCompletions',:'has_0025'::boolean,
 'aMarks',:'a_marks'::integer,'aLimiter',:'a_limit'::integer,
 'aFingerprint',(SELECT encode(sha256(convert_to(jsonb_build_array(id,"createdAt")::text,'UTF8')),'hex')
   FROM "user" WHERE id='synthetic-phase5b-a'),
 'aCredentials',(SELECT count(*) FROM account WHERE "userId"='synthetic-phase5b-a'),
 'aSessions',(SELECT count(*) FROM session WHERE "userId"='synthetic-phase5b-a'),
 'bFingerprint',encode(sha256(convert_to(jsonb_build_array(
   (SELECT to_jsonb(u) FROM "user" u WHERE id='synthetic-phase5b-b'),
   (SELECT jsonb_agg(jsonb_build_array(id,"providerId","createdAt") ORDER BY id)
     FROM account WHERE "userId"='synthetic-phase5b-b'),
   :'b_marks'::jsonb, :'b_limit'::jsonb)::text,'UTF8')),'hex'),
 'registered',(SELECT count(*) FROM solution_evidence WHERE "userId"='synthetic-phase5b-a'
   AND pathname='solution-evidence/synthetic-phase5b/held-demo.png'),
 'held',(SELECT count(*) FROM account_deletion_pending_upload WHERE provider='author'
   AND pathname='solution-evidence/synthetic-phase5b/held-demo.png'),
 'outbox',(SELECT count(*) FROM account_deletion_outbox WHERE provider='author'
   AND pathname='solution-evidence/synthetic-phase5b/held-demo.png'));
ROLLBACK;
'@ | & $Psql @Conn -f -
    if ($LASTEXITCODE -ne 0) { throw 'Read-only recovery verification failed' }
    $Target = $Answer | ConvertFrom-Json
    if ("$($Target.databaseOid)" -cne "$($Plan.databaseOid)" -or -not $Target.ownerOk -or
        $Target.appLoginsDenied -ne 3 -or $Target.otherClients -ne 0 -or
        $Target.aFingerprint -cne $Before.aFingerprint -or $Target.bFingerprint -cne $Before.bFingerprint -or
        $Target.aCredentials -ne 1 -or $Target.aSessions -ne 0 -or
        $Target.withCompletions -ne $Before.withCompletions -or
        $Target.aMarks -ne $Before.aMarks -or $Target.aLimiter -ne $Before.aLimiter -or
        $Target.registered -ne 1 -or $Target.held -ne 1 -or $Target.outbox -ne 0) {
        throw 'Restored database differs from the pre-replay checkpoint'
    }
} finally {
    foreach ($Name in $Overrides.Keys) {
        $EnvPath = 'Env:' + $Name
        if (Test-Path -LiteralPath $EnvPath) { Remove-Item -LiteralPath $EnvPath }
    }
    foreach ($Entry in $Saved) { Set-Item -LiteralPath ('Env:' + $Entry.Name) -Value $Entry.Value }
}

[ordered]@{
    result = 'READY_FOR_INDEPENDENT_REVIEW'
    sampledUtc = [DateTime]::UtcNow.ToString('o')
    sourceCommit = $Head
    originalReceipt = $Plan.deletionRecord
    checkpointSha256 = $DumpHash
    checkpointManifestSha256 = (Get-FileHash -LiteralPath $BeforePath -Algorithm SHA256).Hash.ToLowerInvariant()
    proposalSha256 = (Get-FileHash -LiteralPath $Proposal -Algorithm SHA256).Hash.ToLowerInvariant()
    sourceCheck = 'A absent, B unchanged, held=1, pending=1'
    target = $Target
} | ConvertTo-Json -Depth 4
