[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [string]$ApprovedEndpoint,
    [Parameter(Mandatory = $true)] [ValidateSet('confirmed','unknown','mismatch')] [string]$ServingBindingContinuity
)
& {
    $ErrorActionPreference = 'Stop'
    $ApprovedEndpoint = $ApprovedEndpoint.Trim().ToLowerInvariant()
    $endpoints = @(
        'ep-snowy-heart-b7c1220y.c-13.us-east-1.aws.neon.tech',
        'ep-snowy-heart-b7c1220y-pooler.c-13.us-east-1.aws.neon.tech'
    )
    if ($ApprovedEndpoint -cnotin $endpoints) { throw 'Endpoint differs from the reviewed Neon target.' }
    if ($ServingBindingContinuity -eq 'mismatch') { throw 'Reconcile the serving binding before using its credential.' }

    $verifier = Join-Path $PSScriptRoot 'verify.readonly.sql'
    $pinnedHash = '002295211760e0491857f852cd3087b342a99898e1412eb60fb9c308d94de92e'
    if ((Get-FileHash -LiteralPath $verifier -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pinnedHash) {
        throw 'The runtime verifier does not match the reviewed LF file.'
    }
    $runtimeLogin = 'physcratic_runtime_app'
    $start = [regex]'(?m)^BEGIN READ ONLY;$'
    $body = Get-Content -Raw -LiteralPath $verifier
    if ($start.Matches($body).Count -ne 1) { throw 'Expected one read-only transaction in the pinned verifier.' }
    # Add only session-local settings and guards. All reviewed verifier queries are preserved.
    $intro = @'
BEGIN READ ONLY;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '1s';
SET LOCAL search_path = pg_catalog, pg_temp;
SET LOCAL physcratic.audit_contract = 'b1';
SELECT 1 / CASE WHEN current_database() = 'neondb'
 AND session_user = :'runtime_role' AND current_user = session_user
 AND current_setting('server_version_num') = '180007'
 AND current_setting('transaction_read_only') = 'on'
 AND to_regclass('public.personal_problem_completion') IS NULL
 AND to_regclass('public.personal_completion_write_limit') IS NULL
 AND to_regclass('public.account_deletion_pending_upload') IS NULL
 AND to_regprocedure('public.account_deletion_upload_finished(text,text,text)') IS NULL
 THEN 1 ELSE 0 END AS identity_guard \gset
SELECT 'runtime_transport' AS marker,
 coalesce((SELECT ssl::text FROM pg_stat_ssl WHERE pid=pg_backend_pid()),'unknown') AS backend_ssl,
 (SELECT count(*) FROM pg_attribute a JOIN pg_class c ON c.oid=a.attrelid
  JOIN pg_namespace n ON n.oid=c.relnamespace CROSS JOIN LATERAL aclexplode(a.attacl) g
  WHERE a.attnum>0 AND NOT a.attisdropped AND n.nspname NOT LIKE 'pg_%'
    AND n.nspname<>'information_schema' AND g.grantee=0) AS public_column_grants;
'@
    $sql = $start.Replace($body, $intro, 1)
    $connection = "host=$ApprovedEndpoint hostaddr='' port=5432 dbname=neondb sslmode=verify-full gssencmode=disable connect_timeout=5"
    $psql = (Get-Command psql -CommandType Application | Select-Object -First 1).Source
    $csv = @($sql | & $psql -X -q --csv -v ON_ERROR_STOP=1 -d $connection -U $runtimeLogin -v "runtime_role=$runtimeLogin" -f -)
    if ($LASTEXITCODE -ne 0) { throw "Read-only runtime audit stopped (psql exit $LASTEXITCODE)." }
    $transportIndex = [array]::IndexOf($csv, 'marker,backend_ssl,public_column_grants')
    $findingIndex = [array]::LastIndexOf($csv, 'kind,object,detail')
    if ($transportIndex -lt 0 -or $findingIndex -le ($transportIndex + 1)) {
        throw 'Expected the verifier identity and final findings result sets.'
    }
    $transport = @($csv[$transportIndex..($transportIndex + 1)] | ConvertFrom-Csv)
    if ($transport.Count -ne 1 -or $transport[0].marker -cne 'runtime_transport' -or
        $transport[0].backend_ssl -cnotin @('true','false','unknown') -or
        $transport[0].public_column_grants -notmatch '^\d+$') { throw 'Invalid transport or column ACL evidence.' }
    $findings = @($csv[$findingIndex..($csv.Count - 1)] | ConvertFrom-Csv)
    # The historical b1 verifier predates the accepted external-medal contract.
    # Reconcile the exact positive deltas, both absent and extra, by type/object/privilege.
    $delta = @(
        [pscustomobject]@{ Relation = 'community_badge_selection'; Columns = @('user_id','badge_ids','created_at','updated_at'); Rights = @('SELECT','INSERT','UPDATE') }
        [pscustomobject]@{ Relation = 'community_achievement_write_limit'; Columns = @('user_id','window_start','requests'); Rights = @('SELECT','INSERT','UPDATE') }
        [pscustomobject]@{ Relation = 'community_external_approved_medal'; Columns = @('id','user_id','competition','award','year','country','competitionName'); Rights = @('SELECT') }
    )
    $expected = @(foreach ($relation in $delta) {
        foreach ($right in $relation.Rights) {
            "table_privilege|public.$($relation.Relation)|$right"
            foreach ($column in $relation.Columns) { "column_privilege|public.$($relation.Relation).$column|$right" }
        }
    }) + @('direct_routine_grant|public.community_showcase_ids_valid(text[])|Unlisted direct EXECUTE grant')
    $observed = @($findings | ForEach-Object { "$($_.kind)|$($_.object)|$($_.detail)" })
    $missing = @($expected | Where-Object { $_ -cnotin $observed })
    $extra = @($observed | Where-Object { $_ -cnotin $expected })
    $duplicate = @($observed | Group-Object -CaseSensitive | Where-Object Count -gt 1 | ForEach-Object Name)
    $publicColumnGrants = [int]$transport[0].public_column_grants
    $privilegesPass = -not ($missing.Count -or $extra.Count -or $duplicate.Count -or $publicColumnGrants)
    [ordered]@{
        ObservedAtUtc = [DateTime]::UtcNow.ToString('o')
        DeploymentForContinuityReview = 'dpl_9TEGMDgbd78w4w4TYXByBCoDKwkT'
        ClientTls = 'verify-full'
        BackendSslReported = $transport[0].backend_ssl
        Database = 'neondb'
        SessionUser = $runtimeLogin
        CurrentUser = $runtimeLogin
        ServerVersionNum = '180007'
        TransactionReadOnly = 'on'
        EffectivePrivileges = $(if ($privilegesPass) { 'pass' } else { 'hold' })
        ExpectedApprovedDeltaCount = $expected.Count
        MatchedApprovedDeltaCount = @($observed | Where-Object { $_ -cin $expected } | Sort-Object -Unique -CaseSensitive).Count
        PublicColumnGrants = $publicColumnGrants
        MissingApprovedRights = $missing
        UnexpectedFindings = $extra
        DuplicateFindings = $duplicate
        OwnerReportedServingContinuity = $ServingBindingContinuity
        Step3 = $(if ($privilegesPass -and $ServingBindingContinuity -eq 'confirmed') { 'ready_for_review' } else { 'hold' })
    } | ConvertTo-Json -Depth 5
}
