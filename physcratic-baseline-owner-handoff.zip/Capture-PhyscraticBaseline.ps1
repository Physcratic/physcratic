# PowerShell 7. VerifyFiles is offline. Capture requires separate owner authorization.
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Repository,
    [Parameter(Mandatory)] [string] $PlanPath,
    [Parameter(Mandatory)] [ValidatePattern('^[0-9a-f]{64}$')] [string] $PlanSha256,
    [ValidateSet('VerifyFiles', 'Capture')] [string] $Mode = 'VerifyFiles',
    [string] $EvidenceDir
)

$ErrorActionPreference = 'Stop'
$ExpectedCommit = '9141a7acefcadbadff3cafacc81cf5e31f09bf32'
$ExpectedManifest = '931e3dd8a9ec2c9fe4e203ec7523256d7ea9ee6d83f3f9faaa0fb262417dad84'
$Package = 'scripts/retrospective-baseline'
$PlanFile = (Resolve-Path -LiteralPath $PlanPath).Path

Push-Location -LiteralPath $Repository
try {
    $Head = & git rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $Head -cne $ExpectedCommit) {
        throw "Check out the reviewed package commit $ExpectedCommit."
    }
    $Status = & git status --porcelain
    if ($LASTEXITCODE -ne 0 -or $Status) { throw 'A clean package checkout is required.' }

    $Manifest = Join-Path $Package 'PACKAGE_SHA256SUMS'
    if ((Get-FileHash -LiteralPath $Manifest -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ExpectedManifest) {
        throw 'Package manifest checksum mismatch.'
    }
    foreach ($Line in (Get-Content -LiteralPath $Manifest)) {
        $Digest, $RelativePath = $Line -split '  ', 2
        if ((Get-FileHash -LiteralPath $RelativePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Digest) {
            throw "Package file checksum mismatch for $RelativePath."
        }
    }
    if ((Get-FileHash -LiteralPath $PlanFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $PlanSha256.ToLowerInvariant()) {
        throw 'Inspection plan checksum mismatch.'
    }
    $Plan = Get-Content -Raw -LiteralPath $PlanFile | ConvertFrom-Json
    if ($Mode -eq 'VerifyFiles') {
        Write-Output 'Package and supplied plan bytes verified offline. Capture authority is separate.'
        return
    }

    $Target = $Plan.target
    if ($Plan.version -ne 1 -or -not $Target) { throw 'Invalid inspection plan.' }
    $Required = @(
        $Plan.approvalToInspect, $Plan.ownershipAndAclEvidence, $Plan.runtimeRole, $Plan.objectOwner,
        $Target.providerProject, $Target.providerBranch, $Target.providerBindingRef,
        $Target.login, $Target.database, $Target.databaseOwner, $Target.schemaOwner
    )
    if (@($Required | Where-Object { [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0) {
        throw 'Complete the owner authorization, binding, login, ownership and ACL evidence fields before capture.'
    }
    if ($Target.endpoint -cnotmatch '^[A-Za-z0-9.-]+$' -or $Target.database -cnotmatch '^[A-Za-z0-9_.-]+$' -or
        $Target.port -lt 1 -or $Target.port -gt 65535 -or $Target.version -lt 180000 -or $Target.version -gt 189999 -or
        $Target.login -ceq $Plan.runtimeRole -or -not $Plan.additionalGrants) {
        throw 'Invalid target, reader separation or scoped ACL expectations.'
    }
    if (-not $EvidenceDir -or -not (Test-Path -LiteralPath $EvidenceDir -PathType Container)) {
        throw 'Provide the path to an existing access-restricted evidence directory.'
    }
    $PrivateDir = (Resolve-Path -LiteralPath $EvidenceDir).Path
    $Capture = Join-Path $PrivateDir 'baseline-capture.json'
    $Report = Join-Path $PrivateDir 'baseline-verification.json'
    if ((Test-Path -LiteralPath $Capture) -or (Test-Path -LiteralPath $Report)) {
        throw 'Use a fresh evidence directory to preserve prior captures.'
    }
    if (Test-Path Env:PGPASSWORD) { throw 'Use a private shell without PGPASSWORD. Use the approved libpq credentials or the psql prompt.' }
    $Node = (Get-Command node -CommandType Application).Source
    & $Node (Join-Path $Package 'verify.mjs') $PlanFile $PlanSha256.ToLowerInvariant() $ExpectedManifest $Capture --capture |
        Tee-Object -FilePath $Report
    if ($LASTEXITCODE -ne 0) { throw 'Baseline remains unverified. Preserve any capture and report privately.' }
}
finally {
    Pop-Location
}
