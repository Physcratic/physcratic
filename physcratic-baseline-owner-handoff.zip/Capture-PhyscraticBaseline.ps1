# PowerShell 7. VerifyFiles is offline. Capture requires separate owner authorization.
[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Repository,
    [Parameter(Mandatory)] [string] $PlanPath,
    [Parameter(Mandatory)] [ValidatePattern('^[0-9a-f]{64}$')] [string] $PlanSha256,
    [ValidateSet('VerifyFiles', 'Capture')] [string] $Mode = 'VerifyFiles',
    [string] $EvidenceDir
)

$ErrorActionPreference = 'Stop'
$ExpectedCommit = '0e100050c735f1a2dee328f1c0a96f837391553e'
$ExpectedManifest = 'cfa619af3cb85f9c72375308e11f275c91476c8940503279fad4c45f26c743fb'
$Package = 'scripts/retrospective-baseline'
$PlanFile = (Resolve-Path -LiteralPath $PlanPath).Path

Push-Location -LiteralPath $Repository
try {
    $Head = & git rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $Head -cne $ExpectedCommit) {
        throw "Check out the reviewed package commit $ExpectedCommit."
    }
    $Status = & git status --porcelain
    if ($LASTEXITCODE -ne 0 -or $Status) { throw 'A clean package checkout is required.' }

    $Manifest = Join-Path $Package 'PACKAGE_SHA256SUMS'
    if ((Get-FileHash -LiteralPath $Manifest -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ExpectedManifest) {
        throw 'Package manifest checksum mismatch.'
    }
    foreach ($Line in (Get-Content -LiteralPath $Manifest)) {
        $Digest, $RelativePath = $Line -split '  ', 2
        if ((Get-FileHash -LiteralPath $RelativePath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Digest) {
            throw "Package file checksum mismatch for $RelativePath."
        }
    }
    if ((Get-FileHash -LiteralPath $PlanFile -Algorithm SHA256).Hash.ToLowerInvariant() -cne $PlanSha256.ToLowerInvariant()) {
        throw 'Inspection plan checksum mismatch.'
    }
    $Plan = Get-Content -Raw -LiteralPath $PlanFile | ConvertFrom-Json
    if ($Mode -eq 'VerifyFiles') {
        Write-Output 'Package and supplied plan bytes verified offline. Capture authority is separate.'
        return
    }

    $Target = $Plan.target
    if ($Plan.version -ne 1 -or -not $Target) { throw 'Invalid inspection plan.' }
    $Required = @(
        $Plan.approvalToInspect, $Plan.ownershipAndAclEvidence, $Plan.runtimeRole, $Plan.objectOwner,
        $Target.providerProject, $Target.providerBranch, $Target.providerBindingRef,
        $Target.login, $Target.database, $Target.databaseOwner, $Target.schemaOwner
    )
    if (@($Required | Where-Object { [string]::IsNullOrWhiteSpace([string]$_) }).Count -gt 0) {
        throw 'Complete the owner authorization, binding, login, ownership and ACL evidence fields before capture.'
    }
    if ($Target.endpoint -cnotmatch '^[A-Za-z0-9.-]+$' -or $Target.database -cnotmatch '^[A-Za-z0-9_.-]+$' -or
        $Target.port -lt 1 -or $Target.port -gt 65535 -or $Target.version -lt 180000 -or $Target.version -gt 189999 -or
        $Target.login -ceq $Plan.runtimeRole -or -not $Plan.additionalGrants) {
        throw 'Invalid target, reader separation or scoped ACL expectations.'
    }
    if (-not $EvidenceDir -or -not (Test-Path -LiteralPath $EvidenceDir -PathType Container)) {
        throw 'Provide the path to an existing access-restricted evidence directory.'
    }
    $PrivateDir = (Resolve-Path -LiteralPath $EvidenceDir).Path
    $Capture = Join-Path $PrivateDir 'baseline-capture.json'
    $Report = Join-Path $PrivateDir 'baseline-verification.json'
    if ((Test-Path -LiteralPath $Capture) -or (Test-Path -LiteralPath $Report)) {
        throw 'Use a fresh evidence directory to preserve prior captures.'
    }
    if (Test-Path Env:PGPASSWORD) { throw 'Use a private shell without PGPASSWORD. psql prompts for the password.' }
    $Psql = (Get-Command psql -CommandType Application).Source
    $Node = (Get-Command node -CommandType Application).Source
    $Environment = [ordered]@{
        PGSERVICE = $null
        PGSERVICEFILE = $null
        PGHOSTADDR = $null
        PGOPTIONS = $null
        PGSSLMODE = 'verify-full'
        PGCONNECT_TIMEOUT = '5'
        PGCLIENTENCODING = 'UTF8'
    }
    $Previous = @{}
    foreach ($Name in $Environment.Keys) { $Previous[$Name] = [Environment]::GetEnvironmentVariable($Name) }

    try {
        foreach ($Name in $Environment.Keys) {
            if ($null -eq $Environment[$Name]) { Remove-Item -LiteralPath "Env:$Name" -ErrorAction SilentlyContinue }
            else { [Environment]::SetEnvironmentVariable($Name, $Environment[$Name]) }
        }
        $PsqlArgs = @(
            '-X', '-qAt', '-W', '--set=ON_ERROR_STOP=1',
            '--host', [string]$Target.endpoint, '--port', [string]$Target.port,
            '--dbname', [string]$Target.database, '--username', [string]$Target.login,
            '--set', "expected_database=$($Target.database)", '--set', "expected_login=$($Target.login)",
            '--set', "expected_version=$($Target.version)", '--set', "runtime_role=$($Plan.runtimeRole)",
            '--output', $Capture, '--file', (Join-Path $Package 'capture.sql')
        )
        & $Psql @PsqlArgs
        if ($LASTEXITCODE -ne 0) { throw 'Read-only capture failed. Preserve any partial capture privately.' }

        & $Node (Join-Path $Package 'verify.mjs') $PlanFile $PlanSha256.ToLowerInvariant() $ExpectedManifest $Capture |
            Tee-Object -FilePath $Report
        if ($LASTEXITCODE -ne 0) { throw 'Independent reconciliation is required. Preserve the capture and report.' }
    }
    finally {
        foreach ($Name in $Environment.Keys) {
            if ($null -eq $Previous[$Name]) { Remove-Item -LiteralPath "Env:$Name" -ErrorAction SilentlyContinue }
            else { [Environment]::SetEnvironmentVariable($Name, $Previous[$Name]) }
        }
    }
}
finally {
    Pop-Location
}
