# Physcratic retrospective baseline capture

Prepared 26 November 2026. The only database operation described here is the read-only capture from PR #259 with the same-session TLS correction in PR #262. The correction merged as `fb9155bed208301ba5e070e4c01a52d47f3e3947`. Separate owner authorization is required before connecting. The resulting evidence still needs independent review and explicit baseline acceptance.

## Review and seal the private plan

Copy `inspection-plan.prefilled.json` to a private file named `inspection-plan.approved.json`. Keep the draft as an evidence reference. The draft carries the verified direct inspection LOGIN and database owner neondb_owner, public schema owner pg_database_owner, pooled LOGIN physcratic_runtime_app, database neondb and server version 180007. Confirm that the independently verified target and binding evidence still apply. Complete the read-only authorization, provider binding and ownership/ACL evidence references. Confirm scoped object owners and exact grantors. Record exact exceptions with their own evidence.

The 54 candidate ACL entries come from the reviewed runtime, corrected favourites, B1 profiles and external-medal contracts. The draft excludes the superseded authored-problem `UPDATE(id)` grant. Reconcile the direct favourite-era user column SELECT grants separately from effective table SELECT, since the verifier compares exact ACL entries. Obtain independent evidence for scoped reader, staff, operator and eraser grants, transitive role memberships, prior approved PUBLIC revocations and default ACL changes. An empty list only becomes an expectation after that review. Preserve unexplained observed privileges as findings.

Review 0019, 0023, 0025 and 0026 individually. Add a migration to `expectedLaterMigrations` only when its installation is expected and supported by the exact recorded source and a separate authorization reference. The 0026 source pin in its owner package is `ee236380364a0a0f96145ac1ac753cb5cca11c4f`. Its narrow acknowledgement EXECUTE belongs to the separate 0026 track. Coordinate a quiet window with that operator. Capture again before acceptance if the target is changed. Continue to apply the existing Step 2 checks independently.

The owner and independent reviewer approve the completed plan and its exact SHA-256 through the restricted evidence channel. The runner pins package manifest SHA-256 `931e3dd8a9ec2c9fe4e203ec7523256d7ea9ee6d83f3f9faaa0fb262417dad84`. The draft SHA below verifies the supplied download. The approved plan has its own digest.

## Exact Windows commands

Use PowerShell 7, Node 22, Git, and PostgreSQL psql 15 or later. Store both handoff files and the completed plan outside the repository. Use an existing access-restricted evidence directory. Confirm the provider TLS trust bundle and configure `PGSSLROOTCERT` if your approved psql setup requires it. Use the existing approved libpq credentials. If psql needs a password, it prompts without echoing it. Use a private shell without transcripts or `PGPASSWORD`.

```powershell
$Repository = 'C:\Physcratic\physcratic'
$PackageCheckout = 'C:\Physcratic\reviewed-baseline-262'
$Handoff = 'C:\Physcratic\owner-handoff'
$Evidence = 'C:\Physcratic\private-evidence\baseline-262'
$PackageCommit = '9141a7acefcadbadff3cafacc81cf5e31f09bf32'
$CaptureScript = Join-Path $Handoff 'Capture-PhyscraticBaseline.ps1'
$Draft = Join-Path $Handoff 'inspection-plan.prefilled.json'
$Approved = Join-Path $Evidence 'inspection-plan.approved.json'
$DraftSha = 'f5d2765c8f63ec30a19d1012698cf344523a04dc4eb0e6355b557a0f4012bb38'
$RunnerSha = '19a0fc8bb357630653d28c9f932b8cf5fccd905a757feefeac8c394295a9d9e2'
if ((Get-FileHash -LiteralPath $CaptureScript -Algorithm SHA256).Hash.ToLowerInvariant() -cne $RunnerSha) { throw 'PowerShell helper checksum mismatch' }

git -C $Repository fetch origin main
if ($LASTEXITCODE -ne 0) { throw 'Fetch failed' }
git -C $Repository merge-base --is-ancestor $PackageCommit origin/main
if ($LASTEXITCODE -ne 0) { throw 'Reviewed package commit is absent from main' }
git -C $Repository -c core.autocrlf=false worktree add --detach $PackageCheckout $PackageCommit
if ($LASTEXITCODE -ne 0) { throw 'Worktree creation failed' }

# Offline. Verifies the checkout, manifest, pinned files and supplied draft bytes.
& $CaptureScript -Repository $PackageCheckout -PlanPath $Draft -PlanSha256 $DraftSha -Mode VerifyFiles

if (-not (Test-Path -LiteralPath $Approved)) { Copy-Item -LiteralPath $Draft -Destination $Approved }
# Use a private editor and save UTF-8 without a BOM. Get the independent digest
# from the approved evidence channel after the owner and reviewer sign off.
$ApprovedSha = (Read-Host 'Independently approved plan SHA-256').Trim().ToLowerInvariant()
& $CaptureScript -Repository $PackageCheckout -PlanPath $Approved -PlanSha256 $ApprovedSha -Mode VerifyFiles

# Run only after explicit read-only connection authorization for this target.
& $CaptureScript -Repository $PackageCheckout -PlanPath $Approved -PlanSha256 $ApprovedSha -Mode Capture -EvidenceDir $Evidence
```

Keep `baseline-capture.json`, `baseline-verification.json` and the sealed plan together in the restricted evidence directory. Retain the output even when it contains findings. A successful comparison reports `CATALOGUE_MATCH_PENDING_REVIEW`. The independent reviewer still reconciles Step 2 and later changes, and the owner records a separate explicit acceptance decision against the exact capture, plan, ledger and manifest digests. Phase 5B stays on hold until then. Account erasure and recovery keep their separate activation gates.

The runner uses verify-full and observes client TLS from the same psql connection as the read-only snapshot. In the output, client transport evidence and the backend SSL flag and protocol have separate fields. The backend can report ssl=false and protocol=null. Compare the actual new observations during independent review. The earlier preflight supplies context for review.
