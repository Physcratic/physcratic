# Phase 5B second Windows rehearsal

Use Windows PowerShell 5.1 and the first kit's existing clean checkout and installed dependencies. Leave the first cluster stopped. Extract into a new kit directory. The PostgreSQL fixture port is always 55439 with a loopback-only listener. Keep the generated files under your private Windows user profile. The default instructions include migration 0025 on the synthetic cluster so the test covers the combined case. Its Production release stays separate.

~~~powershell
& {
    $ErrorActionPreference = 'Stop'
    $Pack = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Rehearsal-Kit'
    $Runner = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Kit\Invoke-Phase5bNative.ps1'
    $Repo = Join-Path $env:USERPROFILE 'physcratic-phase5b'
    $Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
    & $Runner -Action Prepare -Repo $Repo -ClusterRoot $Fresh -Port 55439 -AppPort 3317 -IncludeCompletions
    & (Join-Path $Pack 'Save-Phase5bCheckpoint-Pinned.ps1') -ClusterRoot $Fresh
}
~~~

The checkpoint must show A=1/1 B=1/1, Registered=1 Held=1 Outbox=0 OtherConnections=0, WithCompletions=True AMarks=1 ALimiter=1, and Checkpoint=verified. A failure stops the rehearsal before opening the app. The PowerShell Env provider removes inherited libpq variables and restores the shell state afterward.

~~~powershell
$Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
$Runner = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Kit\Invoke-Phase5bNative.ps1'
& $Runner -Action StartApp -ClusterRoot $Fresh
~~~

Use http://localhost:3317/sign-in. Sign in as phase5b-a@example.invalid with Phase5B-local-a-only! and use Settings, Delete account, DELETE MY ACCOUNT. Expect database erasure with one file pending. In a private window B (phase5b-b@example.invalid / Phase5B-local-b-only!) can still sign in. Leave files pending. Stop the app with Ctrl+C and leave the disposable database up.

~~~powershell
$Fresh = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-DB-Rehearsal2'
$Pack = Join-Path $env:LOCALAPPDATA 'Physcratic-Phase5B-Rehearsal-Kit'
$Recovery = Join-Path $Pack 'Phase5b-Recovery.ps1'
& $Recovery -Action CheckErasure -ClusterRoot $Fresh
& $Recovery -Action Restore -ClusterRoot $Fresh
~~~

The check expects A absent, B matching its fingerprint and one pending outbox job with its hold. Record the original synthetic receipt privately. Restore creates a separate database in the same disposable cluster and checks that app roles cannot connect to it. Expect A to reappear in the isolated restored copy, B's fingerprint to match, and one held marker with no pending outbox job in the restored state. Always leave the recovered database disconnected from the app.

The independent reviewer compares the pre-erasure checkpoint, original source receipt and generated approval target. The reviewer edits only the three blank authorization fields in phase5b-recovery-approval.json as shown below, then supplies the digest privately through your independent review channel. Keep the exact returned file in the fresh cluster root. Pending independent reviewer means stop after Restore.

~~~powershell
$Approval = Join-Path $Fresh 'phase5b-recovery-approval.json'
$Record = Get-Content -Raw -Encoding UTF8 -LiteralPath $Approval | ConvertFrom-Json
$Record.reviewer = (Read-Host 'Independent reviewer name').Trim()
$Now = [DateTime]::UtcNow
$Record.approvedAt = $Now.ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
$Record.expiresAt = $Now.AddHours(2).ToString('yyyy-MM-ddTHH:mm:ss.fffZ')
[IO.File]::WriteAllText($Approval, ($Record | ConvertTo-Json -Depth 8), [Text.UTF8Encoding]::new($false))
(Get-FileHash -LiteralPath $Approval -Algorithm SHA256).Hash.ToLowerInvariant()
~~~

Operator commands after receiving the exact file and digest:

~~~powershell
$ApprovedSha = (Read-Host 'SHA-256 supplied independently by reviewer').Trim().ToLowerInvariant()
& $Recovery -Action Reconcile -ClusterRoot $Fresh -ApprovalSha256 $ApprovedSha
& $Recovery -Action Reconcile -ClusterRoot $Fresh -ApprovalSha256 $ApprovedSha
~~~

Expect RECONCILED followed by ALREADY_RECONCILED, each with A absent, B unchanged, Held=1, Pending=1. The replay checks the exact source receipt, installed erasure routine fingerprints, archive SHA, target and deletion scope. After recording results, stop the second cluster with the original kit's Stop action and the fresh path. Preserve both data directories.

Tested end to end with native PostgreSQL 18.7, including a real custom dump and restore, on Linux with PowerShell 7. Windows 5.1 execution remains to be confirmed. This is synthetic recovery evidence with a database-only pending job.
