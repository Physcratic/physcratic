[CmdletBinding()]
param(
 [Parameter(Mandatory)][ValidateSet('CheckErasure','Restore','Reconcile')][string]$Action,
 [Parameter(Mandatory)][string]$ClusterRoot,
 [string]$ApprovalSha256
)
$ErrorActionPreference = 'Stop'
$Node = (Get-Command node -CommandType Application | Select-Object -First 1).Source
$Restore = (Get-Command pg_restore -CommandType Application | Select-Object -First 1).Source
& $Node (Join-Path $PSScriptRoot 'recovery.mjs') $Action $ClusterRoot $Restore "$ApprovalSha256"
if ($LASTEXITCODE -ne 0) { throw 'Rehearsal stopped. Keep the recovery DB isolated.' }
