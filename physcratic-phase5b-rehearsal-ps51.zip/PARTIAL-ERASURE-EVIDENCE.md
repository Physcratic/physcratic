# Phase 5B first Windows synthetic run

Owner-reported on 26 November 2026, Singapore. Synthetic A was erased before the pre-erasure checkpoint was captured.

- A account row and credentials absent.
- B survives.
- Held upload markers: 1.
- Outbox rows for the held path: 1.

Accepted as partial synthetic erasure evidence. The owner report did not include the outbox row's state, a before/after B fingerprint, a pre-erasure backup or a replay outcome. The held marker remains unresolved. This entry establishes no provider cleanup or recovery result. Preserve the first cluster's data and diagnostic output separately from the next rehearsal.
