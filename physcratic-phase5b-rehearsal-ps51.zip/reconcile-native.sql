BEGIN ISOLATION LEVEL SERIALIZABLE;
SET LOCAL search_path = pg_catalog, public, pg_temp;
SET LOCAL timezone = 'UTC';
SET LOCAL lock_timeout = '4s';
SET LOCAL statement_timeout = '35s';
SET LOCAL idle_in_transaction_session_timeout = '15s';
SET LOCAL transaction_timeout = '40s';
SET LOCAL log_statement = 'none';
SET LOCAL log_min_error_statement = 'panic';
SET LOCAL log_parameter_max_length_on_error = 0;

DO $target$
BEGIN
 IF current_database() <> 'physcratic_restore_test' OR session_user <> 'phase5b_cluster_admin'
  OR inet_client_addr() IS DISTINCT FROM '127.0.0.1'::inet
  OR inet_server_addr() IS DISTINCT FROM '127.0.0.1'::inet
  OR inet_server_port() IS DISTINCT FROM 55439 OR current_setting('listen_addresses') <> '127.0.0.1'
  OR EXISTS (SELECT FROM pg_roles WHERE rolname IN ('phase5b_runtime','phase5b_eraser','phase5b_operator')
             AND has_database_privilege(oid,current_database(),'CONNECT'))
  OR current_setting('server_version_num') <> '180007' OR pg_is_in_recovery()
  OR current_setting('session_replication_role') <> 'origin'
  OR NOT EXISTS (SELECT FROM pg_database WHERE datname=current_database() AND datdba='phase5b_owner'::regrole)
  OR EXISTS (SELECT FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid())
 THEN
  RAISE EXCEPTION 'Restore database is not isolated';
 END IF;
END $target$;

SET LOCAL ROLE phase5b_owner;
-- APPROVAL PARAMETERS --
-- Node loads the approval and nonce as parameters inside this transaction.

DO $reconcile$
DECLARE
 approved jsonb := convert_from(decode(current_setting('physcratic.restore_approval'), 'base64'), 'UTF8')::jsonb;
 approval_nonce text := current_setting('physcratic.restore_nonce');
 subject text := approved->>'subjectId';
 actual_fingerprint text;
 receipt_actor_tag text;
 receipt_expires_at timestamptz;
 companion_definitions text;
 trigger_definitions text;
 account_foreign_keys jsonb;
 completion_relation regclass;
 has_completion_rows boolean;
 eraser regprocedure := 'public.account_deletion_execute(text,text,text,text)'::regprocedure;
 definition text := pg_get_functiondef(eraser);
 owned uuid[];
 approved_rights jsonb;
 current_rights jsonb;
 already_reconciled boolean;
 outcome jsonb;
BEGIN
 SELECT encode(sha256(convert_to(string_agg(pg_get_functiondef(p.oid), E'\n' ORDER BY p.proname),'UTF8')),'hex')
 INTO companion_definitions FROM pg_proc p
 WHERE p.pronamespace='public'::regnamespace AND p.proowner=current_user::regrole AND p.proname IN (
  'account_deletion_policy_ready', 'account_deletion_inventory', 'account_deletion_mutation_allowed',
  'account_deletion_permit_delete', 'account_deletion_permit_update', 'account_deletion_receipt',
  'account_deletion_queue', 'account_deletion_cleanup', 'account_deletion_upload_guard',
  'account_deletion_guard_continuing_display');
 SELECT encode(sha256(convert_to(string_agg(pg_get_triggerdef(t.oid), E'\n' ORDER BY c.relname,t.tgname),'UTF8')),'hex')
 INTO trigger_definitions FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
 WHERE c.relnamespace='public'::regnamespace AND t.tgenabled IN ('O','A')
 AND t.tgname IN ('account_deletion_guard_continuing_display','account_deletion_reserve_upload','account_deletion_preserve_upload');

 IF NOT EXISTS (SELECT FROM pg_proc WHERE oid=eraser AND proowner=current_user::regrole)
    OR encode(sha256(convert_to(definition,'UTF8')),'hex') <> '4ad545c7e20c98c37347b072e022e29cb41f0e476d1761368420781debeaea5a'
    OR companion_definitions IS DISTINCT FROM '625831a6db0f0ec2299bad6f1a903ca7cec2928ebfe8d9f046565be1ca94cd05'
    OR trigger_definitions IS DISTINCT FROM 'c62156768bc1cfa062956b193e0066380e5b7d71b62d97c4b01d10a0c3fadd6a'
 THEN
  RAISE EXCEPTION 'Installed erasure revision is not reviewed';
 END IF;

 -- Guard the cascade and anonymization paths relied on by the eraser, including
 -- transitive deletes. The disposable fixture pins the PostgreSQL 18.7 output.
 WITH RECURSIVE parents(rel) AS (
  SELECT 'public."user"'::regclass
  UNION
  SELECT c.conrelid::regclass FROM pg_constraint c JOIN parents p ON c.confrelid=p.rel
  WHERE c.contype='f' AND c.confdeltype='c'
 ), dependencies AS (
  SELECT CASE c.conrelid
           WHEN to_regclass('public.community_restriction') THEN '0019'
           WHEN to_regclass('public.personal_problem_completion') THEN '0025'
           WHEN to_regclass('public.personal_completion_write_limit') THEN '0025'
           ELSE 'core'
         END AS scope,
         c.conrelid::regclass::text AS relation,
         pg_get_constraintdef(c.oid) AS definition,
         c.convalidated, c.conenforced,
         (SELECT string_agg(t.tgenabled::text,'' ORDER BY t.tgenabled)
          FROM pg_trigger t WHERE t.tgconstraint=c.oid AND t.tgisinternal) AS triggers
  FROM pg_constraint c JOIN parents p ON c.confrelid=p.rel
  WHERE c.contype='f' AND c.confdeltype IN ('c','n','d')
 ), fingerprints AS (
  SELECT d.scope, encode(sha256(convert_to(jsonb_agg(
      jsonb_build_array(d.relation,d.definition,d.convalidated,d.conenforced,d.triggers)
      ORDER BY d.relation COLLATE "C", d.definition COLLATE "C")::text,'UTF8')),'hex') AS digest
  FROM dependencies d GROUP BY d.scope
 )
 SELECT jsonb_object_agg(scope,digest) INTO account_foreign_keys FROM fingerprints;
 IF account_foreign_keys->>'core' IS DISTINCT FROM '92b822cec623067975001dfad6f1e5b5cd5f3f4a46567443f23dbd921a6b8da5'
  OR (to_regclass('public.community_restriction') IS NOT NULL AND
      account_foreign_keys->>'0019' IS DISTINCT FROM '2bd74b4041ab6e7aeac58d5711607717fe0dca1077175938052914f1c7c4defd')
  OR ((to_regclass('public.personal_problem_completion') IS NOT NULL
       OR to_regclass('public.personal_completion_write_limit') IS NOT NULL) AND
      account_foreign_keys->>'0025' IS DISTINCT FROM '1b36e6a00514e65643cd08255571782546a475cd7f7f11bb41b5aabd65214fb2')
 THEN
  RAISE EXCEPTION 'Account erasure foreign keys differ from the reviewed fixture';
 END IF;

 IF (approved->>'approvedAt')::timestamptz > clock_timestamp()
    OR (approved->>'expiresAt')::timestamptz <= clock_timestamp() THEN
  RAISE EXCEPTION 'Erasure authorization is outside its approved window';
 END IF;
 IF subject !~ '^synthetic-[A-Za-z0-9-]{1,100}$' OR approved->>'database' <> current_database() THEN
  RAISE EXCEPTION 'Authorized restored account does not match';
 END IF;

 SELECT encode(sha256(convert_to(jsonb_build_array(id, "createdAt")::text,'UTF8')),'hex')
 INTO actual_fingerprint FROM public."user" WHERE id=subject FOR UPDATE;
 SELECT r.actor_tag, r.expires_at INTO receipt_actor_tag, receipt_expires_at
 FROM public.account_deletion_receipt_store r WHERE r.nonce=approval_nonce;
 already_reconciled := FOUND;
 IF already_reconciled THEN
  IF actual_fingerprint IS NOT NULL OR receipt_expires_at<=clock_timestamp()
     OR receipt_actor_tag IS DISTINCT FROM encode(sha256(convert_to(subject||':'||approval_nonce,'UTF8')),'hex') THEN
   RAISE EXCEPTION 'Existing reconciliation receipt conflicts with restored account';
  END IF;
 ELSE
  IF actual_fingerprint IS NULL OR actual_fingerprint IS DISTINCT FROM approved->>'subjectFingerprint' THEN
   RAISE EXCEPTION 'Authorized restored account does not match';
  END IF;
  SELECT coalesce(array_agg(p.id),'{}') INTO owned
  FROM (SELECT id FROM public.authored_problem WHERE owner_id=subject ORDER BY id FOR UPDATE) p;
 END IF;

 SELECT coalesce(jsonb_agg(item ORDER BY item->>'problemId'),'[]') INTO approved_rights
 FROM jsonb_array_elements(approved->'publications') AS items(item);
 IF NOT already_reconciled THEN
  SELECT coalesce(jsonb_agg(jsonb_build_object('problemId',p.id,'revisionId',p.published_revision_id,
         'digest',encode(sha256(convert_to(jsonb_build_array(r.rights_basis,r.review_reference)::text,'UTF8')),'hex'))
         ORDER BY p.id),'[]')
  INTO current_rights FROM public.authored_problem p JOIN public.account_deletion_publication r ON r.problem_id=p.id
  WHERE p.id=ANY(owned) AND p.state='published' AND r.continuing_display_authorized
   AND r.reviewed_revision_id=p.published_revision_id;
  IF current_rights IS DISTINCT FROM approved_rights THEN
   RAISE EXCEPTION 'Continuing publication rights differ from independent approval';
  END IF;

  -- The installed routine above is pinned byte for byte. Only this connection can
  -- resolve the temporary copy. The independently authorized subject is locked above.
  definition := replace(definition,
   'public.account_deletion_execute(actor text, session_token text, credential_hash text, nonce_hash text)',
   'pg_temp.restore_erasure_execute(actor text, nonce_hash text)');
  definition := replace(definition, 'SECURITY DEFINER', 'SECURITY INVOKER');
  definition := replace(definition, ' PERFORM account_deletion_auth(actor,session_token,credential_hash);',
   ' -- Independent authorization and exact subject row lock verified by the local restore transaction.');
  EXECUTE definition;
  REVOKE ALL ON FUNCTION pg_temp.restore_erasure_execute(text,text) FROM PUBLIC;
  outcome := pg_temp.restore_erasure_execute(subject, approval_nonce);
  DROP FUNCTION pg_temp.restore_erasure_execute(text,text);

  IF coalesce(outcome->>'state','') NOT IN ('complete','database-erased-cleanup-pending') THEN
   RAISE EXCEPTION 'Erasure did not commit the expected database state';
  END IF;
 ELSE
  SELECT coalesce(array_agg((item->>'problemId')::uuid),'{}') INTO owned
  FROM jsonb_array_elements(approved_rights) AS items(item);
 END IF;

 IF EXISTS (SELECT FROM public."user" WHERE id=subject)
    OR EXISTS (SELECT FROM public.session WHERE "userId"=subject)
    OR EXISTS (SELECT FROM public.account WHERE "userId"=subject) THEN
  RAISE EXCEPTION 'Erasure did not commit the expected database state';
 END IF;
 FOREACH completion_relation IN ARRAY ARRAY[
  to_regclass('public.personal_problem_completion'), to_regclass('public.personal_completion_write_limit')
 ] LOOP
  IF completion_relation IS NOT NULL THEN
   EXECUTE format('SELECT EXISTS (SELECT FROM %s WHERE user_id=$1)',completion_relation) INTO has_completion_rows USING subject;
   IF has_completion_rows THEN
    RAISE EXCEPTION 'Erasure did not commit the expected database state';
   END IF;
  END IF;
 END LOOP;

 SELECT coalesce(jsonb_agg(jsonb_build_object('problemId',p.id,'revisionId',p.published_revision_id,
        'digest',encode(sha256(convert_to(jsonb_build_array(r.rights_basis,r.review_reference)::text,'UTF8')),'hex'))
        ORDER BY p.id),'[]')
 INTO current_rights FROM public.authored_problem p JOIN public.account_deletion_publication r ON r.problem_id=p.id
 WHERE p.id=ANY(owned) AND p.state='published' AND p.owner_id='__physcratic_deleted_principal_v1__'
  AND r.continuing_display_authorized AND r.reviewed_revision_id=p.published_revision_id;
 IF current_rights IS DISTINCT FROM approved_rights THEN
  RAISE EXCEPTION 'Continuing publication rights differ from independent approval';
 END IF;

 -- Existing retained obligations, including any other account's jobs, remain in
 -- place. A signed pending obligation lost from the recovery point prevents commit.
 IF EXISTS (SELECT FROM jsonb_to_recordset(approved->'cleanup') AS expected(provider text,pathname text,held boolean)
            WHERE NOT EXISTS (SELECT FROM public.account_deletion_outbox o
                              WHERE o.provider=expected.provider AND o.pathname=expected.pathname AND o.state<>'complete')
            OR (expected.held AND NOT EXISTS (SELECT FROM public.account_deletion_pending_upload h
                              WHERE h.provider=expected.provider AND h.pathname=expected.pathname)))
 THEN
  RAISE EXCEPTION 'Expected cleanup obligation or upload hold is absent';
 END IF;
 IF (approved->>'expiresAt')::timestamptz <= clock_timestamp() THEN
  RAISE EXCEPTION 'Erasure authorization is outside its approved window';
 END IF;
 PERFORM set_config('physcratic.restore_result',
  CASE WHEN already_reconciled THEN 'ALREADY_RECONCILED' ELSE 'RECONCILED' END, true);
END $reconcile$;

