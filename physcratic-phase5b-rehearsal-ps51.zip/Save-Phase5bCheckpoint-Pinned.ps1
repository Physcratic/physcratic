[CmdletBinding()]
param([Parameter(Mandatory)][string] $ClusterRoot)

& {
    $ErrorActionPreference = 'Stop'
    $Root = (Resolve-Path -LiteralPath $ClusterRoot).Path
    $State = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $Root 'fixture-state.json') | ConvertFrom-Json
    $Db = 'physcratic_authoring_test'
    $Port = 55439
    $Data = [IO.Path]::GetFullPath((Join-Path $Root 'data'))
    if ([int]$State.port -ne $Port -or $State.secrets.admin -cnotmatch '^[a-f0-9]{64}$' -or
        [IO.Path]::GetFullPath($State.data) -ne $Data) {
        throw 'Unexpected Phase 5B cluster identity'
    }

    $Dump = Join-Path $Root 'phase5b-before-a.dump'
    $Evidence = Join-Path $Root 'phase5b-before-a.json'
    if ((Test-Path -LiteralPath $Dump) -or (Test-Path -LiteralPath $Evidence)) {
        throw 'Checkpoint already exists. Keep it and report its status.'
    }

    $Psql = (Get-Command psql -CommandType Application | Select-Object -First 1).Source
    $PgDump = (Get-Command pg_dump -CommandType Application | Select-Object -First 1).Source
    $PgRestore = (Get-Command pg_restore -CommandType Application | Select-Object -First 1).Source
    $DbArgs = @('-h','127.0.0.1','-p',"$Port",'-U','phase5b_cluster_admin','-d',$Db,'-w')
    # PS 7.5 distinguishes an empty environment value from an absent variable.
    # Remove inherited libpq variables through the Env provider, then restore them.
    $Saved = @(Get-ChildItem Env: | Where-Object { $_.Name -like 'PG*' })
    $Overrides = @{
        PGSSLMODE = 'disable'
        PGGSSENCMODE = 'disable'
        PGCONNECT_TIMEOUT = '5'
        PGCLIENTENCODING = 'UTF8'
        PGPASSWORD = $State.secrets.admin
    }
    try {
        foreach ($Entry in $Saved) {
            Remove-Item -LiteralPath ('Env:' + $Entry.Name)
        }
        foreach ($Name in $Overrides.Keys) {
            Set-Item -LiteralPath ('Env:' + $Name) -Value $Overrides[$Name]
        }
        $Identity = & $Psql @DbArgs -XqAt -v ON_ERROR_STOP=1 -c "SELECT current_setting('data_directory') WHERE current_database()='physcratic_authoring_test' AND session_user='phase5b_cluster_admin' AND inet_server_addr()='127.0.0.1' AND inet_server_port()=$Port AND current_setting('server_version_num')='180007'"
        if ($LASTEXITCODE -ne 0 -or -not $Identity -or [IO.Path]::GetFullPath($Identity) -ne $Data) {
            throw 'Connection did not match the disposable cluster'
        }

        $Before = @'
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL timezone='UTC';
SET LOCAL statement_timeout='5s';
SELECT (to_regclass('public.personal_problem_completion') IS NOT NULL
    AND to_regclass('public.personal_completion_write_limit') IS NOT NULL) AS has_0025 \gset
\if :has_0025
SELECT coalesce((SELECT jsonb_agg(to_jsonb(c) ORDER BY c.problem_key)::text FROM public.personal_problem_completion c WHERE c.user_id='synthetic-phase5b-b'),'[]') AS b_marks,
       coalesce((SELECT to_jsonb(l)::text FROM public.personal_completion_write_limit l WHERE l.user_id='synthetic-phase5b-b'),'null') AS b_limit,
       (SELECT count(*) FROM public.personal_problem_completion WHERE user_id='synthetic-phase5b-a') AS a_marks,
       (SELECT count(*) FROM public.personal_completion_write_limit WHERE user_id='synthetic-phase5b-a') AS a_limit \gset
\else
\set b_marks '[]'
\set b_limit 'null'
\set a_marks 0
\set a_limit 0
\endif
SELECT jsonb_build_object(
 'capturedAtUtc',statement_timestamp(),
 'otherConnections',(SELECT count(*) FROM pg_stat_activity WHERE datname=current_database()
                      AND pid<>pg_backend_pid() AND backend_type='client backend'),
 'withCompletions',:'has_0025'::boolean,
 'aUsers',(SELECT count(*) FROM public."user" WHERE id='synthetic-phase5b-a'),
 'aCredentials',(SELECT count(*) FROM public.account WHERE "userId"='synthetic-phase5b-a'),
 'aMarks',:'a_marks'::integer,
 'aLimiter',:'a_limit'::integer,
 'aFingerprint',(SELECT encode(sha256(convert_to(jsonb_build_array(id,"createdAt")::text,'UTF8')),'hex')
                 FROM public."user" WHERE id='synthetic-phase5b-a'),
 'bUsers',(SELECT count(*) FROM public."user" WHERE id='synthetic-phase5b-b'),
 'bCredentials',(SELECT count(*) FROM public.account WHERE "userId"='synthetic-phase5b-b'),
 'bFingerprint',encode(sha256(convert_to(jsonb_build_array(
   (SELECT to_jsonb(u) FROM public."user" u WHERE id='synthetic-phase5b-b'),
   (SELECT jsonb_agg(jsonb_build_array(id,"providerId","createdAt") ORDER BY id)
    FROM public.account WHERE "userId"='synthetic-phase5b-b'),
   :'b_marks'::jsonb, :'b_limit'::jsonb)::text,'UTF8')),'hex'),
 'aRegistered',(SELECT count(*) FROM public.solution_evidence WHERE "userId"='synthetic-phase5b-a'
                AND pathname='solution-evidence/synthetic-phase5b/held-demo.png'),
 'held',(SELECT count(*) FROM public.account_deletion_pending_upload WHERE provider='author'
         AND pathname='solution-evidence/synthetic-phase5b/held-demo.png'),
 'outbox',(SELECT count(*) FROM public.account_deletion_outbox WHERE provider='author'
           AND pathname='solution-evidence/synthetic-phase5b/held-demo.png')
);
ROLLBACK;
'@ | & $Psql @DbArgs -XqAt -v ON_ERROR_STOP=1 -f -
        if ($LASTEXITCODE -ne 0) { throw 'Pre-erasure fixture check failed' }
        $Check = $Before | ConvertFrom-Json
        if ($Check.otherConnections -ne 0 -or $Check.aUsers -ne 1 -or $Check.aCredentials -ne 1 -or
            $Check.bUsers -ne 1 -or $Check.bCredentials -ne 1 -or $Check.aRegistered -ne 1 -or
            $Check.held -ne 1 -or $Check.outbox -ne 0 -or
            $Check.aFingerprint -cnotmatch '^[a-f0-9]{64}$' -or
            $Check.bFingerprint -cnotmatch '^[a-f0-9]{64}$' -or
            $Check.withCompletions -ne [bool]$State.withCompletions -or
            ($Check.withCompletions -and ($Check.aMarks -ne 1 -or $Check.aLimiter -ne 1))) {
            throw 'Unexpected pre-erasure state. Keep A intact and report the counts.'
        }

        & $PgDump @DbArgs -Fc -f $Dump
        if ($LASTEXITCODE -ne 0) { throw 'Dump failed. Do not erase A.' }
        $Toc = & $PgRestore -l $Dump
        if ($LASTEXITCODE -ne 0 -or -not ($Toc -match 'TABLE DATA public account_deletion_pending_upload') -or
            -not ($Toc -match 'TABLE DATA public solution_evidence')) {
            throw 'Checkpoint archive verification failed. Do not erase A.'
        }
        $Check | Add-Member -NotePropertyName dumpSha256 -NotePropertyValue (
            (Get-FileHash -LiteralPath $Dump -Algorithm SHA256).Hash.ToLowerInvariant()
        )
        [IO.File]::WriteAllText($Evidence, ($Check | ConvertTo-Json), [Text.UTF8Encoding]::new($false))
        "A=$($Check.aUsers)/$($Check.aCredentials) B=$($Check.bUsers)/$($Check.bCredentials)"
        "Registered=$($Check.aRegistered) Held=$($Check.held) Outbox=$($Check.outbox) OtherConnections=$($Check.otherConnections)"
        "WithCompletions=$($Check.withCompletions) AMarks=$($Check.aMarks) ALimiter=$($Check.aLimiter)"
        'Checkpoint=verified'
    } finally {
        foreach ($Name in $Overrides.Keys) {
            $EnvPath = 'Env:' + $Name
            if (Test-Path -LiteralPath $EnvPath) { Remove-Item -LiteralPath $EnvPath }
        }
        foreach ($Entry in $Saved) {
            Set-Item -LiteralPath ('Env:' + $Entry.Name) -Value $Entry.Value
        }
    }
}
