import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readFile, realpath, writeFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { join, resolve } from 'node:path';

const [action, dir, restoreExe, expectedApproval] = process.argv.slice(2);
const root = await realpath(resolve(dir));
const state = JSON.parse(await readFile(join(root, 'fixture-state.json'), 'utf8'));
const before = JSON.parse(await readFile(join(root, 'phase5b-before-a.json'), 'utf8'));
const sha = value => createHash('sha256').update(value).digest('hex');
const hex = /^[a-f0-9]{64}$/;
assert.equal(state.port, 55439);
assert.equal(await realpath(state.data), await realpath(join(root, 'data')));
assert.match(state.secrets.admin, hex);
assert.match(before.aFingerprint, hex);
assert.match(before.bFingerprint, hex);
assert.equal(before.withCompletions, state.withCompletions);
const dump = join(root, 'phase5b-before-a.dump');
assert.equal(sha(await readFile(dump)), before.dumpSha256);
const pinMigrations = {
  '0018_account_deletion.up.sql': '378ff9140a5eab9d62c70505eb764ad1f621ebe26f6d840c62826aee00d61cda',
  '0026_account_deletion_blockers.up.sql': '3b904c1eb01fc75e5446744acc90474cdbe4aba62c6dffc95b9f7c35bfc6c78a',
};
for (const [name, expected] of Object.entries(pinMigrations)) {
  const sql = (await readFile(join(state.repo, 'migrations', name), 'utf8')).replaceAll('\r\n', '\n');
  assert.equal(sha(sql), expected, 'Reviewed migration bytes differ');
}
const requireFromRepo = createRequire(join(state.repo, 'package.json'));
const { Client } = requireFromRepo('pg');
const admin = 'phase5b_cluster_admin';
const source = 'physcratic_authoring_test';
const target = 'physcratic_restore_test';
const actor = 'synthetic-phase5b-a';
const heldPath = 'solution-evidence/synthetic-phase5b/held-demo.png';
const approvalPath = join(root, 'phase5b-recovery-approval.json');

async function targetIdentity(client) {
  const { rows: [row] } = await client.query(
    "SELECT oid::text AS id, datdba='phase5b_owner'::regrole AS owned," +
    " (SELECT count(*)::int FROM pg_roles WHERE rolname IN ('phase5b_runtime','phase5b_eraser','phase5b_operator') AND NOT has_database_privilege(oid,current_database(),'CONNECT')) AS denied" +
    " FROM pg_database WHERE datname=current_database()",
  );
  assert.equal(row.owned, true);
  assert.equal(row.denied, 3);
  return row.id;
}

async function use(database, operation) {
  const client = new Client({
    host: '127.0.0.1', port: 55439, database, user: admin, password: state.secrets.admin,
    ssl: false, connectionTimeoutMillis: 5000, statement_timeout: 40000,
  });
  await client.connect();
  try {
    const { rows: [id] } = await client.query(
      "SELECT current_database() AS db, session_user AS login, current_setting('data_directory') AS data," +
      " current_setting('server_version_num') AS version, host(inet_server_addr()) AS bind," +
      " inet_server_port() AS port, current_setting('listen_addresses') AS listen",
    );
    assert.deepEqual([id.db,id.login,id.version,id.bind,id.port,id.listen], [database,admin,'180007','127.0.0.1',55439,'127.0.0.1']);
    assert.equal(await realpath(id.data), await realpath(state.data));
    return await operation(client);
  } finally { await client.end(); }
}

async function check(client, erased) {
  await client.query("SET LOCAL timezone='UTC'");
  const marks = state.withCompletions ?
    "(SELECT coalesce(jsonb_agg(to_jsonb(c) ORDER BY c.problem_key),'[]') FROM public.personal_problem_completion c WHERE c.user_id='synthetic-phase5b-b')" : "'[]'::jsonb";
  const limiter = state.withCompletions ?
    "(SELECT to_jsonb(l) FROM public.personal_completion_write_limit l WHERE l.user_id='synthetic-phase5b-b')" : "'null'::jsonb";
  const { rows: [row] } = await client.query([
    "SELECT (SELECT count(*)::int FROM public.\"user\" WHERE id=$1) AS a,",
    "(SELECT count(*)::int FROM public.account WHERE \"userId\"=$1) AS credential,",
    "(SELECT count(*)::int FROM public.session WHERE \"userId\"=$1) AS sessions,",
    "(SELECT count(*)::int FROM public.solution_evidence WHERE \"userId\"=$1 AND pathname=$2) AS registered,",
    "(SELECT count(*)::int FROM public.account_deletion_pending_upload WHERE provider='author' AND pathname=$2) AS held,",
    "(SELECT coalesce(array_agg(o.state::text ORDER BY o.id),'{}') FROM public.account_deletion_outbox o WHERE provider='author' AND pathname=$2) AS states,",
    "(SELECT encode(sha256(convert_to(jsonb_build_array(id,\"createdAt\")::text,'UTF8')),'hex') FROM public.\"user\" WHERE id=$1) AS a_fingerprint,",
    "encode(sha256(convert_to(jsonb_build_array((SELECT to_jsonb(u) FROM public.\"user\" u WHERE id='synthetic-phase5b-b'),",
    "(SELECT jsonb_agg(jsonb_build_array(id,\"providerId\",\"createdAt\") ORDER BY id) FROM public.account WHERE \"userId\"='synthetic-phase5b-b'),",
    marks + ',' + limiter + ")::text,'UTF8')),'hex') AS b_fingerprint",
  ].join('\n'), [actor, heldPath]);
  assert.deepEqual(row, { a: erased ? 0 : 1, credential: erased ? 0 : 1, sessions: 0,
    registered: erased ? 0 : 1, held: 1, states: erased ? ['pending'] : [],
    a_fingerprint: erased ? null : before.aFingerprint, b_fingerprint: before.bFingerprint });
  if (state.withCompletions) {
    const { rows: [extra] } = await client.query(
      'SELECT (SELECT count(*)::int FROM public.personal_problem_completion WHERE user_id=$1) AS marks,' +
      ' (SELECT count(*)::int FROM public.personal_completion_write_limit WHERE user_id=$1) AS limiter', [actor],
    );
    assert.deepEqual(extra, { marks: erased ? 0 : before.aMarks, limiter: erased ? 0 : before.aLimiter });
  }
}

async function readCheck(db, erased) {
  return use(db, async client => {
    await client.query('BEGIN READ ONLY');
    await check(client, erased);
    const receipt = erased ? (await client.query(
      "SELECT o.deletion_id::text AS id FROM public.account_deletion_outbox o WHERE o.provider='author' AND o.pathname=$1 AND o.state='pending'",
      [heldPath],
    )).rows[0].id : null;
    await client.query('ROLLBACK');
    return receipt;
  });
}

if (action === 'CheckErasure') {
  const receipt = await readCheck(source, true);
  console.log('Source=A absent, B unchanged, Held=1, Pending=1');
  console.log('SourceReceipt=' + receipt);
} else if (action === 'Restore') {
  const receipt = await readCheck(source, true);
  await use(source, async client => {
    const { rows: [row] } = await client.query("SELECT count(*)::int AS n FROM pg_stat_activity WHERE datname=current_database() AND pid<>pg_backend_pid() AND backend_type='client backend'");
    assert.equal(row.n, 0, 'Stop the fixture app and close other clients');
    await client.query('CREATE DATABASE physcratic_restore_test OWNER phase5b_owner');
    await client.query('REVOKE CONNECT, TEMP ON DATABASE physcratic_restore_test FROM PUBLIC');
  });
  assert.match(await use(target, targetIdentity), /^\d+$/);
  const env = Object.fromEntries(Object.entries(process.env).filter(([k]) => !/^PG/i.test(k)));
  Object.assign(env, { PGPASSWORD: state.secrets.admin, PGSSLMODE: 'disable', PGGSSENCMODE: 'disable', PGCONNECT_TIMEOUT: '5' });
  const result = spawnSync(restoreExe, ['-h','127.0.0.1','-p','55439','-U',admin,'-d',target,
    '-w','--single-transaction','--exit-on-error',dump], { env, stdio: 'inherit', timeout: 60000 });
  assert.equal(result.status, 0, 'Restore did not complete');
  await readCheck(target, false);
  const targetId = await use(target, targetIdentity);
  const approval = { database: target, databaseOid: targetId, dumpSha256: before.dumpSha256, subjectId: actor,
    subjectFingerprint: before.aFingerprint, publications: [], cleanup: [{ provider: 'author', pathname: heldPath, held: true }],
    approvedAt: null, expiresAt: null, reviewer: null, deletionRecord: receipt };
  await writeFile(approvalPath, JSON.stringify(approval,null,2) + '\n', { flag: 'wx' });
  console.log('Restored=A present, B unchanged, Held=1, Pending=0, app logins denied');
  console.log('Awaiting independently approved phase5b-recovery-approval.json');
} else if (action === 'Reconcile') {
  assert.match(expectedApproval ?? '', hex);
  const bytes = await readFile(approvalPath);
  assert.equal(sha(bytes), expectedApproval, 'Use the approval SHA-256 supplied by the reviewer');
  const approval = JSON.parse(bytes.toString('utf8'));
  assert.ok(typeof approval.reviewer === 'string' && approval.reviewer.trim() && typeof approval.deletionRecord === 'string' && approval.deletionRecord.trim());
  if (![approval.approvedAt,approval.expiresAt].every(value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{3})?Z$/.test(value))) throw Error('Reviewer must supply UTC approval times');
  const time = Date.parse(approval.approvedAt);
  const expires = Date.parse(approval.expiresAt);
  assert.ok(time <= Date.now() && expires > Date.now() && expires - time <= 86400000);
  assert.deepEqual([approval.database,approval.dumpSha256,approval.subjectId,approval.subjectFingerprint,approval.publications,approval.cleanup],
    [target,before.dumpSha256,actor,before.aFingerprint,[],[{ provider:'author',pathname:heldPath,held:true }]]);
  assert.equal(await readCheck(source, true), approval.deletionRecord, 'Approval must match the original synthetic receipt');
  const sql = await readFile(new URL('./reconcile-native.sql', import.meta.url), 'utf8');
  const [start, replay] = sql.split('-- APPROVAL PARAMETERS --');
  await use(target, async client => {
    assert.equal(await targetIdentity(client), approval.databaseOid);
    await client.query(start);
    await client.query("SELECT set_config('physcratic.restore_approval',$1,true),set_config('physcratic.restore_nonce',$2,true)",
      [bytes.toString('base64'), sha('phase5b-native-restore:' + expectedApproval)]);
    await client.query(replay);
    await check(client, true);
    const { rows: [{ status }] } = await client.query("SELECT current_setting('physcratic.restore_result') AS status");
    assert.ok(['RECONCILED','ALREADY_RECONCILED'].includes(status));
    await client.query('COMMIT');
    console.log(status + ': A absent, B unchanged, Held=1, Pending=1');
  });
} else {
  throw Error('Unexpected rehearsal action');
}
