# Physcratic Batch 1 review package

The binary-safe Git patch reconstructs the local implementation from the exact GitHub base. See GIT_IDENTITIES.txt for the base, final commit and tree. CHANGED_FILES.txt lists every path. The implementation is for independent review with the feature OFF.

## Verify and review

Verify the archive members with `sha256sum -c SHA256SUMS` from the extracted directory. Use a separate worktree for review. The patch requires the exact base commit.

```sh
git worktree add --detach ../author-credit-review ce970c8d4ec5902335169d7ee5d3855b3c1187b0
git -C ../author-credit-review apply --check --index /absolute/path/to/author-credit-batch1.patch
git -C ../author-credit-review apply --index /absolute/path/to/author-credit-batch1.patch
git -C ../author-credit-review write-tree
```

The last command must print `89b8f3fbfdf32433156f9d64d805e6ff50847381`. The patch and tree were independently verified using a fresh index seeded from the base.

TEST_REPORT.md records local validation. AUTHOR_CREDIT.md contains the engineering handoff. AUTHOR_CREDIT_DISCLOSURE_DRAFT.md is the Studio and Privacy Notice copy for approval. The migrations directory contains the exact committed 0023 artifacts for review.

The package is prepared for code review. Production activation requires a separate decision after the public projection, disclosure review and migration approval.
