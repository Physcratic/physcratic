# Batch 1 local test report

Reviewed on 23 November 2026. Base `ce970c8d4ec5902335169d7ee5d3855b3c1187b0`, final `58de832e327daf7df09bbd9ff1bd5d9bfcb0aae5`. Node 22.23.5 and pnpm 10.34.9. Frozen installation passed.

| Check | Result |
| --- | --- |
| Disposable PostgreSQL 18.7 | 62 passed, 1 optional erasure browser case skipped, 0 failed |
| Studio rendering and CSP inventory unit checks | 22 passed |
| Copy rules | 27 passed |
| Offline isolation safety | Runner self-test passed, 6 checks passed, 2 Windows-only tsx pipe cases skipped on Linux |
| TypeScript | Next type generation and `tsc --noEmit` passed |
| Lint | `pnpm lint --max-warnings=0` passed |
| Production build | Passed with synthetic local Better Auth data and 197 static pages generated |
| Built JSON route with the gate OFF | GET and PATCH both returned 503 with `private, no-store` without a database binding. Route was present in the built and reviewed non-document inventories |
| Browser | Actual Studio credit component and app stylesheet, with mocked API responses. Chromium passed at 390 and 1440 pixels in light and dark for keyboard acknowledgement, duplicate-name recovery, separate claim and consent, withdrawal and horizontal fit |
| Existing activation and runtime-role package manifests | SHA-256 verification passed |

The database run covered case-insensitive duplicates, same-account and cross-account concurrent claims, stale consent revisions, actual expired sessions and switched cookies before quota, continued privacy after a claim and acknowledgement, preservation of separate profile deactivation, shared quota, withdrawal with the published revision intact, and actual account deletion. It also checked gate-OFF behavior before 0023, the guarded DOWN, and preserved the existing signup and detail attribution suites.

## Focused commands

```sh
pnpm install --frozen-lockfile
AUTHORING_TEST_POSTGRES_IMAGE=postgres:18.7-alpine pnpm run test:db \
  pnpm exec tsx --conditions=react-server --test lib/author-credit.test.ts lib/account-deletion.test.ts \
  lib/profile-signup.pg.test.ts lib/authored-attribution.test.ts lib/community-profile.test.ts
pnpm exec tsx --test tests/author-credit-ui.test.ts tests/studio-landing.test.ts \
  tests/studio-cleanup.test.ts tests/csp-route-inventory.test.ts
node --require ./tests/server-only-register.cjs --import tsx --test lib/copy-rules.test.ts
python3 -B scripts/phase-c-offline/run.py safety
pnpm exec next typegen && pnpm exec tsc --noEmit
pnpm lint --max-warnings=0
pnpm build
```

The test DB runner used loopback-only disposable PostgreSQL, and the build used synthetic configuration and a separate disposable auth fixture. GitHub CI requires a later owner-approved publication step.
