import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { existsSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";

const target = {
  endpoint: "ep-snowy-heart-b7c1220y.c-13.us-east-1.aws.neon.tech",
  port: "5432",
  database: "neondb",
  login: "neondb_owner",
  databaseOwner: "neondb_owner",
  schemaOwner: "pg_database_owner",
  version: "180007",
  runtimeRole: "physcratic_runtime_app",
};

try {
  const [checkout, output] = process.argv.slice(2);
  if (!checkout || !output || existsSync(output)) throw Error("A clean reviewed checkout and fresh output filename are required.");
  const transport = pathToFileURL(resolve(checkout, "scripts/retrospective-baseline/transport.mjs"));
  const { attestPsqlOutput } = await import(transport.href);
  const environment = { ...process.env, LC_ALL: "C", LANG: "C", LANGUAGE: "C", PGCLIENTENCODING: "UTF8" };
  for (const key of ["PGSERVICE", "PGSERVICEFILE", "PGHOSTADDR", "PGOPTIONS", "PGSSLNEGOTIATION"]) delete environment[key];
  if ("PGPASSWORD" in environment) throw Error("Use approved libpq credentials without PGPASSWORD.");
  const connection = "dbname=" + target.database + " sslmode=verify-full gssencmode=disable connect_timeout=5";
  const result = spawnSync("psql", [
    "-X", "-qAt", "--set=ON_ERROR_STOP=1", "--host", target.endpoint, "--port", target.port,
    "--username", target.login, "--dbname", connection, "--set", "expected_database=" + target.database,
    "--set", "expected_login=" + target.login, "--set", "expected_owner=" + target.databaseOwner,
    "--set", "expected_schema_owner=" + target.schemaOwner, "--set", "expected_version=" + target.version,
    "--set", "runtime_role=" + target.runtimeRole, "--command", "\\conninfo", "--file",
    fileURLToPath(new URL("inspect-plan-metadata.sql", import.meta.url)),
  ], { env: environment, stdio: ["inherit", "pipe", "inherit"], encoding: "utf8", maxBuffer: 16 * 1024 * 1024 });
  if (result.error) throw result.error;
  if (result.status !== 0) throw Error("The read-only metadata transaction failed. Stop and investigate.");
  const { captureVersion, ...metadata } = attestPsqlOutput(result.stdout);
  const bytes = JSON.stringify({ metadataVersion: 1, purpose: "inspection-plan-qualification", endpoint: target.endpoint, ...metadata }) + "\n";
  writeFileSync(output, bytes, { flag: "wx", mode: 0o600 });
  console.log("Private metadata file saved. SHA-256 " + createHash("sha256").update(bytes).digest("hex"));
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
