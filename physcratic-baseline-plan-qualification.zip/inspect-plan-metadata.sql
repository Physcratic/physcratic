-- One bounded metadata-only transaction. No deployment, application function or student rows.
\set ON_ERROR_STOP on
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL search_path = pg_catalog;
SET LOCAL timezone = 'UTC';
SET LOCAL lock_timeout = '2s';
SET LOCAL statement_timeout = '30s';

SELECT current_database() = :'expected_database'
  AND session_user = :'expected_login' AND current_user = session_user
  AND current_setting('server_version_num') = :'expected_version'
  AND current_setting('server_version_num')::int BETWEEN 180000 AND 189999
  AND NOT pg_is_in_recovery()
  AND current_setting('transaction_read_only') = 'on'
  AND (SELECT pg_get_userbyid(datdba) FROM pg_database WHERE datname = current_database()) = :'expected_owner'
  AND (SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname = 'public') = :'expected_schema_owner'
  AND EXISTS (SELECT FROM pg_roles WHERE rolname = :'runtime_role')
  AND (SELECT count(*)=2 FROM pg_class WHERE relnamespace='public'::regnamespace
       AND relname IN ('authored_revision','physcratic_production_migrations')
       AND relkind='r' AND NOT relrowsecurity AND NOT relforcerowsecurity)
  AS target_matches \gset
\if :target_matches
\else
\warn 'Unexpected target, inspection LOGIN, recovery state or evidence-table kind/security.'
SELECT 1/0;
\endif

WITH relations AS (
  SELECT c.*
  FROM pg_class c WHERE c.relnamespace = 'public'::regnamespace AND c.relname IN (
    'user','session','solution_evidence','authored_problem','authored_revision','authored_revision_part',
    'authored_revision_private_part','author_revision_media','authored_attempt','author_media',
    'community_profile','community_profile_write_limit','community_profile_media',
    'community_favourite','community_favourite_limit','community_problem_total',
    'community_medal_claim','community_approved_medal','community_badge_selection','community_achievement_write_limit',
    'community_external_medal','community_external_medal_audit','community_external_approved_medal','community_restriction',
    'personal_problem_completion','personal_completion_write_limit',
    'account_deletion_publication','account_deletion_outbox','account_deletion_pending_upload',
    'physcratic_production_migrations'
  )
), columns AS (
  SELECT r.relname, a.* FROM relations r JOIN pg_attribute a ON a.attrelid = r.oid
  WHERE a.attnum > 0 AND NOT a.attisdropped
), routines AS (
  SELECT p.*, p.oid::regprocedure::text AS signature FROM pg_proc p
  WHERE p.pronamespace = 'public'::regnamespace AND (
    p.oid IN (SELECT tgfoid FROM pg_trigger WHERE tgrelid IN (SELECT oid FROM relations) AND NOT tgisinternal)
    OR p.proname IN ('community_achievement_progress','community_achievement_problem_solved',
      'community_showcase_ids_valid','authored_discovery_terms','community_external_medal_recipient',
      'community_external_medal_award','community_external_medal_revoke','community_profile_claim_signup',
      'community_profile_guard_publication','community_restriction_decide','account_deletion_execute','account_deletion_cleanup',
      'account_deletion_mutation_allowed','account_deletion_upload_finished')
  )
), objects AS (
  SELECT 'relation:'||r.relname AS key,r.oid,r.relowner AS owner,r.relacl AS acl,'r'::"char" AS acl_type FROM relations r
  UNION ALL SELECT 'routine:'||p.signature,p.oid,p.proowner,p.proacl,'f'::"char" FROM routines p
), shared_objects AS (
  SELECT 'database:'||datname AS key, datdba AS owner, datacl AS acl, 'd'::"char" AS acl_type
  FROM pg_database WHERE datname=current_database()
  UNION ALL
  SELECT 'schema:'||nspname,nspowner,nspacl,'n'::"char" FROM pg_namespace WHERE nspname='public'
), acl_rows AS (
  SELECT o.key,'' AS column_name,a.*
  FROM objects o CROSS JOIN LATERAL aclexplode(coalesce(o.acl,acldefault(o.acl_type,o.owner))) a
  WHERE a.grantee<>o.owner
  UNION ALL
  SELECT 'relation:'||c.relname,c.attname,a.* FROM columns c JOIN relations r ON r.oid=c.attrelid
  CROSS JOIN LATERAL aclexplode(c.attacl) a WHERE a.grantee<>r.relowner
), shared_acl AS (
  SELECT o.key,a.* FROM shared_objects o CROSS JOIN LATERAL aclexplode(coalesce(o.acl,acldefault(o.acl_type,o.owner))) a
), creator_acl AS (
  SELECT d.defaclrole AS creator,coalesce(n.nspname,'') AS schema_name,d.defaclobjtype AS object_type,
    a.grantee,a.grantor,a.privilege_type,a.is_grantable
  FROM pg_default_acl d LEFT JOIN pg_namespace n ON n.oid=d.defaclnamespace
  LEFT JOIN LATERAL aclexplode(d.defaclacl) a ON true
  WHERE (d.defaclnamespace=0 OR n.nspname='public')
    AND d.defaclrole IN (SELECT owner FROM objects UNION SELECT owner FROM shared_objects)
), principals AS (
  SELECT owner AS oid FROM objects UNION SELECT owner FROM shared_objects
  UNION SELECT oid FROM pg_roles WHERE rolname IN (:'runtime_role',session_user)
  UNION SELECT grantee FROM acl_rows WHERE grantee<>0 UNION SELECT grantor FROM acl_rows
  UNION SELECT grantee FROM shared_acl WHERE grantee<>0 UNION SELECT grantor FROM shared_acl
  UNION SELECT grantee FROM creator_acl WHERE grantee<>0 UNION SELECT grantor FROM creator_acl WHERE grantor IS NOT NULL
), role_paths AS (
  SELECT m.oid AS member,g.oid AS granted,
    pg_has_role(m.oid,g.oid,'USAGE') AS inherits,pg_has_role(m.oid,g.oid,'SET') AS can_set
  FROM pg_roles m CROSS JOIN pg_roles g
  WHERE m.oid<>g.oid AND NOT m.rolsuper
    AND (m.oid IN (SELECT oid FROM principals) OR g.oid IN (SELECT oid FROM principals))
    AND pg_has_role(m.oid,g.oid,'MEMBER')
), relevant_roles AS (
  SELECT oid FROM principals UNION SELECT member FROM role_paths UNION SELECT granted FROM role_paths
), direct_edges AS (
  SELECT a.* FROM pg_auth_members a
  WHERE a.member IN (SELECT oid FROM relevant_roles) AND a.roleid IN (SELECT oid FROM relevant_roles)
), runtime AS (
  SELECT * FROM pg_roles WHERE rolname=:'runtime_role'
), effective AS (
  SELECT o.key,
    CASE WHEN o.acl_type='f' THEN
      ARRAY(SELECT 'EXECUTE' WHERE has_function_privilege(r.oid,o.oid,'EXECUTE'))
    ELSE ARRAY(SELECT p FROM unnest(ARRAY['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER','MAINTAIN']) p
       WHERE has_table_privilege(r.oid,o.oid,p) ORDER BY p) END AS rights,
    CASE WHEN o.acl_type='f' THEN has_function_privilege(r.oid,o.oid,'EXECUTE WITH GRANT OPTION')
      ELSE has_table_privilege(r.oid,o.oid,'SELECT WITH GRANT OPTION,INSERT WITH GRANT OPTION,UPDATE WITH GRANT OPTION,DELETE WITH GRANT OPTION,TRUNCATE WITH GRANT OPTION,REFERENCES WITH GRANT OPTION,TRIGGER WITH GRANT OPTION,MAINTAIN WITH GRANT OPTION')
    END AS grant_option
  FROM objects o CROSS JOIN runtime r
), effective_columns AS (
  SELECT 'relation:'||c.relname AS key,c.attname AS column_name,
    ARRAY(SELECT p FROM unnest(ARRAY['SELECT','INSERT','UPDATE','REFERENCES']) p
      WHERE has_column_privilege(r.oid,c.attrelid,c.attnum,p) ORDER BY p) AS rights,
    has_column_privilege(r.oid,c.attrelid,c.attnum,'SELECT WITH GRANT OPTION,INSERT WITH GRANT OPTION,UPDATE WITH GRANT OPTION,REFERENCES WITH GRANT OPTION') AS grant_option
  FROM columns c CROSS JOIN runtime r
)
SELECT jsonb_build_object(
  -- This internal version lets the reviewed parser attest this psql output. The wrapper writes a separate metadata format.
  'captureVersion',2,
  'target',jsonb_build_object('database',current_database(),'login',session_user,
    'version',current_setting('server_version_num')::int,'observedAt',statement_timestamp(),
    'readOnly',current_setting('transaction_read_only')='on',
    'databaseOwner',(SELECT pg_get_userbyid(datdba) FROM pg_database WHERE datname=current_database()),
    'schemaOwner',(SELECT pg_get_userbyid(nspowner) FROM pg_namespace WHERE nspname='public'),
    'backendTls',(SELECT jsonb_build_object('ssl',ssl,'protocol',version) FROM pg_stat_ssl WHERE pid=pg_backend_pid())),
  'ledger',(SELECT coalesce(jsonb_agg(jsonb_build_object('id',id,'sha256',sha256,'sourceCommit',source_commit,
    'appliedBy',applied_by,'appliedAt',applied_at,'result',result) ORDER BY id),'[]') FROM public.physcratic_production_migrations),
  'optionalMarkers',jsonb_build_object(
    '0019',jsonb_build_array(to_regclass('public.community_restriction') IS NOT NULL,
      to_regprocedure('public.community_restriction_decide(text,text,text,integer,boolean,text)') IS NOT NULL),
    '0023',(SELECT coalesce(jsonb_agg(attname ORDER BY attname),'[]') FROM columns
      WHERE relname='community_profile' AND attname IN
        ('author_credit_policy_version','author_credit_acknowledged_at','author_credit_withdrawn_at')),
    '0025',jsonb_build_array(to_regclass('public.personal_problem_completion') IS NOT NULL,
      to_regclass('public.personal_completion_write_limit') IS NOT NULL),
    '0026',jsonb_build_array(to_regclass('public.account_deletion_pending_upload') IS NOT NULL,
      to_regprocedure('public.account_deletion_upload_finished(text,text,text)') IS NOT NULL)),
  'scopedOwners',(SELECT jsonb_object_agg(key,pg_get_userbyid(owner)) FROM objects),
  'scopedAcl',(SELECT coalesce(jsonb_agg(jsonb_build_array(key,column_name,
    CASE WHEN grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(grantee) END,
    pg_get_userbyid(grantor),privilege_type,is_grantable)
    ORDER BY key,column_name,grantee,grantor,privilege_type),'[]') FROM acl_rows),
  'databaseAndSchemaAcl',(SELECT coalesce(jsonb_agg(jsonb_build_array(key,
    CASE WHEN grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(grantee) END,
    pg_get_userbyid(grantor),privilege_type,is_grantable)
    ORDER BY key,grantee,grantor,privilege_type),'[]') FROM shared_acl),
  'creatorDefaultAcl',(SELECT coalesce(jsonb_agg(jsonb_build_array(pg_get_userbyid(creator),schema_name,object_type,
    CASE WHEN grantee=0 THEN 'PUBLIC' ELSE pg_get_userbyid(grantee) END,
    pg_get_userbyid(grantor),privilege_type,is_grantable)
    ORDER BY creator,schema_name,object_type,grantee,grantor,privilege_type),'[]') FROM creator_acl),
  'roleAttributes',(SELECT coalesce(jsonb_agg(jsonb_build_object('role',rolname,
    'login',rolcanlogin,'inheritsByDefault',rolinherit,'superuser',rolsuper,'createRole',rolcreaterole,
    'createDb',rolcreatedb,'replication',rolreplication,'bypassRls',rolbypassrls) ORDER BY rolname),'[]')
    FROM pg_roles WHERE oid IN (SELECT oid FROM relevant_roles UNION SELECT grantor FROM direct_edges)),
  'scopedMemberships',(SELECT coalesce(jsonb_agg(jsonb_build_array(
    pg_get_userbyid(p.member),pg_get_userbyid(p.granted),p.inherits,p.can_set) ORDER BY p.member,p.granted),'[]')
    FROM role_paths p WHERE p.granted IN (SELECT owner FROM objects UNION SELECT grantee FROM acl_rows UNION SELECT oid FROM runtime)),
  'relatedMemberships',(SELECT coalesce(jsonb_agg(jsonb_build_array(
    pg_get_userbyid(member),pg_get_userbyid(granted),inherits,can_set) ORDER BY member,granted),'[]') FROM role_paths),
  'directRoleGrants',(SELECT coalesce(jsonb_agg(jsonb_build_array(pg_get_userbyid(member),pg_get_userbyid(roleid),
    pg_get_userbyid(grantor),inherit_option,set_option,admin_option) ORDER BY member,roleid,grantor),'[]') FROM direct_edges),
  'explicitObjectAcl',(SELECT coalesce(jsonb_agg(key ORDER BY key),'[]') FROM objects WHERE acl IS NOT NULL),
  'runtimeEffective',(SELECT jsonb_object_agg(key,jsonb_build_array(rights,grant_option)) FROM effective),
  'runtimeEffectiveColumns',(SELECT coalesce(jsonb_agg(jsonb_build_array(key,column_name,rights,grant_option)
    ORDER BY key,column_name),'[]') FROM effective_columns),
  'runtimeBoundary',(SELECT jsonb_build_object(
    'connect',has_database_privilege(oid,current_database(),'CONNECT'),
    'databaseCreate',has_database_privilege(oid,current_database(),'CREATE'),
    'schemaUsage',has_schema_privilege(oid,'public','USAGE'),
    'schemaCreate',has_schema_privilege(oid,'public','CREATE'),
    'databaseConnectGrantOption',has_database_privilege(oid,current_database(),'CONNECT WITH GRANT OPTION'),
    'schemaUsageGrantOption',has_schema_privilege(oid,'public','USAGE WITH GRANT OPTION')) FROM runtime)
);
ROLLBACK;
