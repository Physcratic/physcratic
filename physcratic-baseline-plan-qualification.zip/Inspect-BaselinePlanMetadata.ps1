[CmdletBinding()]
param(
    [Parameter(Mandatory)] [string] $Repository,
    [switch] $VerifyFiles,
    [string] $EvidenceDir,
    [string] $MetadataAuthorizationRef
)

$ErrorActionPreference = 'Stop'
$Commit = 'b832cc41ec7e1885cfc83ea935c445c1b5c5609a'
$ManifestSha = 'cd332ed1325989ba6195132c3a106b139362c4b8853a33f016c4e64e7665ae2a'
$Package = 'scripts/retrospective-baseline'
$MetadataFiles = [ordered]@{
    'inspect-plan-metadata.mjs' = 'd1cb821092a724d7162bfec842faa795b76b44f08ff680641ab75d9529ef271a'
    'inspect-plan-metadata.sql' = '49aad5c946ceb7efe55207f66e06d5d2878d9d08973bd21e3175f47057044d85'
}

function Assert-Sha256([string] $Path, [string] $Expected) {
    if ((Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $Expected) {
        throw "Checksum mismatch for $Path."
    }
}

Push-Location -LiteralPath $Repository
try {
    $Head = & git rev-parse HEAD
    if ($LASTEXITCODE -ne 0 -or $Head -cne $Commit) { throw 'Use the exact reviewed PR #263 checkout.' }
    $Status = & git status --porcelain
    if ($LASTEXITCODE -ne 0 -or $Status) { throw 'Use a clean PR #263 checkout.' }

    $Manifest = Join-Path $Package 'PACKAGE_SHA256SUMS'
    Assert-Sha256 $Manifest $ManifestSha
    foreach ($Line in Get-Content -LiteralPath $Manifest) {
        $Digest, $Path = $Line -split '  ', 2
        Assert-Sha256 $Path $Digest
    }
    foreach ($Name in $MetadataFiles.Keys) {
        Assert-Sha256 (Join-Path $PSScriptRoot $Name) $MetadataFiles[$Name]
    }
    if ($VerifyFiles) {
        Write-Output 'Reviewed checkout and supplemental inspector verified offline.'
        return
    }

    if ([string]::IsNullOrWhiteSpace($MetadataAuthorizationRef)) {
        throw 'Record explicit owner authorization for this supplemental metadata-only query first.'
    }
    if (-not $EvidenceDir -or -not (Test-Path -PathType Container -LiteralPath $EvidenceDir)) {
        throw 'Use an existing access-restricted evidence directory.'
    }
    $Output = Join-Path (Resolve-Path -LiteralPath $EvidenceDir).Path 'baseline-plan-metadata.json'
    if (Test-Path -LiteralPath $Output) { throw 'Use a fresh evidence directory and keep prior metadata.' }
    if (Test-Path Env:PGPASSWORD) { throw 'Use approved libpq credentials without PGPASSWORD.' }

    $Node = (Get-Command node -CommandType Application).Source
    & $Node (Join-Path $PSScriptRoot 'inspect-plan-metadata.mjs') (Get-Location).Path $Output
    if ($LASTEXITCODE -ne 0) { throw 'Plan qualification is on hold. Preserve the failure details privately.' }
}
finally {
    Pop-Location
}
