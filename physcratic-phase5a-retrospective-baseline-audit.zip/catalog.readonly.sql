-- Read-only catalogue audit. Input bindings come from the verified PowerShell wrapper.
\set ON_ERROR_STOP on
BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout = '10s';
SET LOCAL lock_timeout = '1s';
SET LOCAL search_path = pg_catalog, pg_temp;
SELECT 1 / CASE WHEN current_database() = 'neondb'
  AND session_user = :'catalog_login' AND current_user = session_user
  AND current_setting('server_version_num') = :'server_version'
  AND current_setting('transaction_read_only') = 'on'
  AND to_regclass('public.physcratic_integration_migrations') IS NULL
  AND EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'runtime_role')
  AND EXISTS (SELECT 1 FROM pg_roles WHERE rolname = :'trusted_owner')
  THEN 1 ELSE 0 END AS audit_target_guard \gset

WITH runtime AS (
  SELECT * FROM pg_roles WHERE rolname = :'runtime_role'
), rel AS (
  SELECT c.*, c.relname::text AS object_name,
         c.relname IN ('community_external_medal','community_external_medal_audit','community_external_approved_medal','account_deletion_pending_upload') AS isolated
  FROM pg_class c
  WHERE c.relnamespace = 'public'::regnamespace
  AND c.relname IN ('authored_revision','authored_problem','community_favourite','user','community_profile',
    'community_profile_write_limit','community_badge_selection','community_achievement_write_limit','community_medal_claim',
    'community_external_medal','community_external_medal_audit','community_external_approved_medal','account_deletion_pending_upload','account_deletion_publication')
), guard_scope(relation_name, trigger_name) AS (VALUES
  ('authored_problem','account_deletion_guard_continuing_display'),
  ('community_favourite','community_favourite_total'),('community_favourite','community_favourite_guard'),
  ('user','community_profile_claim_signup'),('community_profile','community_profile_guard_update'),
  ('community_profile','community_profile_guard_publication'),('community_badge_selection','community_badge_selection_guard'),
  ('community_medal_claim','community_medal_external_slot_guard'),
  ('community_medal_claim','account_deletion_reserve_upload'),('community_medal_claim','account_deletion_preserve_upload'),
  ('author_media','account_deletion_reserve_upload'),('author_media','account_deletion_preserve_upload'),
  ('community_profile_media','account_deletion_reserve_upload'),('community_profile_media','account_deletion_preserve_upload'),
  ('solution_evidence','account_deletion_reserve_upload'),('solution_evidence','account_deletion_preserve_upload')
), constraint_scope(relation_name, constraint_name) AS (VALUES
  ('authored_revision','authored_revision_solution_consent_check'),('community_favourite','community_favourite_key_check'),
  ('user','user_profile_signup_pair'),('community_profile','community_profile_publication_record'),
  ('account_deletion_publication','account_deletion_reviewed_revision_fk')
), routine AS (
  SELECT p.*, p.proname || '(' || oidvectortypes(p.proargtypes) || ')' AS object_name,
    p.proname IN ('account_deletion_execute','account_deletion_cleanup') AS service_acl
  FROM pg_proc p WHERE p.pronamespace = 'public'::regnamespace
  AND p.proname IN ('community_achievement_problem_solved','community_achievement_progress',
    'community_favourite_total','community_favourite_guard','community_profile_claim_signup',
    'community_profile_guard_publication','community_profile_guard_update','community_showcase_ids_valid',
    'community_badge_selection_guard','community_medal_external_slot_guard',
    'community_external_medal_recipient','community_external_medal_award','community_external_medal_revoke',
    'account_deletion_execute','account_deletion_cleanup','account_deletion_upload_guard',
    'account_deletion_upload_finished','account_deletion_guard_continuing_display')
), rights_rel AS (
  SELECT * FROM rel WHERE object_name NOT IN ('authored_problem','community_medal_claim')
), column_scope AS (
  SELECT r.object_name, r.oid, r.relowner, r.isolated, a.*
  FROM rights_rel r JOIN pg_attribute a ON a.attrelid = r.oid
  WHERE a.attnum > 0 AND NOT a.attisdropped
    AND (r.isolated OR r.object_name IN ('community_profile','community_profile_write_limit','community_favourite',
      'community_badge_selection','community_achievement_write_limit')
      OR (r.object_name='authored_revision' AND a.attname IN ('solution_policy','solution_consented_at'))
      OR (r.object_name='user' AND a.attname IN ('profileSignupHandle','profileSignupPolicyVersion'))
      OR (r.object_name='account_deletion_publication' AND a.attname='reviewed_revision_id'))
), definitions(kind, key, value) AS (
  SELECT 'relation',r.object_name,jsonb_build_array(r.relkind,r.relrowsecurity,r.relforcerowsecurity,
    ARRAY(SELECT unnest(r.reloptions) ORDER BY 1),pg_get_userbyid(r.relowner)=:'trusted_owner',
    CASE WHEN r.relkind='v' THEN pg_get_viewdef(r.oid,false) END)
  FROM rel r
  UNION ALL
  SELECT 'column',c.object_name||'.'||c.attname,jsonb_build_array(format_type(c.atttypid,c.atttypmod),
    c.attnotnull,c.attidentity,c.attgenerated,pg_get_expr(d.adbin,d.adrelid,false),
    CASE WHEN c.attcollation <> 0 THEN c.attcollation::regcollation::text END)
  FROM column_scope c LEFT JOIN pg_attrdef d ON d.adrelid=c.attrelid AND d.adnum=c.attnum
  UNION ALL
  SELECT 'constraint',r.object_name||'.'||c.conname,jsonb_build_array(c.contype, c.convalidated,c.condeferrable,
    c.condeferred,c.conenforced,pg_get_constraintdef(c.oid,false))
  FROM rel r JOIN pg_constraint c ON c.conrelid=r.oid
  WHERE r.isolated OR (r.object_name,c.conname) IN (SELECT relation_name,constraint_name FROM constraint_scope)
    OR (r.object_name='community_badge_selection' AND c.contype='c')
  UNION ALL
  SELECT 'index',r.object_name||'.'||idx.relname,jsonb_build_array(i.indisvalid,i.indisready,i.indislive,i.indisunique,
    pg_get_userbyid(idx.relowner)=:'trusted_owner',pg_get_indexdef(i.indexrelid,0,false))
  FROM rel r JOIN pg_index i ON i.indrelid=r.oid JOIN pg_class idx ON idx.oid=i.indexrelid
  WHERE r.isolated OR idx.relname IN ('community_profile_handle_unique','community_favourite_problem_idx','community_favourite_authored_idx')
  UNION ALL
  SELECT 'trigger',c.relname||'.'||t.tgname,jsonb_build_array(t.tgenabled,pg_get_triggerdef(t.oid,false))
  FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid
  WHERE c.relnamespace='public'::regnamespace AND NOT t.tgisinternal
  AND ((c.relname,t.tgname) IN (SELECT relation_name,trigger_name FROM guard_scope)
    OR c.relname IN ('authored_revision','user','community_favourite','community_profile','community_badge_selection','community_medal_claim',
      'community_external_medal','community_external_medal_audit','community_external_approved_medal','account_deletion_pending_upload'))
  UNION ALL
  SELECT 'policy',r.object_name||'.'||p.polname,jsonb_build_array(p.polpermissive,p.polcmd,
    ARRAY(SELECT CASE WHEN roles.oid=0 THEN 'PUBLIC'
        WHEN pg_get_userbyid(roles.oid)=:'trusted_owner' THEN 'owner'
        WHEN pg_get_userbyid(roles.oid)=:'runtime_role' THEN 'runtime' ELSE 'third_party' END
      FROM unnest(p.polroles) AS roles(oid) ORDER BY 1),
    pg_get_expr(p.polqual,p.polrelid,false),pg_get_expr(p.polwithcheck,p.polrelid,false))
  FROM pg_policy p JOIN rel r ON r.oid=p.polrelid
  UNION ALL
  SELECT 'routine',p.object_name,jsonb_build_array(pg_get_userbyid(p.proowner)=:'trusted_owner',p.prosecdef,p.proconfig,
    replace(pg_get_functiondef(p.oid),E'\r\n',E'\n')) FROM routine p
  UNION ALL
  SELECT 'role','runtime',jsonb_build_array(a.rolcanlogin,a.rolinherit,a.rolsuper,a.rolcreatedb,a.rolcreaterole,
    a.rolreplication,a.rolbypassrls,has_database_privilege(a.oid,current_database(),'CONNECT'),
    has_database_privilege(a.oid,current_database(),'CREATE'),has_schema_privilege(a.oid,'public','USAGE'),
    EXISTS(SELECT 1 FROM pg_namespace n WHERE n.nspname NOT LIKE 'pg_%' AND n.nspname<>'information_schema'
      AND has_schema_privilege(a.oid,n.oid,'CREATE')),
    EXISTS(SELECT 1 FROM pg_roles m WHERE m.oid<>a.oid AND pg_has_role(a.oid,m.oid,'MEMBER')))
  FROM runtime a
  UNION ALL
  SELECT 'table_rights',r.object_name,jsonb_build_array(
    ARRAY(SELECT p FROM unnest(ARRAY['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER','MAINTAIN']) p
      WHERE has_table_privilege(a.oid,r.oid,p) ORDER BY p),
    ARRAY(SELECT p FROM unnest(ARRAY['SELECT','INSERT','UPDATE','DELETE','TRUNCATE','REFERENCES','TRIGGER','MAINTAIN']) p
      WHERE has_table_privilege(a.oid,r.oid,p||' WITH GRANT OPTION') ORDER BY p),
    ARRAY(SELECT DISTINCT x.privilege_type || ':' || CASE WHEN x.grantee=0 THEN 'PUBLIC' ELSE 'third_party' END
      FROM aclexplode(coalesce(r.relacl,acldefault('r',r.relowner))) x
      WHERE x.grantee NOT IN (r.relowner,a.oid) ORDER BY 1))
  FROM rights_rel r CROSS JOIN runtime a
  UNION ALL
  SELECT 'column_rights',c.object_name||'.'||c.attname,jsonb_build_array(
    ARRAY(SELECT p FROM unnest(ARRAY['SELECT','INSERT','UPDATE','REFERENCES']) p
      WHERE has_column_privilege(a.oid,c.oid,c.attnum,p) ORDER BY p),
    ARRAY(SELECT p FROM unnest(ARRAY['SELECT','INSERT','UPDATE','REFERENCES']) p
      WHERE has_column_privilege(a.oid,c.oid,c.attnum,p||' WITH GRANT OPTION') ORDER BY p),
    ARRAY(SELECT DISTINCT x.privilege_type || ':' || CASE WHEN x.grantee=0 THEN 'PUBLIC' ELSE 'third_party' END
      FROM aclexplode(c.attacl) x WHERE x.grantee NOT IN (c.relowner,a.oid) ORDER BY 1))
  FROM column_scope c CROSS JOIN runtime a
  UNION ALL
  SELECT 'routine_rights',p.object_name,jsonb_build_array(has_function_privilege(a.oid,p.oid,'EXECUTE'),
    has_function_privilege(a.oid,p.oid,'EXECUTE WITH GRANT OPTION'),
    EXISTS(SELECT 1 FROM aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) x WHERE x.grantee=0),
    CASE WHEN NOT p.service_acl THEN
      EXISTS(SELECT 1 FROM aclexplode(coalesce(p.proacl,acldefault('f',p.proowner))) x WHERE x.grantee NOT IN (0,p.proowner,a.oid)) END)
  FROM routine p CROSS JOIN runtime a
), rows(kind,key,value) AS (
  SELECT kind,key,encode(sha256(convert_to(value::text,'UTF8')),'hex') FROM definitions
  UNION ALL
  SELECT 'ledger',id,sha256||':'||result FROM public.physcratic_production_migrations
  UNION ALL
  SELECT 'completions','schema_collision',c.relname::text FROM pg_class c
  WHERE c.relnamespace='public'::regnamespace AND c.relname ~ '^personal_(problem_completion|completion_write_limit)'
  UNION ALL
  SELECT 'completions','type_collision',typname::text FROM pg_type
  WHERE typnamespace='public'::regnamespace AND typname ~ '^_?personal_(problem_completion|completion_write_limit)'
  UNION ALL
  SELECT 'transport','backend_ssl',coalesce((SELECT ssl::text FROM pg_stat_ssl WHERE pid=pg_backend_pid()),'unknown')
)
SELECT kind,key,value FROM rows ORDER BY kind COLLATE "C",key COLLATE "C",value COLLATE "C";
ROLLBACK;
