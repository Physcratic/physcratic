[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [ValidatePattern('^[0-9a-f]{64}$')] [string]$ManifestSha256,
    [Parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [string]$CatalogLogin,
    [Parameter(Mandatory = $true)] [ValidateNotNullOrEmpty()] [string]$TrustedOwner,
    [string]$Approved0023Reference,
    [string]$Approved0026Reference,
    [string]$ApprovedEarnedGrantReference
)
& {
    $ErrorActionPreference = 'Stop'
    $manifest = Join-Path $PSScriptRoot 'SHA256SUMS'
    function Assert-Hash([string]$Path, [string]$Expected) {
        $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
        if ($actual -cne $Expected) { throw "SHA-256 mismatch for $(Split-Path -Leaf $Path)." }
    }
    Assert-Hash $manifest $ManifestSha256
    $remaining = @('Invoke-BaselineAudit.ps1','catalog.readonly.sql','reference.json','README.md')
    foreach ($line in Get-Content -LiteralPath $manifest) {
        if ($line -cnotmatch '^([0-9a-f]{64})  ([A-Za-z0-9_.-]+)$') { throw 'Malformed package checksum line.' }
        $expectedHash = $Matches[1]
        $file = $Matches[2]
        if ($file -cnotin $remaining) { throw 'Unexpected or duplicate package checksum entry.' }
        Assert-Hash (Join-Path $PSScriptRoot $file) $expectedHash
        $remaining = @($remaining | Where-Object { $_ -cne $file })
    }
    if ($remaining.Count) { throw 'Incomplete package checksum manifest.' }

    # Reference is a JSON object so Windows PowerShell 5.1 preserves array shape.
    $reference = ConvertFrom-Json -InputObject (Get-Content -Raw -LiteralPath (Join-Path $PSScriptRoot 'reference.json'))
    $runtimeRole = 'physcratic_runtime_app'
    $hostName = 'ep-snowy-heart-b7c1220y.c-13.us-east-1.aws.neon.tech'
    $connection = "host=$hostName hostaddr='' port=5432 dbname=neondb sslmode=verify-full gssencmode=disable connect_timeout=5"
    $psql = (Get-Command psql -CommandType Application | Select-Object -First 1).Source
    $query = Join-Path $PSScriptRoot 'catalog.readonly.sql'
    $argv = @('-X','-q','--csv','-v','ON_ERROR_STOP=1','-d',$connection,'-U',$CatalogLogin,
        '-v',"catalog_login=$CatalogLogin",'-v',"server_version=$($reference.serverVersion)",
        '-v',"runtime_role=$runtimeRole",'-v',"trusted_owner=$TrustedOwner",'-f',$query)
    $csv = & $psql @argv
    if ($LASTEXITCODE -ne 0) { throw "Read-only audit stopped (psql exit $LASTEXITCODE)." }
    $actual = @($csv | ConvertFrom-Csv)
    $transport = @($actual | Where-Object { $_.kind -ceq 'transport' -and $_.key -ceq 'backend_ssl' })
    if ($transport.Count -ne 1 -or $transport[0].value -cnotin @('true','false','unknown')) {
        throw 'Expected one transport row from the audit connection.'
    }
    $ledger = @($actual | Where-Object { $_.kind -ceq 'ledger' })
    $credit = '0023_author_credit' -cin $ledger.key
    $erasure = '0026_account_deletion_blockers' -cin $ledger.key
    $variant = if ($credit -and $erasure) { 'credit-erasure' } elseif ($credit) { 'credit' } elseif ($erasure) { 'erasure' } else { 'core' }
    $expected = $reference.variants.PSObject.Properties[$variant].Value
    $notes = @(if ($credit -xor (-not [string]::IsNullOrWhiteSpace($Approved0023Reference))) { '0023 ledger presence and independent approval evidence must agree.' }
               if ($erasure -xor (-not [string]::IsNullOrWhiteSpace($Approved0026Reference))) { '0026 ledger presence and separate owner-approved cutover evidence must agree.' })
    $earned = -not [string]::IsNullOrWhiteSpace($ApprovedEarnedGrantReference)
    $expectedRows = @($expected.ledger + $expected.facts)
    if ($earned) {
        $earnedKeys = @($reference.earnedExecute | ForEach-Object { $_.key })
        $expectedRows = @($expectedRows | Where-Object { $_.kind -cne 'routine_rights' -or $_.key -cnotin $earnedKeys }) + $reference.earnedExecute
    }

    $expectedIndex = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
    foreach ($row in $expectedRows) { $expectedIndex.Add(($row.kind + ':' + $row.key), $row.value) }
    $actualIndex = New-Object 'System.Collections.Generic.Dictionary[string,string]' ([StringComparer]::Ordinal)
    $duplicates = @(foreach ($row in $actual) {
        if ($row.kind -cnotin @('transport','completions')) {
            $address = $row.kind + ':' + $row.key
            if ($actualIndex.ContainsKey($address)) { $address } else { $actualIndex.Add($address,$row.value) }
        }
    })
    $missing = @($expectedIndex.Keys | Where-Object { -not $actualIndex.ContainsKey($_) } | Sort-Object)
    $extra = @($actualIndex.Keys | Where-Object { -not $expectedIndex.ContainsKey($_) } | Sort-Object)
    $changed = @($expectedIndex.Keys | Where-Object { $actualIndex.ContainsKey($_) -and $actualIndex[$_] -cne $expectedIndex[$_] } | Sort-Object)
    $completionMarkers = @($actual | Where-Object { $_.kind -ceq 'completions' } | ForEach-Object { $_.value })
    $held = $notes.Count -or $duplicates.Count -or $missing.Count -or $extra.Count -or $changed.Count -or $completionMarkers.Count
    [ordered]@{
        ComparedAtUtc = [DateTime]::UtcNow.ToString('o')
        ReviewedSource = $reference.sourceCommit
        ClientTls = 'verify-full'
        BackendSslReported = $transport[0].value
        DatabaseTargetGuard = 'passed'
        ExpectedVariant = $variant
        EarnedExecuteVariant = $earned
        CheckedFacts = $expectedIndex.Count
        IndependentEvidenceNotes = $notes
        Missing = $missing
        Unexpected = $extra
        Mismatched = $changed
        Duplicate = $duplicates
        CompletionSchemaCollisions = $completionMarkers
        HistoricalProvenance = 'unknown where independently unsupported'
        Audit = $(if ($held) { 'hold' } else { 'pass' })
        OwnerAcceptance = 'pending'
    } | ConvertTo-Json -Depth 5
}
